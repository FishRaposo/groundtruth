"""Offline evidence audit only. Never prints private seed key material."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

O=Path(__file__).resolve().parent
V=O.parents[1]
S=V.parent
W=S/'delivery-worktree'
E=W/'docs/evidence/answer-coverage-v7'
E4=W/'docs/evidence/answer-coverage-v4'
sys.path[:0]=[str(W/'apps/api'),str(W/'scripts')]
from app.portfolio import load_corpus
from verify_answer_coverage_delivery import audit_report,validate_headers
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def git(*args):
    return subprocess.check_output(['git','-C',str(W),*args])

result={'archives':{},'reports':{},'engineering':{},'limits':[]}
current=read(E/'current-observation.json')
payloads={}
for sidecar in E.glob('*.sha256'):
    original=sidecar.with_name(sidecar.name.removesuffix('.sha256'))
    assert sha(original.read_bytes())==sidecar.read_text().split()[0].lower(),original.name
for path in E.glob('*.zip'):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        assert len(set(names))==len(names),path.name
        hashes=json.loads(z.read('archive-file-hashes.json'))
        assert set(names)==set(hashes)|{'archive-file-hashes.json'}
        data={n:z.read(n) for n in hashes}
        assert all(sha(data[n])==h for n,h in hashes.items()),path.name
        if 'source-before.json' not in data:
            assert path.name=='v14-packaging-lint-supplement.zip'
            result['archives'][path.name]={'sha256':sha(path.read_bytes()),'payloads':len(hashes),'supplement_only':True}
            assert sha(path.read_bytes())=='a6c8daf1083c16d731ec8e8ca600c6a31c6b11190d562974766478634091cb8c'
            wheel=json.loads(data['wheel.json'])
            assert wheel['reader_probe_threshold']==0 and wheel['default_measured_threshold']==4
            wheel_path=V/'groundtruth-v14-audit.whl'
            assert sha(wheel_path.read_bytes())==wheel['sha256']
            with zipfile.ZipFile(wheel_path) as built:
                application=list((W/'apps/api/app').rglob('*.py'))
                assert all(built.read(p.relative_to(W/'apps/api').as_posix())==p.read_bytes() for p in application)
            for name,text in [('v14-final-ruff.log',b'All checks passed!'),('v14-final-format.log',b'230 files already formatted'),('v14-final-forbidden.log',b'No actionable external shared-core dependencies found.'),('v14-package-closure.log',b'Wheel vendor closure verified'),('v14-package-base.log',b'Isolated wheel imports verified'),('v14-package-reader.log',b'No broken requirements found.')]:
                assert text in data[name],name
            for model in ['minilm','roberta']:
                lines=data['v14-installed-'+model+'.log'].decode().splitlines()
                observation=json.loads(next(line for line in lines if line.startswith('{"status": "installed_api_reader_functional_probe')))
                assert observation['reader']==model and observation['threshold']==0
                assert observation['actual_upload_query_history_source'] and observation['exact_spans']
            result['packaging_supplement']={'wheel_sha256':wheel['sha256'],'matching_runtime_python_modules':len(application),'reader_smoke_threshold':0,'quality_measurement_threshold':4,'fresh_optional_install_recorded':True}
            payloads[path.name]=data
            continue
        before=json.loads(data['source-before.json'])
        after=json.loads(data['source-after.json'])
        assert before==after,path.name
        missing={}
        if 'source-recovery-qualification.json' in data:
            qualification=json.loads(data['source-recovery-qualification.json'])
            assert qualification['runtime_source_complete'] is True
            missing=qualification['missing_test_snapshots']
        for n,h in before.items():
            archived=data.get('measured-source/'+n)
            if n in missing:
                assert archived is None and missing[n]==h
                assert n.startswith('apps/api/tests/')
            else:
                assert archived is not None and sha(archived)==h,(path.name,n)
        result['archives'][path.name]={'sha256':sha(path.read_bytes()),'payloads':len(hashes),'bound_source_files':len(before),'unrecovered_tests':missing}
        payloads[path.name]=data

assert len(result['archives']['v12-exposed-development-and-review.zip']['unrecovered_tests'])==2
assert not result['archives']['v13-exposed-development-and-review.zip']['unrecovered_tests']
v14=payloads['v14-current-development-engineering.zip']
source=json.loads(v14['source-before.json'])
live_before={n:sha((W/n).read_bytes()) for n in source}
assert source==live_before
(O/'source-before.json').write_text(json.dumps(live_before,indent=2),encoding='utf-8')
assert current['source_files']==len(source)==160
result['runtime_current_bindings']=len(source)
rows=0
for label,corpus_name in [('prior-development-80','coverage-development-v3'),('exposed-v4-200','coverage-blind-v4')]:
    report=json.loads(v14[label+'-report.json'])
    assert sha(v14[label+'-report.json'])==v14[label+'-report.json.sha256'].decode().split()[0]
    assert report['evaluation_visibility'].startswith('EXPOSED DEVELOPMENT ONLY')
    assert report['selection_sha256'] is None and report['span_integrity_required']
    assert report['settings']['reader_null_threshold']==4
    assert report['settings']['reader_model_revision']=='adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'
    corpus=load_corpus(W/'apps/api/app/portfolio/assets'/corpus_name)
    audit=audit_report(report,corpus)
    assert audit==json.loads(v14[label+'-integrity.json'])
    summaries={m:r['summary'] for m,r in report['results'].items()}
    assert summaries==current['reports'][label]
    expected=(47,32) if label=='prior-development-80' else (116,80)
    assert set(report['results'])==({'keyword','vector','hybrid','reranked'} if label=='prior-development-80' else {'reranked'})
    for method,data in report['results'].items():
        assert (data['summary']['answerable_correct'],data['summary']['negative_correct'])==expected
        assert all(data['summary'][k]==0 for k in ['execution_errors','unauthorized_source_exposures','citation_integrity_failures','span_integrity_failures'])
        wrong=sum(r['category']=='answerable' and not r['refused'] and not r['answer_quality_passed'] for r in data['cases'])
        assert wrong==0
        rows+=len(data['cases'])
    result['reports'][label]=audit
    if label=='exposed-v4-200':
        try:
            validate_headers(read(E4/'first-baseline-blind-v4.json'),report)
        except ValueError as exc:
            result['blind_header_rejection']=str(exc)
        else:
            raise AssertionError('exposed report became eligible as blind comparison')
assert rows==520
result['rescored_rows']=rows

# V12/V13 stated observations are independently summarized, not rerun.
for version,expected in [('v12',(111,80)),('v13',(116,80))]:
    data=payloads[version+'-exposed-development-and-review.zip']
    report=json.loads(data['exposed-v4-200-report.json'])
    summary=report['results']['reranked']['summary']
    assert (summary['answerable_correct'],summary['negative_correct'])==expected
    for label in ['prior-development-80','exposed-v4-200']:
        raw=data[label+'-report.json']
        assert sha(raw)==data[label+'-report.json.sha256'].decode().split()[0]

checks={
 'api':('engineering/v13-current-full-python.log',b'620 passed, 1 skipped'),
 'tools':('engineering/v14-script-tests.log',b'20 passed'),
 'types':('engineering/v14-types.log',b'0 errors, 0 warnings, 0 informations'),
 'frontend':('engineering/v14-frontend-unit-permitted.log',b'72 passed'),
 'connected':('connected/connected.log',b'3 passed'),
 'diagnostics':('connected/diagnostic.log',b'3 passed'),
 'offline':('engineering/v14-browser-offline.log',b'21 passed'),
}
for label,(name,text) in checks.items():
    assert text in v14[name],label
    result['engineering'][label]=True
coverage=json.loads(v14['engineering/v14-combined-coverage.json'])['totals']
assert coverage==current['engineering']['coverage']
assert (coverage['covered_lines'],coverage['num_statements'],coverage['percent_covered_display'])==(5033,7303,'69')
result['engineering']['coverage']=coverage
assert b'EPERM' in v14['engineering/v14-frontend-unit.log']
restart=json.loads(v14['connected/restart.json'])
assert restart['equal'] is True and restart['before']==restart['after']
result['engineering']['restart']=restart
for name in current['engineering']['inspected_screenshots']:
    assert (E/name).read_bytes()==v14['connected/screenshots/'+name]
assert len(current['engineering']['inspected_screenshots'])==3

original=read(S/'original-evidence-hashes.json')
assert len(original)==16
assert all(sha((W/n).read_bytes())==h for n,h in original.items())
result['original16_unchanged']=True
paths=git('ls-tree','-r','--name-only','57e4128','docs/evidence/answer-coverage-v4').decode().splitlines()
all_v4_paths=list(paths)
paths=[n for n in paths if Path(n).suffix in {'.json','.sha256','.zip'}]
for n in paths:
    assert git('show','57e4128:'+n)==(W/n).read_bytes(),n
assert sha((E4/'first-comparison-seal.json').read_bytes())=='787ed5101e35aea4e583b150adc279592494ee06f1ffb0fc76c50043dddc5388'
assert read(E4/'first-comparison-gate.json')['gate']=='failed'
result['v4_failed_raw_unchanged']=len(paths)
assert len(all_v4_paths)==21
assert all(git('show','57e4128:'+n)==(W/n).read_bytes() for n in all_v4_paths)
result['v4_all_files_including_readme_unchanged']=len(all_v4_paths)
result['later_supplement_logs']={}
for filename,expected in [('v14-final-ruff.log',b'All checks passed!'),('v14-final-format.log',b'230 files already formatted')]:
    data=(V/filename).read_bytes()
    assert expected in data
    result['later_supplement_logs'][filename]={'sha256':sha(data),'archived_in_original_current_zip':False}

# Authorized exact-key check: examine in memory only; output counts, never keys.
keys=set()
for directory in [S/'candidate-blind-v4',V/'calibration',V/'browser-v14/data']:
    manifest=read(directory/'seed-manifest.json')
    keys.update(p['api_key'].encode() for p in manifest['principals'].values() if p.get('api_key'))
evidence_bytes=[p.read_bytes() for p in E.rglob('*') if p.is_file()]
evidence_bytes.extend(b for data in payloads.values() for b in data.values())
staged=git('diff','--cached','--name-only','--','docs/evidence').decode().splitlines()
for n in staged:
    try:
        b=git('show',':'+n)
    except subprocess.CalledProcessError:
        continue
    evidence_bytes.append(b)
    if n.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            evidence_bytes.extend(z.read(x) for x in z.namelist())
assert not any(key in b for key in keys for b in evidence_bytes)
result['exact_private_key_check']={'known_key_count':len(keys),'staged_evidence_paths':len(staged),'payloads_checked':len(evidence_bytes),'matches':0}
links=re.findall(r'\]\(([^)]+)\)',(E/'README.md').read_text(encoding='utf-8'))
assert all((E/n).exists() for n in links)
result['readme_local_links']=len(links)
live_after={n:sha((W/n).read_bytes()) for n in source}
assert live_before==live_after
(O/'source-after.json').write_text(json.dumps(live_after,indent=2),encoding='utf-8')
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'audit-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
