from pathlib import Path
import os,subprocess
R=Path('C:/Projects/operation-fan-the-hammer'); S=R/'.tmp/groundtruth-coverage-20261024'; V=S/'coverage-v3'; W=S/'delivery-worktree'; P=R/'portfolio/groundtruth/.venv/Scripts/python.exe'
env=os.environ.copy(); env.pop('PYTHONPATH',None); env.pop('PYTHONHOME',None)
target=S/'wheel-reader-v14-venv'; assert not target.exists()
subprocess.run([str(P),'-m','venv',str(target)],check=True,env=env)
py=target/'Scripts/python.exe'
wheel=max((W/'apps/api/dist').glob('*.whl'),key=lambda p:p.stat().st_mtime)
subprocess.run([str(py),'-m','pip','install',str(wheel)+'[reader]'],check=True,env=env,cwd=V)
subprocess.run([str(py),'-m','pip','check'],check=True,env=env,cwd=V)
probe=(V/'installed_reader_probe_v8.py').read_text(encoding='utf-8').replace('wheel-reader-v6-venv','wheel-reader-v14-venv').replace('reader-parts-v6','reader-parts-v13')
out=V/'installed_reader_probe_v14.py'; assert not out.exists(); out.write_text(probe,encoding='utf-8')
for name in ['minilm','roberta']:
 with (V/('v14-installed-'+name+'.log')).open('wb') as log:
  subprocess.run([str(py),str(out),'--reader',name],check=True,env=env,cwd=V,stdout=log,stderr=subprocess.STDOUT)
print('Fresh outside-checkout reader installation and both cached CPU API probes passed.')
