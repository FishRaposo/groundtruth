"""Run installed, cached reader/API checks outside the source checkout."""
from pathlib import Path
import argparse
import asyncio
import json
import os

parser = argparse.ArgumentParser()
parser.add_argument('--reader', choices=['minilm', 'roberta'], required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
revision = '934656cdda79824eabf503ed56e15c01ddbdbe3f' if args.reader == 'minilm' else 'adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'
model = 'minilm-uncased-squad2' if args.reader == 'minilm' else 'roberta-base-squad2'
for key in list(os.environ):
    if key.startswith(('OPENAI_', 'ANTHROPIC_', 'AZURE_OPENAI_', 'GOOGLE_API', 'GEMINI_')):
        del os.environ[key]
os.environ.update(DATABASE_URL='sqlite+aiosqlite:///:memory:', EMBEDDING_MODE='deterministic', EMBEDDING_DIMENSIONS='384', GENERATION_MODE='extractive', INGESTION_MODE='inline', AUTH_ENABLED='false', APP_ENV='development', RATE_LIMIT_ENABLED='false', ANSWER_SELECTION_MODE='reader', READER_MODEL_PATH=str(root/'models'/f'{model}--{revision}'), READER_MODEL_REVISION=revision, READER_NULL_THRESHOLD='0', STORAGE_ROOT=str(root/'coverage-v3'/f'installed-{args.reader}-uploads'), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false')

import app
import app.main
import httpx
from importlib.resources import files
from app.portfolio import load_corpus
from app.db.migrate import migrate
from app.db.session import async_engine
assert 'wheel-reader-v14-venv' in app.__file__ and 'site-packages' in app.__file__
assert len(load_corpus()['cases']) == 100
assert len(load_corpus(files('app.portfolio')/'assets/coverage-development')['cases']) == 80
assert len(load_corpus(files('app.portfolio')/'assets/coverage-blind-canonical-v3')['cases']) == 200
current = load_corpus(files('app.portfolio')/'assets/coverage-development-v3')
assert len(current['cases']) == 80
assert current['manifest']['manifest_sha256'] == '62071bb0298c0bf7322b26db9d74bd7e163bcb1d15a57caf95341cf5e0854e22'

async def exercise():
    await migrate()
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app.main.app), base_url='http://installed-wheel.local') as client:
        text = 'Harbor coordinator Anika authorizes the bridge opening after quay clearance.'
        upload = await client.post('/api/documents/upload', files=[('files', ('bridge.txt', text.encode(), 'text/plain'))])
        assert upload.status_code == 200, upload.text
        document = upload.json()['documents'][0]
        response = await client.post('/api/queries', json={'question':'Who authorizes the bridge opening?', 'document_ids':[document['id']], 'retrieval_method':'keyword'})
        assert response.status_code == 200, response.text
        row = response.json()
        assert row['outcome'] == 'completed' and 'Anika' in row['answer'], row
        assert row['provenance']['answer_selection']['revision'] == revision
        assert row['provenance']['answer_selection']['threshold'] == 0
        assert row['provenance']['answer_selection']['contract'] == 'reader-parts-v13'
        for source in row['sources']:
            assert source['answer_spans']
            for span in source['answer_spans']:
                assert source['quoted_text'][span['start']:span['end']] == span['text']
        history = await client.get('/api/queries/'+row['id'])
        assert history.status_code == 200 and history.json()['sources'] == row['sources']
        source = await client.get('/api/queries/'+row['id']+'/sources/1')
        assert source.status_code == 200
        print(json.dumps({'status':'installed_api_reader_functional_probe_passed_not_quality_acceptance','reader':args.reader,'revision':revision,'threshold':0,'packaged_case_counts':[100,80,200,80],'exact_spans':True,'actual_upload_query_history_source':True,'offline_model_assets':True}))
    await async_engine.dispose()

asyncio.run(exercise())
