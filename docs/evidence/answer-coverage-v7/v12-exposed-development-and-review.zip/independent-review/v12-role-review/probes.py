"""Exact AST role/procedure normalizer probes; no model/API imports."""
import ast
import json
from pathlib import Path
import re
import sys
O=Path(__file__).resolve().parent
def functions(filename):
    tree=ast.parse((O/filename).read_text(encoding='utf-8'))
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'nominal_role_question','reader_question'}]
    namespace={'re':re}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),filename,'exec'),namespace)
    return namespace['reader_question']
current=functions('answer_reader.py')
baseline=functions('baseline-answer_reader.py')
rows=[]
def check(name,question,expected):
    observed=current(question)
    rows.append({'name':name,'question':question,'expected':expected,'observed':observed,'baseline_observed':baseline(question),'passed':observed==expected})
for name,question in [
    ('locative_context_is_not_the_object_of_intake','At the Willow clinic, What is the responsible intake role?'),
    ('temporal_context_is_not_the_object_of_review','On Monday, What is the responsible final review role?'),
    ('role_genitive_is_not_the_activity_object','What is the responsible review role of the Willow coordinator?'),
]:
    check(name,question,question)
check('regarding_object_control','Regarding the Willow panel, What is the responsible review role?','Which role is responsible for the review of the Willow panel?')
check('for_object_control','What is the responsible review role for the Willow panel?','Which role is responsible for the review of the Willow panel?')
check('topic_and_activity_qualifiers_control','Regarding the Willow panel after shutdown, What is the responsible final safety review role?','Which role is responsible for the final safety review of the Willow panel after shutdown?')
check('negative_qualifier_is_retained','Regarding the Willow panel without emergency override, What is the responsible review role?','Which role is responsible for the review of the Willow panel without emergency override?')
check('conditional_topic_is_retained','Regarding the Willow panel if its latch is sealed, What is the responsible final review role?','Which role is responsible for the final review of the Willow panel if its latch is sealed?')
for question in [
    'What is the responsible review role for the person who operates Willow?',
    'What is the role that is not responsible for reviewing Willow?',
    "What is the responsible review role's training duration?",
]:
    check('embedded_or_other_role_predicate_unchanged',question,question)
for question in [
    'Walk me through how to inspect the Willow panel after shutdown.',
    'I am preparing the Willow panel after shutdown. Copy the entire procedure in its stated order.',
    'Give every step, in order, for checking the Willow panel after shutdown.',
]:
    check('old_procedural_normalizer_preserved',question,baseline(question))
auxiliary='What is the responsible review role for Willow, and can it delegate?'
result={'assertions':rows,'auxiliary_interrogative_observation':{'question':auxiliary,'output':current(auxiliary),'scope':'Informational only: upstream request splitting is not exercised here.'}}
print(json.dumps(result,indent=2))
(O/'probe-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not r['passed'] for r in rows) else 0)
