# V12 bounded role-preparation review

2026-10-24. Read-only review of nominal_role_question/reader_question and new test_reader_role_preparation.py, compared with the reviewed v11 recheck snapshot. One material relationship-preservation defect remains in this source snapshot, reproduced by three independent forms. No application/test/corpus/evidence edits, real model/API/service execution or seed/corpus access occurred.

## Finding

**P2 — The normalizer turns contextual and genitive relationships into an activity object.** answer_reader.py:101 accepts Regarding/For/At/In/On prefixes and :108 accepts suffix for/of; :123 then always emits `the ACTIVITY of TOPIC`. Retaining all topic words does not preserve their grammatical relationship:

- `At the Willow clinic, What is the responsible intake role?` becomes `Which role is responsible for the intake of the Willow clinic?`. Intake at a clinic is changed into intake of the clinic.
- `On Monday, What is the responsible final review role?` becomes `Which role is responsible for the final review of Monday?`. The weekday qualifier is changed into the reviewed object.
- `What is the responsible review role of the Willow coordinator?` becomes `Which role is responsible for the review of the Willow coordinator?`. A role belonging to the coordinator is changed into a review of that coordinator.

All three remain unchanged under the v11 normalizer. They are single questions and do not rely on a model, unusual tokenization, source labels or multi-question parsing. Prefix At/On role questions can reach the normalizer after ordinary request preparation, so the relationship change is not merely a display concern. No real QA result or quality score is asserted for these independent fixtures.

The described intended feature was limited to explicit Regarding-topic and role-for-topic forms; the added At/In/On and genitive-of alternatives exceed that equivalence assumption. Even within the allowed forms, carrying a topic as topical context is safer than assuming it must be the grammatical object of the activity.

## Controls and proposal assessment

Exact AST probes have14 assertions:3FAIL/11PASS (probes.py, probes.log, probe-result.json). They verify the intended Regarding/for object examples, complete activity/topic qualifier retention, a negative qualifier, a conditional topic, unchanged indirect who/other role relationships, and preservation of three existing public procedural normalizers. No model/package convenience imports are used: only the exact helper/reader_question AST functions and re execute.

Parent's proposed narrow repair preserves the topical preposition: Regarding/For TOPIC followed by `which role is responsible for the ACTIVITY?`; suffix for becomes an explicit For topical prefix; unknown At/In/On and genitive-of forms remain unchanged. That direction resolves the demonstrated relation problem without inventing an activity object. Conditions and negated qualifiers within TOPIC must retain their original order and scope. This is review of a proposal only, not a repaired-source verification. Earlier positive expectations and red/green logs for the flawed object-conversion contract must remain retained rather than rewritten as though they never passed.

An informational direct-helper observation is separately retained: `What is the responsible review role for Willow, and can it delegate?` is normalized, because the guard only recognizes WH words, not auxiliary interrogatives. The upstream request parser ordinarily splits can questions; no API decomposition or end-to-end defect was exercised here. If the standalone helper continues to promise every embedded further interrogative remains unchanged, that promise needs a corresponding bounded check or qualification. This observation is not counted as a second material product finding.

## Source binding and scope

Command: `C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe -B <this-directory>/probes.py`, PYTHONDONTWRITEBYTECODE=1: exit1 with the three exact failures above. Read-only diff, AST compilation and final hash/result verification completed successfully. All source/artifact text operations specify UTF-8. result-summary.json records counts and exact hashes.

The two scoped files match before=after, and the copied reader implementation matches those raw bytes. Answer reader SHA256 `a52417c63c993a5eb79ad1e4f7630f5a39f93e0cdffcd2164f800176f74b5455`; new role test SHA256 `8776c46055e265a1401885a91930bf585a691ff24bb5bb0359dc2ae19721c005`. source-before.json/source-after.json and exact baseline/current normalizer copies are retained.

The bounded diff changes deterministic preparation and metadata only; no additional QA attempt, threshold, source narrowing or extraction/access-policy change was found. This is not a broad integration/privacy audit. Input normalization does not establish factual entailment, and no purity/model-quality/completion claim follows from these tests. Parent owns preserving any active fixed-source observation before repair and obtaining a focused repaired-source recheck. Failed blind and later exposed-development status remain unchanged.
