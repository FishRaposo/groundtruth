import ast
import json
from pathlib import Path
import re
O=Path(__file__).resolve().parent
def normalizer(path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'nominal_role_question','reader_question'}]
    namespace={'re':re}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
    return namespace['reader_question']
current=normalizer(O/'answer_reader.py')
baseline=normalizer(O.parent/'baseline-answer_reader.py')
rows=[]
def check(name,question,expected):
    observed=current(question)
    rows.append({'name':name,'question':question,'expected':expected,'observed':observed,'passed':observed==expected})
for question in [
    'At the Willow clinic, What is the responsible intake role?',
    'On Monday, What is the responsible final review role?',
    'What is the responsible review role of the Willow coordinator?',
]:
    check('original_relationship_reproducer_unchanged',question,question)
check('regarding_relation_preserved','Regarding the Willow panel, What is the responsible review role?','Regarding the Willow panel, which role is responsible for the review?')
check('suffix_for_remains_topical','What is the responsible review role for the Willow panel?','For the Willow panel, which role is responsible for the review?')
check('prefix_for_relation_preserved','For the Willow panel, What is the responsible review role?','For the Willow panel, which role is responsible for the review?')
check('activity_and_topic_qualifiers_retained','Regarding the Willow panel after shutdown, What is the responsible final safety review role?','Regarding the Willow panel after shutdown, which role is responsible for the final safety review?')
check('negative_qualifier_retained','Regarding the Willow panel without emergency override, What is the responsible review role?','Regarding the Willow panel without emergency override, which role is responsible for the review?')
check('conditional_topic_retained','Regarding the Willow panel if its latch is sealed, What is the responsible final review role?','Regarding the Willow panel if its latch is sealed, which role is responsible for the final review?')
for question in [
    'What is the responsible review role for Willow, and can it delegate?',
    'What is the responsible review role for the person who operates Willow?',
    'What is the role that is not responsible for reviewing Willow?',
    "What is the responsible review role's training duration?",
]:
    check('embedded_or_other_predicate_unchanged',question,question)
for question in [
    'Walk me through how to inspect the Willow panel after shutdown.',
    'I am preparing the Willow panel after shutdown. Copy the entire procedure in its stated order.',
    'Give every step, in order, for checking the Willow panel after shutdown.',
]:
    check('old_procedural_normalizer_preserved',question,baseline(question))
print(json.dumps(rows,indent=2))
(O/'revised-contract-result.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not row['passed'] for row in rows) else 0)
