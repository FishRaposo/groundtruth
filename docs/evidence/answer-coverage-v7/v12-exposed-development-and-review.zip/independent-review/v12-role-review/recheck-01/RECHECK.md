# V12 role relationship finding — focused recheck01

2026-10-24. The retained material relationship-preservation finding is resolved in the exact current snapshot. No unresolved material finding remains within this focused role-preparation recheck. Earlier source copies, flawed positive expectations and all initial red observations remain unchanged; this record does not reinterpret them as though they never passed.

The three exact original reproducers now remain unchanged: At the Willow clinic, On Monday, and genitive role-of-the-Willow-coordinator. Regarding/For topics remain topical context in the revised QA question rather than being invented as the activity's object. Activity and topic qualifiers, negative qualifier and conditional topic remain in their original relation/order. The original auxiliary can-it-delegate informational witness now remains unchanged, as do the indirect who predicate and other role relationships. Three prior procedural normalizers retain their previous outputs.

## Retained and revised expectations

- An exact byte copy of the original14-assertion probe runs against this new snapshot: exit1,9PASS/5FAIL. All three original negative relationship assertions pass. The remaining five failures are the deliberately superseded role-positive strings that expected `activity of TOPIC`; they are preserved in original-expectations.log/probe-result.json. This is not reported as all original assertions passing.
- The explicit revised topical-preposition contract has16/16 passing assertions: recheck_probes.py, revised-contract.log, revised-contract-result.json, exit0. It includes the original three relationship failures, Regarding prefix, explicit For prefix, suffix-for topical mapping, topic/activity qualifiers, conditions/negation, auxiliary/indirect questions and old procedural forms.
- Hash/result verification: exit0. The original probe byte copy equals the retained original script. Two scoped files have matching source-before/source-after hashes, and the copied implementation equals those exact raw bytes.

All commands use C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe -B with PYTHONDONTWRITEBYTECODE=1 and explicit UTF-8 source/artifact operations. Only the exact nominal_role_question and reader_question AST functions execute, with re as their supporting namespace. No real model, API, service, corpus, seed, network or database access occurs.

Raw SHA256: answer_reader `6b7500bcd7f8fc012d844ea57aa4cc0c8c521d7e918210b1c8d24080c4e423b0`; role tests `d11cad38798143a8888177de1f5d9e818ab93f05e047f0f9937b1d7eac165b4c`. Exact records are source-before.json/source-after.json and result-summary.json. The original source/expectation evidence remains in the parent v12-role-review directory.

No application/test/corpus/evidence/staging changes were made by this reviewer. This finite grammar review does not certify equivalence for arbitrary language, entailment, QA selection or complete multi-document answers. Any earlier measured V12 result belongs to its original pre-fix source and is not a measurement of this fix. Parent owns any later source-bound exposed-development observation; failed blind status, open acceptance and lack of release/quality approval remain unchanged.
