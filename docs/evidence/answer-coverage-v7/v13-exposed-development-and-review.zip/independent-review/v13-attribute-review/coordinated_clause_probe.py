"""Proportional selected-clause and multi-document/citation-cap controls."""
import json
import os
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
W=O.parents[2]/'delivery-worktree'
os.environ.update(DATABASE_URL='sqlite+aiosqlite:///:memory:',EMBEDDING_MODE='legacy',GENERATION_MODE='extractive',ANSWER_SELECTION_MODE='reader',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OPENAI_API_KEY='')
sys.path.insert(0,str(W/'apps/api'))
services=types.ModuleType('app.services')
services.__path__=[str(O/'current/apps/api/app/services'),str(W/'apps/api/app/services')]
sys.modules['app.services']=services
from app.services.answer_reader import LocalReader,ReaderSelection,passage_span
from app.services.reader_attributes import attribute_features
from app.services.reader_witnesses import select_witness_cover

q='For Aurora, What is the responsible review role?'
sources=['The Aurora inspection is owned by the seal reviewer.', 'The Aurora review covers four seals, but the reservations are handled by the scheduler.']
raw=['seal reviewer','scheduler']
local=LocalReader()
calls=[]
def prediction(question,context,config):
    i=sources.index(context)
    start=context.index(raw[i])
    calls.append(i)
    return ReaderSelection(passage_span(context,start,start+len(raw[i])),{'decision':'answer','null_margin':[-10,-4][i],'raw_span':{'start':start,'end':start+len(raw[i])}})
local._context=prediction
selections=local._parts(q,sources,object())
assert all(s.span is not None for s in selections)
cover=select_witness_cover(selections)
rows=[{'name':'coordinated-selected-clause-borrowing','question':q,'sources':sources,'raw':raw,'margins':[-10,-4],'both_accepted':True,'attribute_features':[s.diagnostics['parts'][0]['attribute_evidence'] for s in selections],'selected':cover.indices,'expected_without_cross_clause_borrowing':(0,),'passed':cover.indices==(0,)}]
for count,expected in [(3,(0,1,2)),(4,())]:
    values=[ReaderSelection(passage_span('witness',0,7),{'part_count':count,'covered_parts':[i],'parts':[{'index':i,'null_margin':-4}]}) for i in range(count)]
    result=select_witness_cover(values)
    assert result.indices==expected
    rows.append({'name':f'{count}-document-cover-cap3','selected':result.indices,'passed':True})
assert len(calls)==2
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'coordinated-clause-result.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
raise SystemExit(any(not r['passed'] for r in rows))
