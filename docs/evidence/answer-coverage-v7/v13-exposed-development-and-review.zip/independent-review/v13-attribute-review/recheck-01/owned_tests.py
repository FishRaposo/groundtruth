"""Run only the copied scoped pure/model-seam unit tests, without repo conftest."""
import os
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
W=O.parents[3]/'delivery-worktree'
os.environ.update(DATABASE_URL='sqlite+aiosqlite:///:memory:',EMBEDDING_MODE='legacy',GENERATION_MODE='extractive',ANSWER_SELECTION_MODE='reader',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OPENAI_API_KEY='')
sys.path.insert(0,str(W/'apps/api'))
services=types.ModuleType('app.services')
services.__path__=[str(O/'current/apps/api/app/services'),str(W/'apps/api/app/services')]
sys.modules['app.services']=services
import pytest
result=pytest.main(['--noconftest','--confcutdir',str(O),'-o','addopts=','-p','no:cacheprovider','-q',str(O/'current/apps/api/tests/test_reader_attribute_witnesses.py'),str(O/'current/apps/api/tests/test_reader_request_intent.py')])
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
raise SystemExit(result)

