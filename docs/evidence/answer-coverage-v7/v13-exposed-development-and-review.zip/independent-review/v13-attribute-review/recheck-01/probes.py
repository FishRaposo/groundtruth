"""Deterministic model seam; no model, corpus, API, or live database use."""
import json
import os
from pathlib import Path
import sys
import types

O = Path(__file__).resolve().parent
W = O.parents[3] / 'delivery-worktree'
os.environ.update(DATABASE_URL='sqlite+aiosqlite:///:memory:', EMBEDDING_MODE='legacy', GENERATION_MODE='extractive', ANSWER_SELECTION_MODE='reader', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', OPENAI_API_KEY='')
sys.path.insert(0, str(W / 'apps/api'))
services = types.ModuleType('app.services')
services.__path__ = [str(O / 'current/apps/api/app/services'), str(W / 'apps/api/app/services')]
sys.modules['app.services'] = services
from app.services.answer_reader import LocalReader, ReaderSelection, passage_span
from app.services.reader_attributes import attribute_features
from app.services.reader_questions import question_parts
from app.services.reader_witnesses import select_witness_cover

rows = []
def check(name, actual, expected, *, category='control'):
    passed = actual == expected
    rows.append(dict(name=name, actual=actual, expected=expected, passed=passed, category=category))
    print(('PASS' if passed else 'FAIL') + ' ' + name + ': ' + repr(actual))

def feature(q, text, selected):
    start = text.index(selected)
    return attribute_features(q, text, {'start':start, 'end':start+len(selected)})

q = 'For Aurora, What is the responsible review role?'
text = '😀 The Aurora review is owned by the seal reviewer.'
check('unicode-codepoints-selected-clause', feature(q,text,'seal reviewer')['selected_clause_matches'], True)
text = 'Aurora review notes. The scheduler handles reservations.'
check('no-cross-sentence-borrow', feature(q,text,'scheduler')['selected_clause_matches'], False)
text = 'Aurora review notes; the scheduler handles reservations.'
check('no-cross-semicolon-borrow', feature(q,text,'scheduler')['selected_clause_matches'], False)
for raw in [None, {}, {'start':True,'end':4}, {'start':0,'end':False}, {'start':0.0,'end':3}, {'start':-1,'end':3}, {'start':0,'end':999}]:
    check('invalid-offset-'+repr(raw), attribute_features(q,text,raw)['selected_clause_matches'], False)
check('topic-is-not-attribute', feature('What is the normal inspection workload for Review?', 'The Review office books four hours.', 'four hours')['selected_clause_matches'],False)
check('negative-request-no-prior', feature('What is the not responsible review role for Aurora?', 'Aurora review is handled by scheduler.', 'scheduler')['requested'],False)
check('uppercase-genitive-no-prior',feature('What is the responsible review role OF Aurora?', 'Aurora review is handled by scheduler.', 'scheduler')['requested'],False)
check('regarding-topic', question_parts('Regarding Aurora, what is its owner?')[0].anchors, ('aurora',))
check('regarding-midname', question_parts('Who owns the Regarding queue?')[0].anchors, ('regarding',))

def cover(features, margins=(-4,-10), accepted=(True,True)):
    selections=[]
    for i, attr in enumerate(features):
        diagnostic={'index':0,'null_margin':margins[i]}
        if attr is not None:
            diagnostic['attribute_evidence']=attr
        selections.append(ReaderSelection(passage_span('source witness',0,14) if accepted[i] else None, {'part_count':1,'covered_parts':[0], 'parts':[diagnostic]}))
    return select_witness_cover(selections)

match={'contract':'explicit-selected-clause-attribute-v2','requested':True,'selected_clause_matches':True}
nomatch={'contract':'explicit-selected-clause-attribute-v2','requested':True,'selected_clause_matches':False}
check('known-matching-prior',cover([match,nomatch]).indices,(0,))
check('all-legacy-margin-fallback',cover([None,None]).indices,(1,))
check('mixed-legacy-margin-fallback',cover([match,None]).indices,(1,),category='compatibility-finding')
check('custom-unknown-contract-margin-fallback',cover([{'contract':'custom-future','requested':True,'selected_clause_matches':True},None]).indices,(1,),category='compatibility-finding')
check('missing-margin-keeps-coverage',cover([match,None],margins=(-4,None)).indices,(0,))
check('nonfinite-margin-keeps-coverage',cover([match,None],margins=(-4,float('inf'))).indices,(0,))
check('null-never-promoted',cover([match,nomatch],accepted=(False,True)).indices,(1,))
check('tie-original-order',cover([match,match],margins=(-4,-4)).indices,(0,))

# Actual _parts + actual cover, with deterministic QA predictions only.
sources=['The Aurora review is owned by the seal reviewer.', 'The reservations scheduler accepts reservations for Aurora.']
local=LocalReader()
local._load=lambda *a,**kw: (_ for _ in ()).throw(AssertionError('Forbidden model load'))
calls=[]
def prediction(question,context,config):
    i=sources.index(context)
    selected=['seal reviewer','reservations scheduler'][i]
    start=context.index(selected)
    calls.append((question,i))
    return ReaderSelection(passage_span(context,start,start+len(selected)), {'decision':'answer','null_margin':[-4,-10][i], 'raw_span':{'start':start,'end':start+len(selected)}})
local._context=prediction
selected=local._parts(q,sources,object())
check('actual-parts-retains-both-accepted', [s.span is not None for s in selected], [True,True])
check('actual-parts-attribute-witness',select_witness_cover(selected).indices,(0,))
check('actual-parts-no-retry-count',len(calls),2)
check('actual-parts-immutable-exact-span',all(s.span.text == sources[i][s.span.start:s.span.end] for i,s in enumerate(selected)),True)

# Honest surface-prior limitations, recorded rather than assumed entailment.
for name,source in [
    ('negated-clause','The Aurora review is not owned by the scheduler.'),
    ('conditional-clause','If the Aurora review were delegated, the scheduler would own it.'),
    ('coordinated-other-attribute','The Aurora review uses a seal, and the scheduler accepts reservations.'),
]:
    result=feature(q,source,'scheduler')
    rows.append(dict(name=name, category='literal-prior-limitation', observed=result))

check('no-model-libraries',any(n in sys.modules for n in ('torch','transformers')),False)
(O/'probe-result.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
failures=sum(r.get('passed') is False for r in rows)
print(f'{sum(r.get("passed") is True for r in rows)} PASS, {failures} FAIL; {sum(r.get("category")=="literal-prior-limitation" for r in rows)} informational limitations')
raise SystemExit(bool(failures))

