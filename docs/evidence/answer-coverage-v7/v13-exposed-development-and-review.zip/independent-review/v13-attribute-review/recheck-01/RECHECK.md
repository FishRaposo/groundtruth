# V13 findings — focused recheck01

2026-10-24. Both retained material findings are resolved in the current snapshot. No additional material finding remains within this focused recheck. Original REVIEW.md, source snapshots, probes and failing logs in the parent directory remain unchanged.

## Finding accumulator

- **Mixed legacy/custom diagnostic fallback — resolved.** The shared attribute contract is now `explicit-selected-clause-attribute-v2`. `reader_witnesses.py` requires every scored candidate for that part to have that current contract and `requested is True` before enabling the new prior. Exact retained mixed-legacy and unknown-custom assertions now select candidate1 by margin, as expected. All-legacy, missing/nonfinite margin, null and tie controls remain passing. The current-contract matching-prior control still selects candidate0.
- **Comma-but selected-clause borrowing — resolved.** The exact deterministic `_parts`/cover fixture now marks neither candidate as a literal attribute match and retains candidate0 by raw-margin fallback. Both original QA spans remain accepted; no rejection, retry, input crop or added QA call is introduced. Three-document cover and four-indispensable-document cap controls remain passing.

## Actual verification

All Python commands use the existing original `.venv/Scripts/python.exe -B`, with explicit UTF-8 and bytecode writes disabled. Imports resolve the seven copied current files, with unchanged dependencies from the isolated worktree. No repository conftest is loaded. Each command exits0:

- `probes.py`:28PASS/0FAIL plus3 informational surface-prior observations. This is the retained assertion set with only its bootstrap path adjusted for the new subdirectory and its positive diagnostic fixture updated from contract-v1 to current contract-v2. Assertion expectations are unchanged. The original script/log was not rewritten.
- `coordinated_clause_probe.py`:3PASS/0FAIL; only the bootstrap path changes from the retained script.
- `owned_tests.py`:33PASS in0.88s, both copied scoped unit-test files, pytest cache disabled. Only bootstrap path changes.
- `boundary_controls.py`:18PASS/0FAIL. Checks comma-and/but/or/yet/whereas/while/although/because and bare contrast/subordination boundaries; raw spans crossing an explicit boundary; same-predicate noun `and`/`or`, appositive commas and astral-Unicode offset control retaining legitimate local matches.
- Seven live-source before/after hashes match, and all snapshot files are byte-identical to those hashes: exit0. See source-before.json/source-after.json.

Key hashes: attributes `e59135005a96460cdfd1cdea0aee85b1b15a4b91b2dde3c57e3bd2b937d70cd7`; witnesses `012bc237620cbe3c26998ec1ba64319968ea2830b7e94ff3b09a44ebe19c22b4`; answer-reader `2df375063b124cdaff77c6faf21d6f9d7ec745708d4517b6330bf2ce1760f46d`. Question/support dependencies remain unchanged from the original review. Current metadata is reader-parts-v13 / strongest-accepted-part-witness-v5.

## Remaining limits

The new helper is a bounded punctuation/conjunction segmenter, not a syntax parser. Literal matches can remain true inside a negated or hypothetical clause and bare coordinated independent clauses without its recognized boundaries. This is still a ranking prior among already accepted predictions and does not establish entailment or support. A dropped prior preserves accepted-span margin fallback; it does not certify that fallback's factual answer. No arbitrary grammar expansion was attempted.

No models, actual APIs, services, database sessions, corpus, seed, results or future authoring data were accessed. No app/test/evidence/staging changes were made. This is a finite regression recheck, not a quality, privacy, completeness, release or blind-gate pass. Earlier failed measurements remain attached to their original source; parent owns subsequent source-bound observations.
