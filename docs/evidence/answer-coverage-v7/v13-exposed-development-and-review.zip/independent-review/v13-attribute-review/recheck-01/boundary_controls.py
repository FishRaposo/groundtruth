"""Bounded new clause-split controls; no language/model generalization claim."""
import json
import os
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
W=O.parents[3]/'delivery-worktree'
os.environ.update(DATABASE_URL='sqlite+aiosqlite:///:memory:',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
sys.path.insert(0,str(W/'apps/api'))
services=types.ModuleType('app.services')
services.__path__=[str(O/'current/apps/api/app/services'),str(W/'apps/api/app/services')]
sys.modules['app.services']=services
from app.services.reader_attributes import attribute_features
q='For Aurora, What is the responsible review role?'
rows=[]
for connector in [', and ', ', but ', ', or ', ', yet ', ', whereas ', ', while ', ', although ', ', because ', ' but ', ' whereas ', ' although ', ' while ', ' because ']:
    source='The Aurora review covers four seals'+connector+'the reservations are handled by the scheduler.'
    start=source.index('scheduler')
    value=attribute_features(q,source,{'start':start,'end':start+9})['selected_clause_matches']
    rows.append({'name':'explicit-clause-'+repr(connector),'actual':value,'expected':False,'passed':value is False})
for source,raw in [
    ('The Aurora review is owned by the seal reviewer and the scheduler.','scheduler'),
    ('The Aurora review is owned by the seal reviewer or the scheduler.','scheduler'),
    ('The Aurora review owner, the scheduler, inspects each seal.','scheduler'),
    ('😀 The Aurora review is owned by the seal reviewer and the scheduler.','scheduler'),
]:
    start=source.index(raw)
    value=attribute_features(q,source,{'start':start,'end':start+len(raw)})['selected_clause_matches']
    rows.append({'name':'same-predicate-noun-'+source,'actual':value,'expected':True,'passed':value is True})
source='The Aurora review owner is the reviewer, but the scheduler handles reservations.'
start=source.index('reviewer')
end=source.index('scheduler')+9
value=attribute_features(q,source,{'start':start,'end':end})['selected_clause_matches']
rows.append({'name':'raw-span-crosses-explicit-boundary','actual':value,'expected':False,'passed':value is False})
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'boundary-controls-result.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'{sum(r["passed"] for r in rows)} PASS / {sum(not r["passed"] for r in rows)} FAIL')
raise SystemExit(any(not r['passed'] for r in rows))
