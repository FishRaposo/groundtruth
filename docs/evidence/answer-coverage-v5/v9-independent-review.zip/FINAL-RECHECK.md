# V9 final bounded finding accumulator

2026-10-24. No unresolved material finding remains within the explicitly bounded request/scope/deadline review. This is not a claim about model quality, entailment, release readiness or unseen acceptance. Failed blind-v4 and all earlier red evidence remain unchanged and exposed.

The seven findings are preserved in their original records:

| Finding | Original evidence | Final bounded status |
| --- | --- | --- |
| Capitalized Identify drops shared entity | REVIEW.md1, current-result.json | Exact retained assertion passes |
| Second nominal sentence fuses requests | REVIEW.md2, current-result.json | Exact retained assertion passes; owner/day/time separate |
| Mid-question Copy proper name discarded | REVIEW.md3, current-result.json | Exact retained assertion passes |
| Pay attention falsely treated as monetary | REVIEW.md4, current-result.json | Exact retained assertion passes |
| Physical outside-room misread as scope exclusion | REVIEW.md5, current-result.json | Exact retained assertion passes |
| Euro/en-dash regex mojibake | REVIEW.md6, current-encoding-result.json | Both exact Unicode assertions pass |
| Earlier duration confused with later identical deadline | RECHECK.md, recheck-control-result.json | Exact retained first-occurrence assertion passes; later deadline still rejected |

The final deadline helper accepts canonical context and offsets, locates the selected clause, and compares the selected start against actual matched until-interval positions. It no longer tests raw-string membership. Direct inspection found the intended narrow offset repair in the two helper files. Actual elapsed duration remains eligible even when its text repeats in a later deadline, while the deadline occurrence and explicit deadline question retain their expected behavior.

Using exact quiet-source copies retained under final/app/services, all17 assertions passed:

- `P -B probe.py final`: exit0,8 retained original request/scope assertions, final-original-probes.log.
- `P -B encoding_probe.py final`: exit0,2 retained Unicode currency/time assertions, final-encoding.log.
- `P -B final_controls.py`: exit0,7 retained qualifier/entity/deadline controls, final-controls.log. This is an exact copy of the earlier controls with only snapshot/output paths changed.

P is `C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe`. PYTHONDONTWRITEBYTECODE=1. Probes import only the two pure helper modules through synthetic package paths, bypassing unrelated service package convenience imports. No API, model, network, service or corpus execution occurred. No additional grammar cases were added in this final pass.

An initial shell quoting failure prevented snapshot preparation; the follow-on module/file-not-found outputs are retained as final-*-setup-failure.log. The setup was moved into final_setup.py, which completed exit0; the actual three verification commands then completed exit0. This was a scratch harness failure, not an application/test failure, and no production file was changed by the reviewer.

Final source-before.json/source-after.json equality was checked for all5 scoped files, and the retained implementation copy digests also match. Exact details: final-source-before.json, final-source-after.json and final-result-summary.json. Reader questions SHA256 `ae0a6a15f70a8d9e1181d05d8dc2f489290abc7108a4b5a70fbebaae8a5f2096`; support `3e3bd4fef54136a746a507336aef33346136911bdda43e23736c7bd8b59a9f73`; answer-reader metadata `ff560b8fb8742afc685356c3e490f99aa3b255a78208aea7c685e326453fa3a3`.

Limits remain: surface preparation/guards do not certify factual entailment; these controls use exact selected spans and do not measure real QA selection or end-to-end completeness. No broader application or arbitrary grammar review was performed. Parent owns source freeze and any later source-bound development checks; this record supplies no new blind-quality result.
