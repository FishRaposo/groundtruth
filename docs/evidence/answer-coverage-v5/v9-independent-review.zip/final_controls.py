import json
from pathlib import Path
import sys
import types
root = Path(__file__).resolve().parent/'final'
for package, relative in [('app','app'),('app.services','app/services')]:
    module = types.ModuleType(package)
    module.__path__ = [str(root/relative)]
    sys.modules[package] = module
from app.services.reader_questions import question_parts, mismatch_reason
checks = []
def check(name, passed, observed):
    checks.append({'name':name,'passed':passed,'observed':observed})
for prefix, q in [('preposed','For the Willow panel in the dry room, identify the owner and duration.'),('postposed','Identify the owner and duration for the Willow panel in the dry room.')]:
    parts = question_parts(q)
    check(prefix+'_location_qualifier',all('dry room' in p.question and 'willow' in p.anchors for p in parts),[p.question for p in parts])
parts = question_parts('Who owns the Willow panel, and who owns the Borealis panel?')
check('separate_entities_do_not_merge',len(parts)==2 and parts[0].anchors==('willow',) and parts[1].anchors==('borealis',),[p.anchors for p in parts])
source = 'The Willow reviewer works four days and takes reservations until four days before the session.'
raw = 'four days'
first = source.index(raw)
last = source.rindex(raw)
actual = mismatch_reason('How long does the Willow reviewer work?',source,first,first+len(raw))
check('first_actual_duration_is_not_later_identical_deadline',actual is None,actual)
actual = mismatch_reason('How long does the Willow reviewer work?',source,last,last+len(raw))
check('later_deadline_still_rejected',actual is not None,actual)
actual = mismatch_reason('How long before the Willow session must I reserve?',source,last,last+len(raw))
check('deadline_question_keeps_interval',actual is None,actual)
source = 'The Willow reviewer works three days and takes reservations until four days before the session.'
raw = 'three days'
start = source.index(raw)
actual = mismatch_reason('How long does the Willow reviewer work?',source,start,start+len(raw))
check('nonidentical_duration_control',actual is None,actual)
print(json.dumps(checks,indent=2))
Path(__file__).with_name('final-control-result.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not x['passed'] for x in checks) else 0)
