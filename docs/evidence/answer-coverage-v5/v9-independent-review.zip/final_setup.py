import hashlib
import json
from pathlib import Path
O = Path(__file__).resolve().parent
W = O.parents[2]/'delivery-worktree'
D = O/'final/app/services'
D.mkdir(parents=True,exist_ok=True)
for name in ['reader_questions.py','reader_support.py']:
    (D/name).write_bytes((W/'apps/api/app/services'/name).read_bytes())
names = ['apps/api/app/services/reader_questions.py','apps/api/app/services/reader_support.py','apps/api/app/services/answer_reader.py','apps/api/tests/test_reader_request_boundaries.py','apps/api/tests/test_reader_scope_exclusion.py']
(O/'final-source-before.json').write_text(json.dumps({n:hashlib.sha256((W/n).read_bytes()).hexdigest() for n in names},indent=2),encoding='utf-8')
source = (O/'recheck_controls.py').read_text()
assert source.count("parent/'recheck'") == 1
source = source.replace("parent/'recheck'","parent/'final'").replace('recheck-control-result.json','final-control-result.json')
(O/'final_controls.py').write_text(source,encoding='utf-8')
print('Final snapshot and unchanged control assertions prepared.')
