# V9 repaired-source recheck

2026-10-24, subsequent to REVIEW.md. Original failures, logs and source copies are retained unchanged. This recheck uses exact later quiet-source copies in `recheck/app/services/` and does not edit application/tests or invoke a model/API/service/corpus measurement.

All10 retained original assertions pass: `probe.py recheck` exit0 (8assertions) and `encoding_probe.py recheck` exit0 (2assertions). The second sentence now retains three separate owner/day/time parts, shared Willow topic is preserved, the named Copy queue remains constrained, pay-attention and physical outside-room facts remain eligible, actual procedure exclusion still rejects, and original euro/en-dash codepoints work. This independently confirms the specific six original findings were addressed at this source snapshot; it is not a model-quality claim.

One additional material false rejection remains in the newly introduced deadline boundary:

**P2: Repeated text is used instead of selected offsets when classifying a deadline.** In `recheck/app/services/reader_support.py:46-52`, deadline_duration_mismatch returns true when the selected raw string occurs anywhere within `until ... before/after`, regardless of which occurrence was selected. Source:

`The Willow reviewer works four days and takes reservations until four days before the session.`

Question: `How long does the Willow reviewer work?`

Selecting the FIRST `four days` (the stated work duration) incorrectly returns `relative_deadline_is_not_elapsed_duration`. Selecting the later `four days` correctly rejects it as a reservation deadline. Replacing the first duration with `three days` removes the erroneous rejection, while preserving the rest of the sentence. This isolates textual duplication as the cause. The API already has exact raw offsets, so the scope classification must refer to the selected occurrence rather than text membership. No claim is made about a real QA model choosing either span; this is a deterministic guard outcome for exact input offsets.

The bounded `recheck_controls.py` run returns exit1 with1FAIL/6PASS. Controls preserve preposed and postposed dry-room qualifiers, separate Willow/Borealis entities, reject the actual later deadline, allow an explicit advance-deadline question and allow a nonidentical actual duration. Logs and observed values are retained in `recheck-controls.log` and recheck-control-result.json. No additional grammar expansion was attempted.

Source-before/source-after hashes match for all5 scoped files during this recheck. New raw implementation hashes: reader_questions `b03e138718125fc5f8e117bd9bd872bf1fa346ca28559c89c80dae1b22dc7920`; reader_support `37872709c0e16e652fb7d3907b7e0dabdbed5ae78aea9185cd53d38dd57379a0`; answer_reader metadata contract snapshot `ff560b8fb8742afc685356c3e490f99aa3b255a78208aea7c685e326453fa3a3`. Exact test hashes are in recheck-source-before.json/recheck-source-after.json. Retained snapshot implementation digests were independently checked after the probes.

No blind-v4 bytes, scoring, labels or failed outcome were changed. This record gives no release/quality verdict. The parent owns any narrow deadline fix and subsequent source-bound development checks.
