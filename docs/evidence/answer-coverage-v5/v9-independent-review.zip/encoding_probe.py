import json
from pathlib import Path
import sys
import types
version = sys.argv[1]
root = Path(__file__).resolve().parent/version
for package, relative in [('app','app'),('app.services','app/services')]:
    module = types.ModuleType(package)
    module.__path__ = [str(root/relative)]
    sys.modules[package] = module
from app.services.reader_questions import mismatch_reason
source = 'The Willow review fee is \u20ac18.'
raw = '\u20ac18'
start = source.index(raw)
currency = mismatch_reason('What is the Willow review fee?',source,start,start+len(raw))
source = 'The Willow review session runs 18:10\u201318:40.'
raw = '18:10\u201318:40'
start = source.index(raw)
interval = mismatch_reason('What is the number of review items for Willow?',source,start,start+len(raw))
results = [{'name':'bare_euro_fee_remains_eligible','passed':currency is None,'observed':currency},{'name':'en_dash_interval_cannot_establish_count','passed':interval is not None,'observed':interval}]
print(json.dumps(results,indent=2))
Path(__file__).with_name(version+'-encoding-result.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not x['passed'] for x in results) else 0)
