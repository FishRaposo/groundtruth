"""Independent pure preparation/guard probes; no model or API imports."""
import json
from pathlib import Path
import sys
import types
version = sys.argv[1]
root = Path(__file__).resolve().parent/version
for package, relative in [('app','app'),('app.services','app/services')]:
    module = types.ModuleType(package)
    module.__path__ = [str(root/relative)]
    sys.modules[package] = module
from app.services.reader_questions import question_parts, scope_matches, mismatch_reason

result = []
def test(name, expected, observed, details=None):
    result.append({'name':name,'expected':expected,'observed':observed,'passed':expected==observed,'details':details})
def parts_details(parts):
    return [{'question':p.question,'anchors':p.anchors} for p in parts]

p = question_parts('Identify the review owner and deadline for the Willow panel.')
test('capitalized_identify_preserves_shared_named_topic',True,all('willow' in x.anchors for x in p),parts_details(p))
p = question_parts('Who owns the Willow panel? Also give the scheduled day and time.')
test('second_sentence_nominal_list_keeps_first_request_separate',True,len(p)==3 and all('?' not in x.question[:-1] for x in p),parts_details(p))
p = question_parts('Who owns the Copy queue?')
test('midquestion_capitalized_Copy_still_names_the_entity',False,scope_matches(p[0],'The Borealis queue owner is the steward.'),parts_details(p))
source = 'The Willow panel requires close attention.'
start = source.index('close attention')
actual = mismatch_reason('How much attention must I pay to the Willow panel?',source,start,start+len('close attention'))
test('pay_attention_is_not_a_monetary_request',None,actual)
source = 'For the Willow review, wait in the courtyard. This courtyard is outside the standard review room.'
start = source.index('courtyard')
actual = mismatch_reason('Where should the Willow reviewer wait during the standard review?',source,start,start+len('courtyard'))
test('physical_outside_room_does_not_exclude_waiting_instruction',None,actual)
p = question_parts('Please combine the review owner and deadline for the Willow panel.')
test('lowercase_combine_shared_topic_control',True,all('willow' in x.anchors for x in p),parts_details(p))
source = 'The Willow review costs 18 euros.'
start = source.index('18 euros')
test('actual_payment_control',None,mismatch_reason('What amount must I pay for the Willow review?',source,start,start+len('18 euros')))
source = 'For the Willow exception, attach the marker to the inner edge. This exception is outside the standard review procedure.'
start = source.index('inner edge')
test('actual_procedure_scope_exclusion_control',True,mismatch_reason('What are the steps for the Willow standard review?',source,start,start+len('inner edge')) is not None)
print(json.dumps(result,indent=2))
Path(__file__).with_name(version+'-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not x['passed'] for x in result) else 0)
