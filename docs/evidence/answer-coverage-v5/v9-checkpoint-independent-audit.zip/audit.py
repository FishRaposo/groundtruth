"""Offline checkpoint audit: no model, API, DB or service execution."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile
import re

O = Path(__file__).resolve().parent
V = O.parents[1]
S = V.parent
W = S/'delivery-worktree'
E = W/'docs/evidence/answer-coverage-v5'
E4 = W/'docs/evidence/answer-coverage-v4'
sys.path[:0] = [str(W/'apps/api'),str(W/'scripts')]
from app.portfolio import load_corpus
from verify_answer_coverage_delivery import audit_report, validate_headers

def sha(data):
    return hashlib.sha256(data).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git','-C',str(W),*args])
def blobs(queries):
    stream = io.BytesIO(subprocess.run(['git','-C',str(W),'cat-file','--batch'], input=('\n'.join(queries)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout)
    result = {}
    for q in queries:
        header = stream.readline().split()
        assert header[1] == b'blob',(q,header)
        result[q] = stream.read(int(header[2]))
        assert stream.read(1)==b'\n'
    return result

checkpoint = read(E/'v9-checkpoint.json')
results = {'archives':{},'source_bindings':{},'report_audits':{},'engineering':{}}
for sidecar in E.glob('*.sha256'):
    path = sidecar.with_name(sidecar.name.removesuffix('.sha256'))
    assert sha(path.read_bytes()) == sidecar.read_text().split()[0].lower(),path.name
results['checkpoint_sha256'] = sha((E/'v9-checkpoint.json').read_bytes())
before = {n:sha((W/n).read_bytes()) for n in checkpoint['source_files_sha256']}
assert before==checkpoint['source_files_sha256']
staged = blobs([':'+n for n in before])
assert all(staged[':'+n].replace(b'\r\n',b'\n')==(W/n).read_bytes().replace(b'\r\n',b'\n') for n in before)
results['source_bindings']['current_and_staged_canonical'] = len(before)
archive_payloads = {}
for record in checkpoint['archives']:
    path = E/record['file']
    assert sha(path.read_bytes())==record['sha256']
    with zipfile.ZipFile(path) as z:
        hashes = json.loads(z.read('archive-file-hashes.json'))
        assert len(hashes)==record['payloads']
        assert set(z.namelist()) == set(hashes)|{'archive-file-hashes.json'}
        for name,h in hashes.items():
            assert sha(z.read(name))==h,(path.name,name)
        archive_payloads[path.name] = {name:z.read(name) for name in hashes}
        results['archives'][path.name] = {'sha256':record['sha256'],'payloads':len(hashes)}
observations = archive_payloads['v9-exposed-development-observations.zip']
recorded_before = json.loads(observations['source-before.json'])
recorded_after = json.loads(observations['source-after.json'])
assert recorded_before==recorded_after==before
for source in ['answer_reader.py','reader_questions.py','reader_support.py']:
    assert observations['measured-source/'+source] == (W/'apps/api/app/services'/source).read_bytes()
for test in ['test_reader_request_boundaries.py','test_reader_scope_exclusion.py']:
    assert observations['measured-tests/'+test] == (W/'apps/api/tests'/test).read_bytes()
for label,corpus_name in [('prior-development-80','coverage-development-v3'),('exposed-v4-200','coverage-blind-v4')]:
    report = json.loads(observations[label+'-report.json'])
    assert sha(observations[label+'-report.json']) == observations[label+'-report.json.sha256'].decode().split()[0]
    assert report['evaluation_visibility'].startswith('EXPOSED DEVELOPMENT ONLY')
    assert report['selection_sha256'] is None and report['span_integrity_required']
    assert report['settings']['reader_null_threshold']==4
    assert report['settings']['reader_model_revision']=='adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'
    corpus = load_corpus(W/'apps/api/app/portfolio/assets'/corpus_name)
    audit = audit_report(report,corpus)
    assert audit == json.loads(observations[label+'-integrity.json'])
    summaries = {method:v['summary'] for method,v in report['results'].items()}
    assert summaries==checkpoint['results'][label]
    assert sum(len(x['cases']) for x in report['results'].values())==(320 if label=='prior-development-80' else 200)
    for summary in summaries.values():
        assert all(summary[key]==0 for key in ['execution_errors','unauthorized_source_exposures','citation_integrity_failures','span_integrity_failures'])
    if label=='prior-development-80':
        assert len(report['results'])==4
        assert all((s['answerable_correct'],s['negative_correct'])==(46,32) for s in summaries.values())
    else:
        assert set(report['results'])=={'reranked'}
        s=summaries['reranked']
        assert (s['answerable_correct'],s['negative_correct'],s['refusal_false_positives'])==(83,80,29)
        wrong=sum(r['category']=='answerable' and not r['refused'] and not r['answer_quality_passed'] for r in report['results']['reranked']['cases'])
        assert wrong==8
        try:
            validate_headers(read(E4/'first-baseline-blind-v4.json'),report)
        except ValueError as exc:
            results['blind_comparison_rejects_exposed_report'] = str(exc)
        else:
            raise AssertionError('Exposed reranked-only report became blind eligible')
    results['report_audits'][label] = audit
engineering=archive_payloads['v9-engineering-observations.zip']
assert b'552 passed, 1 skipped' in engineering['v9-full-python.log']
assert b'20 passed' in engineering['v9-script-tests.log']
assert b'0 errors, 0 warnings, 0 informations' in engineering['v9-final-types.log']
coverage=json.loads(engineering['v9-combined-coverage.json'])['totals']
assert coverage==checkpoint['python']['coverage']
assert (coverage['covered_lines'],coverage['num_statements'],coverage['percent_covered_display'])==(4919,7184,'68')
results['engineering']={'api_tests':552,'scripts':20,'skipped':1,'coverage':coverage,'final_pyright':'0errors'}
independent = archive_payloads['v9-independent-review.zip']
independent_summary=json.loads(independent['final-result-summary.json'])
assert independent_summary['retained_assertions_passed']==17
assert all(h==before[n] for n,h in independent_summary['source_hashes'].items())
for name in independent:
    original=V/'code-review/v9-request-scope-review'/name
    assert original.read_bytes()==independent[name],name
results['review_exact_original_payloads']=len(independent)
oldpaths=git('ls-tree','-r','--name-only','57e4128','docs/evidence/answer-coverage-v4').decode().splitlines()
rawpaths=[n for n in oldpaths if Path(n).suffix in {'.json','.sha256','.zip'}]
old=blobs(['57e4128:'+n for n in rawpaths])
assert all(old['57e4128:'+n]==(W/n).read_bytes() for n in rawpaths)
assert sha((E4/'first-comparison-seal.json').read_bytes())=='787ed5101e35aea4e583b150adc279592494ee06f1ffb0fc76c50043dddc5388'
assert read(E4/'first-comparison-gate.json')['gate']=='failed'
results['unchanged_v4_raw_artifacts_from_failed_commit']=len(rawpaths)
results['failed_first_gate_preserved']=True
readme=(E/'README.md').read_text()
links=re.findall(r'\]\(([^)]+)\)',readme)
assert all((E/link).exists() for link in links)
results['readme_local_links_verified']=len(links)
olddev=read(W/'docs/evidence/answer-coverage-v3/v8-development-all-methods.json')
newdev=json.loads(observations['prior-development-80-report.json'])
oldrows={x['case_id']:x for x in olddev['results']['reranked']['cases']}
regressions=[x for x in newdev['results']['reranked']['cases'] if oldrows[x['case_id']]['answer_quality_passed'] and not x['answer_quality_passed']]
assert len(regressions)==1 and regressions[0]['case_id']=='dev-v3-043'
reg=regressions[0]
parts=list(dict.fromkeys(p for c in reg['provenance']['answer_selection']['candidates'] for p in c.get('question_parts',[])))
assert parts[0]=='I am resetting the Oriel contour sand table?'
results['documented_regression']={'case_id':reg['case_id'],'refused':reg['refused'],'prepared_parts':parts}
assert {n:sha((W/n).read_bytes()) for n in before}==before
(O/'source-before.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
(O/'source-after.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
(O/'audit-result.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
