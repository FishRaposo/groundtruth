# V9 exposed-development checkpoint evidence audit

2026-10-24, bounded read-only audit of `docs/evidence/answer-coverage-v5`. No material discrepancy found in the checked checkpoint, reports, bindings or README. This is evidence consistency, not acceptance or application-quality approval. Earlier implementation findings and red logs remain preserved in their original review directory.

## Verified

- Checkpoint SHA256 `3fc3a8025745184b9eeef460fd9e15912b56e134534bad943459431154f9459f` agrees with its sidecar. All three archive digests match both sidecars and checkpoint. All90 payload SHA256 values and exact ZIP membership agree with their manifests (19HTTP+47review+24engineering).
- All155 recorded measured source/test/scorer hashes agree before=after=current. Current staged Git blobs equal those working files allowing only CRLF/LF representation. The five archived measured reader/test files equal their actual working bytes; the measured source includes the previously independently reviewed final helper hashes. All47 independent-review payloads equal their exact original scratch files.
- Independently re-scored all520 stored HTTP observations through the unchanged portable `audit_report`:320 rows from the80-case four-method run and200 from the reranked-only exposed-v4 run. Canonical case identities, immutable sources, fact/order checks, source/citation/span integrity and summary calculations all match the archived integrity records and checkpoint.
- Earlier80 development: all four methods46/48 correct positives and32/32 negatives. Exposed-v4 reranked:83/120 and80/80,29 false refusals and8 emitted wrong/incomplete positive answers. All520 rows have zero recorded execution/access/citation/span-integrity failures. None of these integrity totals certifies semantic entailment.
- Both report headers explicitly say EXPOSED DEVELOPMENT ONLY, retain original split solely for immutable identity, have null selection SHA256, and use pinned RoBERTa revision `adc3b06f79f797d1c575d5479d6f5efe54a9e3b4`, threshold4. The200-case report contains only reranked results. The original blind header validator rejects pairing it with the original baseline (`Comparison dataset or frozen selection differs`); it cannot become a qualifying blind comparison.
- All20 raw JSON/checksum/ZIP files under the committed failed-v4 packet are byte-identical to commit57e4128. Original seal SHA256 remains `787ed5101e35aea4e583b150adc279592494ee06f1ffb0fc76c50043dddc5388`; original gate remains FAILED. The later83/80 result has not replaced51/75.
- Stored full API log records552 passed/1skip; separate script log20 passed. Combined coverage JSON and checkpoint agree exactly:4919/7184 =68.47160356347439%, display68. Separate command scopes are correctly disclosed. Final archived configured Pyright log records0 errors; earlier179-error sandbox discovery output is preserved separately.
- README correctly discloses failure/exposure, one additional false refusal on the80-case set, remaining37 positive failures, no repeated frontend/package/browser gates and no owner-review promotion. The five local README links resolve. Comparing archived prior/current development responses confirms the one regressed positive is dev-v3-043; its diagnostics turn the declarative `I am resetting the Oriel contour sand table.` into a separate required question. This corroborates the stated demonstrated regression; its repair remains pending.

Archive SHA256 values:

- HTTP/development: `def2444757b0a5b906c82dc03ce9d41e21f6d42997f18908c514b6e724e26476`
- Independent review: `6f7cffb492b8a17f60a8cd6098e54b605f461d118075686e9c0854973d1c1e44`
- Engineering: `d861fef240ece10c0bc193ba56dca461a889ffda3aa3bf2e4ed2cc89ecb966be`

## Method and limits

Executed `C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe -B audit.py`, with PYTHONDONTWRITEBYTECODE=1, twice as the audit added the bounded README/regression checks: both exit0. Exact code, `audit.log`, `audit-final.log`, `audit-result.json` and155-file source-before/source-after maps are retained here. Stored observations are read directly from the preserved ZIP; the runner is inspected as text and never executed. No app/scorer/corpus/evidence files, staging or original review files were changed by the reviewer.

No model/API/service, comparison rerun, live/owner database access, full test suite or broader code review occurred. The archive runner uses read-only original SQLite connections to create disposable backups, asserts original database digests, starts only its own8410 API and logs completion; this reviewer did not independently open/re-hash the excluded original databases. Model assets were not reloaded/rehashed in this checkpoint audit. Ruff/format statements remain parent-observed gates; this audit did not rerun them. Existing earlier browser/package observations retain their original scope. The complete natural-language semantics of every label/answer were not newly reviewed; portable re-scoring verifies the declared synthetic contract.

The checkpoint is a coherent record of exposed post-failure development with known regressions still open. The failed unseen measurement remains failed. Parent owns any later repair, source-bound development checks, commit and future clean candidate freeze; this audit supplies no completion, release or unseen-quality verdict.
