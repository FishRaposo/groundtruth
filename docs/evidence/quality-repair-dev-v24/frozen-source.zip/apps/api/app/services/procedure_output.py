"""Versioned literal rendering and independent immutable source/output replay.

No classifier, tokenizer, retrieval or producer success flag is an authority here.
Callers supply actual request/output and separately resolved immutable snapshots.
"""

from __future__ import annotations

import hashlib
import uuid

from app.services.requirement_contract import PROCEDURE_COPY_CONTRACT as COPY_CONTRACT

RENDERER = "extractive-answer-v1"
OUTPUT_CONTRACT = "procedure-output-cover-v1"


def render_extractive(citations, groups=(), disclosures=()):
    """One renderer shared by publication and saved-answer verification."""
    indices = {str(c["chunk_id"]): c["citation_index"] for c in citations}
    extracts = []
    segments = {}
    for group in groups:
        extracts.append(
            group["text"]
            + " "
            + " ".join(f"[{indices[identifier]}]" for identifier in group["chunk_ids"])
        )
    for citation in citations:
        identifier, passage = str(citation["chunk_id"]), citation["quoted_text"]
        spans = citation.get("answer_spans") or []
        if not groups:
            extract = "\n".join(s["text"] for s in spans) if spans else passage
            extracts.append(f"{extract} [{citation['citation_index']}]")
            continue
        covered = sorted(
            (f["start"], f["end"])
            for g in groups
            for f in g["fragments"]
            if f["chunk_id"] == identifier
        )
        for span in spans:
            remaining = [(span["start"], span["end"])]
            for left, right in covered:
                remaining = [
                    (a, min(b, left)) for a, b in remaining if a < min(b, left)
                ] + [(max(a, right), b) for a, b in remaining if max(a, right) < b]
            extracts.extend(
                f"{passage[a:b]} [{citation['citation_index']}]"
                for a, b in remaining
                if passage[a:b].strip()
            )
    prefix = (
        "Source extracts with declared activity-scope interpretation:\n\n"
        if disclosures
        else "Source extracts (not model-generated):\n\n"
    )
    cursor = len(prefix)
    for group, extract in zip(groups, extracts, strict=False):
        segments[group["requirement_id"]] = {
            "start": cursor,
            "end": cursor + len(group["text"]),
        }
        cursor += len(extract) + 2
    return prefix + "\n\n".join([*extracts, *disclosures]), segments


def _source(proof, snapshots):
    from app.models.chunk import ChunkWithScore
    from app.services.procedure_evidence import (
        MAX_BODY_BYTES,
        MAX_CHUNKS,
        LocatedChunk,
        ProcedureSource,
    )

    snapshot = snapshots[proof["document_id"]]
    identity = {
        k: proof[k] for k in ("document_id", "document_version", "content_hash")
    }
    if "workspace_id" in proof:
        identity["workspace_id"] = proof["workspace_id"]
    if any(snapshot.get(k) != v for k, v in identity.items()):
        raise ValueError("Immutable identity mismatch")
    body = snapshot["body"]
    if (
        not isinstance(body, str)
        or body != proof["source_body"]
        or len(body) != proof["body_length"]
        or len(body.encode()) > MAX_BODY_BYTES
        or hashlib.sha256(body.encode()).hexdigest() != identity["content_hash"]
    ):
        raise ValueError("Immutable body mismatch")
    manifest = snapshot["chunks"]
    if not isinstance(manifest, list) or not 1 <= len(manifest) <= MAX_CHUNKS:
        raise ValueError("Immutable chunk budget")
    located, ids, indices = [], set(), set()
    for item in manifest:
        identifier, index, text = uuid.UUID(item["id"]), item["index"], item["content"]
        if (
            identifier in ids
            or type(index) is not int
            or index < 0
            or index in indices
            or not isinstance(text, str)
            or not text
        ):
            raise ValueError("Immutable chunk identity mismatch")
        start = body.find(text)
        if start < 0 or body.find(text, start + 1) >= 0:
            raise ValueError("Ambiguous immutable chunk mapping")
        chunk = ChunkWithScore(
            id=identifier,
            document_id=uuid.UUID(identity["document_id"]),
            content=text,
            chunk_index=index,
            relevance_score=0.0,
            metadata={**snapshot.get("metadata", {}), **identity},
        )
        located.append(LocatedChunk(chunk, start, start + len(text)))
        ids.add(identifier)
        indices.add(index)
    located.sort(key=lambda c: c.chunk.chunk_index)
    if any(
        a.start >= b.start or a.end >= b.end
        for a, b in zip(located, located[1:], strict=False)
    ):
        raise ValueError("Immutable chunk ordering mismatch")
    return ProcedureSource(
        body,
        tuple(located),
        identity,
        snapshot.get("metadata", {}),
        snapshot.get("captured_scope"),
    )


def _canonical_group(proof, requirement, question, citations, snapshots):  # noqa: C901 - bounded canonical source and certificate replay
    from app.services.procedure_evidence import bind_extent, project_cover
    from app.services.procedure_support import (
        COPY_PROFILE,
        build_plan,
        copy_request_binding,
        verification_method,
    )
    from app.services.requirement_contract import _units_valid

    if (
        proof["contract"] != COPY_CONTRACT
        or proof["status"] != "supported"
        or proof["coverage_complete"] is not True
        or proof["procedure_verification_profile"] != COPY_PROFILE
        or proof["request_binding"] != copy_request_binding(requirement, question)
    ):
        raise ValueError("Procedure request binding mismatch")
    source = _source(proof, snapshots)
    raw = proof["raw_seed"]
    seed = next(c.chunk for c in source.chunks if str(c.chunk.id) == raw["chunk_id"])
    extent = bind_extent(
        requirement, source, seed, {**raw["chunk_range"], "text": raw["text"]}
    )
    if raw["document_range"] != {"start": extent.raw_start, "end": extent.raw_end}:
        raise ValueError("Raw source position mismatch")
    plan = build_plan(requirement, source, extent)
    copy_request_binding(requirement, question, plan=plan, source=source)
    if not {"namespace", "applicability"}.issubset({u.kind for u in plan.units}):
        raise ValueError("Source declaration required")
    closure = {"kind": extent.closure, "end": extent.claim.end}
    if extent.boundary:
        closure["boundary_range"] = {
            "start": extent.boundary[0],
            "end": extent.boundary[1],
        }
    expected = {
        "extent": {"start": plan.start, "end": plan.end},
        "closure": closure,
        "structure": plan.structure,
        "step_count": len(plan.steps) if plan.structure == "numbered" else None,
        "mandatory_proof_count": len(plan.units),
        "step_ranges": [{"ordinal": n, "start": a, "end": b} for n, a, b in plan.steps],
        "required_inventory": plan.required_inventory(source),
        "structure_edges": list(plan.edges),
    }
    if any(proof[k] != v for k, v in expected.items()) or len(
        proof["proof_units"]
    ) != len(plan.units):
        raise ValueError("Canonical inventory mismatch")
    for unit, record in zip(plan.units, proof["proof_units"], strict=True):
        method = verification_method(unit)
        fields = {
            "name": unit.name,
            "kind": unit.kind,
            "source_range": {"start": unit.start, "end": unit.end},
            "premise_range": unit.premise_range,
            "hypothesis": unit.hypothesis,
            "verification_method": method,
            "supported": True,
        }
        if any(record.get(k) != v for k, v in fields.items()):
            raise ValueError("Canonical obligation mismatch")
        if method == "nli_entailment":
            if not _units_valid(
                {"mandatory_proof_count": 1, "proof_units": [record]}, len(source.body)
            ):
                raise ValueError("NLI obligation rejected")
        elif set(record) != set(fields):
            raise ValueError("Non-NLI obligation contains classifier fields")
    fragments = project_cover(source, plan.start, plan.end, plan.steps)
    expected_parts = [
        {
            "chunk_id": str(c.id),
            "chunk_start": s.start,
            "chunk_end": s.end,
            "document_start": a,
            "document_end": b,
        }
        for c, s, a, b in fragments
    ]
    if proof["fragments"] != expected_parts:
        raise ValueError("Canonical fragment mismatch")
    mapping = []
    for chunk, span, _left, _right in fragments:
        matches = [c for c in citations if str(c["chunk_id"]) == str(chunk.id)]
        if len(matches) != 1:
            raise ValueError("Missing unique procedure citation")
        citation = matches[0]
        if any(
            citation.get(k) != source.identity[k]
            for k in ("document_id", "document_version", "content_hash")
        ):
            raise ValueError("Citation immutable identity mismatch")
        if citation["quoted_text"] != chunk.content or not any(
            s["start"] <= span.start < span.end <= s["end"]
            for s in citation["answer_spans"]
        ):
            raise ValueError("Citation does not cover procedure")
        mapping.append(
            {
                **expected_parts[len(mapping)],
                "citation_index": citation["citation_index"],
            }
        )
    return {
        "requirement_id": requirement.id,
        "text": source.body[plan.start : plan.end],
        "chunk_ids": [str(c.id) for c, *_ in fragments],
        "fragments": [
            {"chunk_id": str(c.id), "start": s.start, "end": s.end}
            for c, s, *_ in fragments
        ],
    }, mapping


def _replay(selection, *, question, answer, citations, source_snapshots):  # noqa: C901 - complete request/output cross-contract replay
    from app.services.answer_requirements import plan_requirements
    from app.services.requirement_contract import (
        validate_discovery_lineage,
        validate_role_scope_evidence,
    )

    if (
        selection.get("evidence_profile", {}).get("procedure_verification_profile")
        != "source_declared_procedure_copy_v1"
        or validate_discovery_lineage(selection).get("valid") is not True
        or validate_role_scope_evidence(selection).get("valid") is False
    ):
        raise ValueError("Invalid recorded evidence lineage")

    if (
        not isinstance(question, str)
        or not isinstance(answer, str)
        or not isinstance(citations, list)
    ):
        raise ValueError("Actual presentation context required")
    planned = plan_requirements(question)
    requirements = selection["requirements"]
    if len(requirements) != len(planned):
        raise ValueError("Entire request inventory mismatch")
    groups, pending, seen = [], [], set()
    for row, requirement in zip(requirements, planned, strict=True):
        if (
            row.get("id") != requirement.id
            or row.get("kind") != requirement.kind
            or row.get("original_text") != requirement.original_text
            or row.get("input_range")
            != {"start": requirement.input_start, "end": requirement.input_end}
            or row.get("status") != "supported"
        ):
            raise ValueError("Actual request plan mismatch")
        if requirement.kind != "procedure":
            continue
        proof = row["procedure_completeness"]
        group, mapping = _canonical_group(
            proof, requirement, question, citations, source_snapshots
        )
        groups.append(group)
        pending.append((proof, mapping, requirement))
    if not pending:
        raise ValueError("No v3 procedure")
    _validate_selected_passages(selection, citations, groups, source_snapshots)
    for index, citation in enumerate(citations, 1):
        identifier = str(citation["chunk_id"])
        if citation["citation_index"] != index or identifier in seen:
            raise ValueError("Citation order mismatch")
        seen.add(identifier)
        passage = citation["quoted_text"]
        for span in citation["answer_spans"]:
            a, b = span["start"], span["end"]
            if (
                type(a) is not int
                or type(b) is not int
                or not 0 <= a < b <= len(passage)
                or passage[a:b] != span["text"]
            ):
                raise ValueError("Nonliteral answer span")
    disclosures = [
        item["disclosure"]
        for item in selection.get("role_scope_interpretations", [])
        if item.get("activity_fallback")
    ]
    expected_answer, segments = render_extractive(citations, groups, disclosures)
    if answer != expected_answer:
        raise ValueError("Actual answer differs from canonical renderer")
    certificates = []
    for proof, mapping, requirement in pending:
        certificates.append(
            (
                proof,
                {
                    "contract": OUTPUT_CONTRACT,
                    "renderer": RENDERER,
                    "request_binding": proof["request_binding"],
                    "source_identity": {
                        k: proof[k]
                        for k in ("document_id", "document_version", "content_hash")
                    },
                    "required_inventory": proof["required_inventory"],
                    "instruction_range": proof["extent"],
                    "answer_range": segments[requirement.id],
                    "citation_mapping": mapping,
                    "answer_sha256": hashlib.sha256(answer.encode()).hexdigest(),
                },
            )
        )
    return certificates


def _validate_selected_passages(selection, citations, groups, snapshots):  # noqa: C901 - replay the existing witness-span union
    """Replay the existing selected-witness span union, including other facts."""
    from app.models.query import AnswerSpan
    from app.services.requirement_answers import Witness, _selected_passages

    chunks = {}
    for citation in citations:
        snapshot = snapshots[citation["document_id"]]
        source = _source(
            {
                **{
                    k: citation[k]
                    for k in ("document_id", "document_version", "content_hash")
                },
                "workspace_id": snapshot["workspace_id"],
                "source_body": snapshot["body"],
                "body_length": len(snapshot["body"]),
            },
            snapshots,
        )
        chunk = next(
            c.chunk
            for c in source.chunks
            if str(c.chunk.id) == str(citation["chunk_id"])
        )
        if chunk.content != citation["quoted_text"]:
            raise ValueError("Citation differs from immutable chunk")
        chunks[str(chunk.id)] = chunk
    selected = []
    for group in groups:
        for part in group["fragments"]:
            chunk = chunks[part["chunk_id"]]
            span = AnswerSpan(
                start=part["start"],
                end=part["end"],
                text=chunk.content[part["start"] : part["end"]],
            )
            selected.append(
                Witness(group["requirement_id"], chunk, span, "", "", 0, None)
            )
    identifiers = set(selection["selected_proposal_ids"])
    for row in selection["requirements"]:
        if row["kind"] == "procedure":
            continue
        matching = [
            w
            for w in row["witnesses"]
            if any(p["proposal_id"] in identifiers for p in w["proposals"])
        ]
        if not matching:
            raise ValueError("No selected factual witness")
        for witness in matching:
            chunk = chunks[witness["chunk_id"]]
            span = AnswerSpan.model_validate(witness["span"])
            if chunk.content[span.start : span.end] != span.text:
                raise ValueError("Factual witness is not literal")
            selected.append(Witness(row["id"], chunk, span, "", "", 0, None))
    expected = _selected_passages(selected)
    for citation in citations:
        spans = expected.get(uuid.UUID(str(citation["chunk_id"])), ())
        if citation["answer_spans"] != [s.model_dump(mode="json") for s in spans]:
            raise ValueError(
                "Actual extracts differ from selected factual/procedure witnesses"
            )


def certify_output(selection, **context):
    """Stage -> certified only after reconstructing actual full canonical output."""
    for proof, certificate in _replay(selection, **context):
        proof["output_certificate"] = certificate


def verify_output(selection, **context) -> bool:
    try:
        return all(
            proof.get("output_certificate") == certificate
            for proof, certificate in _replay(selection, **context)
        )
    except (KeyError, IndexError, TypeError, ValueError, AttributeError, StopIteration):
        return False


def has_v3(selection):
    if not isinstance(selection, dict):
        return False
    profile = selection.get("evidence_profile")
    profile = profile if isinstance(profile, dict) else {}
    rows = selection.get("requirements", [])
    copy_profile = (
        profile.get("procedure_verification_profile")
        == "source_declared_procedure_copy_v1"
    )
    if not isinstance(rows, list):
        return copy_profile
    return (
        any(
            isinstance(row, dict)
            and row.get("kind") == "procedure"
            and row.get("status") == "supported"
            for row in rows
        )
        and copy_profile
    ) or any(
        isinstance(row, dict)
        and isinstance(row.get("procedure_completeness"), dict)
        and row["procedure_completeness"].get("contract") == COPY_CONTRACT
        for row in rows
    )


async def load_snapshots(db, selection):
    """Historical versions are independently loaded, never copied from certificates."""
    from sqlalchemy import select

    from app.db.cancellation import complete_read
    from app.models.document import DocumentVersion
    from app.services.document.source_context import validated_snapshot_context

    snapshots = {}
    identities = [
        row.get("procedure_completeness") or {}
        for row in selection.get("requirements", [])
    ]
    identities.extend(selection.get("inspected_sources", []))
    for proof in identities:
        if not proof or proof["document_id"] in snapshots:
            continue
        with db.no_autoflush:
            snapshot = await complete_read(
                db.scalar(
                    select(DocumentVersion).where(
                        DocumentVersion.document_id == uuid.UUID(proof["document_id"]),
                        DocumentVersion.version_number == proof["document_version"],
                        DocumentVersion.content_hash == proof["content_hash"],
                    )
                )
            )
        if snapshot is None:
            raise ValueError("Missing immutable snapshot")
        snapshots[proof["document_id"]] = {
            "document_id": proof["document_id"],
            "document_version": snapshot.version_number,
            "content_hash": snapshot.content_hash,
            "workspace_id": snapshot.workspace_id,
            "body": snapshot.normalized_content,
            "chunks": snapshot.chunks,
            "captured_scope": validated_snapshot_context(snapshot),
            "metadata": {},
        }
    return snapshots
