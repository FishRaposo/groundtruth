"""Read-only final delivery records, bindings and links; no test/model/API runs."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile
O=Path(__file__).resolve().parent
V=O.parents[1];S=V.parent;W=S/'delivery-worktree';R=W.parents[2]
E=W/'docs/evidence/answer-coverage-v9'
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
def blobs(queries):
    stream=io.BytesIO(subprocess.run(['git','-C',str(W),'cat-file','--batch'],input=('\n'.join(queries)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout)
    out={}
    for q in queries:
        header=stream.readline().split();assert header[1]==b'blob'
        out[q]=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    return out
result={'bundles':{},'engineering':{},'limitations':[]}
obs=read(E/'observations.json');source=read(E/'current-source.json');wheel=read(E/'wheel-binding.json')
assert len(source)==161
before={n:sha((W/n).read_bytes()) for n in source}
assert before==source
(O/'source-before.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
assert obs['reader_contract']=='reader-parts-v14' and obs['quality_acceptance'].startswith('OPEN')
payloads={}
for record in obs['bundles']:
    path=E/record['name']
    assert sha(path.read_bytes())==record['sha256']
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==len(set(z.namelist()))==record['files']
        payloads[path.name]={n:z.read(n) for n in z.namelist()}
    result['bundles'][path.name]={'sha256':record['sha256'],'files':record['files']}
assert set(payloads['current-source.zip'])=={'source/'+n for n in source}
assert all(sha(payloads['current-source.zip']['source/'+n])==h for n,h in source.items())
assert len(wheel['runtime_modules'])==137 and wheel['source_match'] is True
assert all(sha((W/'apps/api'/n).read_bytes())==h for n,h in wheel['runtime_modules'].items())
result['source_bindings']={'measured_current_paths':161,'wheel_module_paths':137}
wheel_path=W/'apps/api/dist/groundtruth-0.2.0-py3-none-any.whl'
try:
    wheel_bytes=wheel_path.read_bytes()
except PermissionError:
    copy=O/'current-wheel.whl'
    if copy.exists():wheel_bytes=copy.read_bytes()
    else:
        wheel_bytes=None
        result['limitations'].append('Direct wheel bytes unavailable by PermissionError;137 recorded wheel/source module hashes still match current source.')
if wheel_bytes is not None:
    assert sha(wheel_bytes)==wheel['wheel_sha256']
    with zipfile.ZipFile(io.BytesIO(wheel_bytes)) as z:
        actual={n:sha(z.read(n)) for n in z.namelist() if n.startswith('app/') and n.endswith('.py')}
    assert actual==wheel['runtime_modules']
    result['source_bindings']['actual_wheel_sha256']=sha(wheel_bytes)
assert wheel['optional_api_probe_threshold']==0 and wheel['comparison_threshold']==4
assert 'Previously fresh' in wheel['optional_reader_environment']

engineering=payloads['engineering-commands-and-results.zip']
checks={
 'api633':('postseal-final-python.log',b'633 passed, 1 skipped'),
 'tools20':('postseal-final-tools.log',b'20 passed'),
 'ruff':('postseal-final-ruff.log',b'All checks passed!'),
 'format231':('postseal-final-format.log',b'231 files already formatted'),
 'pyright0':('postseal-final-types.log',b'0 errors, 0 warnings, 0 informations'),
 'frontend72':('postseal-final-frontend-unit.log',b'72 passed'),
 'forbidden':('postseal-final-forbidden.log',b'No actionable external shared-core dependencies found.'),
 'wheel_build':('postseal-final-build.log',b'Successfully built'),
 'wheel_closure':('postseal-final-wheel-contents.log',b'Wheel vendor closure verified'),
 'base_install':('postseal-final-isolated-wheel.log',b'Isolated wheel imports verified'),
 'offline21':('postseal-final-offline-browser.log',b'21 passed'),
 'golden':('postseal-final-golden.log',b'Verified 4 files'),
 'historical_corrected':('postseal-final-historical-revision.log',b'first quality gate remains FAILED'),
}
for label,(name,expected) in checks.items():
    assert expected in engineering[name],label
    result['engineering'][label]=True
coverage=json.loads(engineering['postseal-final-combined-coverage.json'])['totals']
assert coverage==obs['coverage']
assert (coverage['covered_lines'],coverage['num_statements'],coverage['percent_covered_display'])==(5005,7303,'69')
result['engineering']['coverage']=coverage
assert b'verify_package_closure.py' in engineering['postseal-final-package-closure.log']
assert b'No such file' in engineering['postseal-final-package-closure.log'] or b"can't open file" in engineering['postseal-final-package-closure.log']
assert b'FAILED' in engineering['postseal-final-historical.log'] or b'changed' in engineering['postseal-final-historical.log'] or b'mismatch' in engineering['postseal-final-historical.log']
for model in ['minilm','roberta']:
    log=engineering['postseal-final-installed-'+model+'.log'].decode()
    observation=json.loads(next(line for line in log.splitlines() if line.startswith('{"status": "installed_api_reader_functional_probe')))
    assert observation['reader']==model and observation['threshold']==0 and observation['actual_upload_query_history_source']
assert b'Successfully installed groundtruth-0.2.0' in engineering['postseal-final-reader-wheel-update.log']

browser=payloads['connected-browser-and-restart.zip']
for name in ['connected.log','diagnostic.log']:
    assert b'3 passed' in browser['browser-postseal-final/'+name]
assert json.loads(browser['browser-postseal-final/result.json'])['connected_exit']==0
assert json.loads(browser['browser-postseal-final/result.json'])['diagnostic_exit']==0
restart=json.loads(browser['browser-postseal-final/restart.json'])
assert restart['equal'] and restart['before']==restart['after']
reader=json.loads(browser['browser-postseal-final/reader-api.log.ready.json'])['runtime']['answer_selection']
assert reader['contract']=='reader-parts-v14' and reader['threshold']==4
result['engineering']['restart']=restart
for name in ['diagnostic-answer-1440.png','diagnostic-source-390.png','connected-documents-768.png']:
    assert (E/name).read_bytes()==browser['browser-postseal-final/screenshots/'+name]
# The reused frontend is unchanged relative to the previously inspected build source.
assert not git('diff','--name-only','bf7d283','--','apps/web').strip()
result['frontend_source_unchanged_since_build']=True

focused=payloads['focused-exposed-http.zip']
prefix='postseal-final-observations/'
assert json.loads(focused[prefix+'source-before.json'])==json.loads(focused[prefix+'source-after.json'])==source
report_bytes=focused[prefix+'focused-exposed-filtered-5-report.json']
assert sha(report_bytes)==focused[prefix+'focused-exposed-filtered-5-report.json.sha256'].decode().strip()
report=json.loads(report_bytes)
assert set(report['results'])=={'reranked'} and report['settings']['reader_null_threshold']==4
assert report['evaluation_visibility'].startswith('EXPOSED DEVELOPMENT ONLY') and report['selection_sha256'] is None
rows=report['results']['reranked']['cases']
assert len(rows)==5 and all(r['category']=='answerable' and r['answer_quality_passed'] for r in rows)
# Offline portable rescoring of saved rows only; no application/test invocation.
frozen=V/'code-review/v5-final-audit/frozen'
sys.path[:0]=[str(frozen/'apps/api'),str(frozen/'scripts')]
from app.portfolio import load_corpus
from verify_answer_coverage_delivery import audit_report
corpus=load_corpus(S/'blind-v5-derived-v1')
corpus['cases']=[c for c in corpus['cases'] if c['document_ids'] is not None]
assert len(corpus['cases'])==5
assert {r['case_id'] for r in rows}=={c['id'] for c in corpus['cases']}
audit=audit_report(report,corpus)
assert audit==json.loads(focused[prefix+'focused-exposed-filtered-5-integrity.json'])
result['focused_saved_row_audit']=audit

review=payloads['independent-scope-review.zip']
review_root=V/'code-review/postseal-scope-review'
assert all((review_root/n).read_bytes()==b for n,b in review.items())
assert all(r['passed'] for r in json.loads(review['recheck-01/probe-result.json']))
assert all(r['passed'] for r in json.loads(review['recheck-01/case-controls-result.json']))
assert b'13 passed' in review['recheck-01/owned_tests.log']
result['independent_review_exact_files']=len(review)

preservation=read(E/'preservation.json')
assert len(preservation['original16'])==16
assert all(sha((W/n).read_bytes())==h for n,h in preservation['original16'].items())
for folder,record in preservation['historical'].items():
    paths=git('ls-tree','-r','--name-only',record['revision'],'--','docs/evidence/'+folder).decode().splitlines()
    assert len(paths)==record['unchanged_files']
    old=blobs([record['revision']+':'+n for n in paths])
    assert all(old[record['revision']+':'+n]==(W/n).read_bytes() for n in paths)
result['preservation']={'original':16,**{n:r['unchanged_files'] for n,r in preservation['historical'].items()}}

# Exact known disposable seed key scan in memory; never emit private values.
keys=set()
for folder in [S/'baseline-blind-v5',S/'candidate-blind-v5',V/'browser-postseal/data',V/'browser-postseal-final/data']:
    seed=read(folder/'seed-manifest.json')
    keys.update(p['api_key'].encode() for p in seed['principals'].values() if p.get('api_key'))
scan=[p.read_bytes() for p in E.iterdir() if p.is_file()]+[b for data in payloads.values() for b in data.values()]
assert not any(k in b for k in keys for b in scan)
result['private_key_check']={'known_keys':len(keys),'payloads':len(scan),'matches':0}

docs=['README.md','SETUP.md','docs/ARCHITECTURE.md','docs/SECURITY.md','docs/answer-coverage-development-v3.md','docs/answer-coverage-verification.md','docs/portfolio-case-study.md','docs/portfolio-handoff.md','docs/portfolio-verification.md','docs/portfolio-walkthrough.md','docs/evidence/answer-coverage-v9/README.md']
link_count=0
for name in docs:
    path=W/name
    if name=='docs/evidence/answer-coverage-v9/README.md':
        text=path.read_text(encoding='utf-8')
    else:
        diff=git('diff','--unified=0','d95899d','--',name).decode('utf-8')
        text='\n'.join(line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++'))
    for link in re.findall(r'\]\(([^)]+)\)',text):
        if link.startswith(('http:','https:','mailto:','#')):continue
        target=link.split('#')[0]
        if not target:continue
        assert (path.parent/target).exists(),(name,link)
        link_count+=1
result['existing_local_links_checked']=link_count
root_link_count=0
for relative in ['portfolio/PORTFOLIO_PLAN.md','portfolio/plans/groundtruth.md','docs/handoffs.md']:
    path=R/relative
    for link in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
        if 'answer-coverage-v8' not in link and 'answer-coverage-v9' not in link:continue
        assert (path.parent/link.split('#')[0]).exists(),(relative,link)
        root_link_count+=1
result['current_root_trial_and_repair_links']=root_link_count
assert before=={n:sha((W/n).read_bytes()) for n in source}
(O/'source-after.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'audit-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
