"""Disposable real-process connected browser and restart acceptance; preserve all results."""
from pathlib import Path
from uuid import UUID
import hashlib,json,os,sqlite3,subprocess,time
import httpx
R=Path('C:/Projects/operation-fan-the-hammer');S=R/'.tmp/groundtruth-coverage-20261024';W=S/'delivery-worktree';V=S/'coverage-v3'
P=R/'portfolio/groundtruth/.venv/Scripts/python.exe'; D=V/'browser-postseal';D.mkdir(exist_ok=False)
data=D/'data';data.mkdir();env=os.environ.copy();env['PYTHONPATH']=str(W/'apps/api')
for k in list(env):
 if k.startswith(('OPENAI_','ANTHROPIC_','AZURE_OPENAI_','GOOGLE_API','GEMINI_')):del env[k]
common=['--data-dir',str(data),'--model-dir',str(R/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41'),'--port','8402','--frontend-origin','http://127.0.0.1:3506']
valid=S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'
def command(action,reader=valid):return [str(P),str(W/'scripts/portfolio_local.py'),action,*common,'--reader-dir',str(reader)]
def run(cmd,name,cwd=W,extraenv=None):
 with (D/name).open('wb') as log:r=subprocess.run(cmd,cwd=cwd,env=extraenv or env,stdout=log,stderr=subprocess.STDOUT)
 print(name+': exit '+str(r.returncode),flush=True);return r.returncode
assert run(command('migrate'),'migrate.log')==0
def start(name,reader=valid,ready=True):
 log=(D/name).open('wb');p=subprocess.Popen(command('serve',reader),cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 for _ in range(200):
  assert p.poll() is None,'API exited'
  try:
   if httpx.get('http://127.0.0.1:8402/api/health/live',timeout=1).status_code==200:break
  except httpx.HTTPError:pass
  time.sleep(.25)
 else:raise RuntimeError('API startup timeout')
 if ready:
  h=httpx.get('http://127.0.0.1:8402/api/health/ready',timeout=300);h.raise_for_status();body=h.json();assert body['status']=='ready',body
  a=body['runtime']['answer_selection'];assert a['threshold']==4 and a['revision']=='adc3b06f79f797d1c575d5479d6f5efe54a9e3b4' and a['contract']=='reader-parts-v14'
  (D/(name+'.ready.json')).write_text(json.dumps(body,indent=2)+'\n')
 return p,log
def stop(pair):
 p,log=pair;subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False);p.wait(timeout=20);log.close()
pair=start('missing-reader-api.log',D/'intentionally-missing-reader',False)
try:
 assert run(command('seed'),'seed.log')==0
 seed=json.loads((data/'seed-manifest.json').read_text(encoding='utf-8'))
 q='Who approves the staging rollback? reader-unavailable-evidence-postseal'
 r=httpx.post(seed['api_url']+'/api/queries',headers={'X-API-Key':seed['principals']['admin-a']['api_key']},json={'question':q,'document_ids':[seed['browser']['document_id']],'retrieval_method':'reranked'},timeout=300)
 assert r.status_code==503,r.status_code
 with sqlite3.connect(data/'groundtruth.sqlite') as db:
  row=db.execute('SELECT id,outcome,provenance FROM queries WHERE question=?',(q,)).fetchone()
 assert row and row[1]=='error';provenance=json.loads(row[2]);assert provenance['answer_selection']['decision']=='error'
 seed['reader_error_query_id']=str(UUID(row[0]));seed['browser']['reader_contract']='reader-parts-v14';seed['browser']['expected_answer_span']='pause the deployment queue'
 (data/'seed-manifest.json').write_text(json.dumps(seed,indent=2)+'\n',encoding='utf-8')
 (D/'reader-error.json').write_text(json.dumps({'status':503,'outcome':'error','query_id':seed['reader_error_query_id'],'injection':'Explicit missing configured assets, real request; no response mock'},indent=2)+'\n')
finally:stop(pair)
pair=start('reader-api.log')
try:
 browserenv={**env,'PLAYWRIGHT_PORT':'3506','PLAYWRIGHT_EXTERNAL_SERVER':'1','GROUNDTRUTH_SEED_MANIFEST':str(data/'seed-manifest.json'),'GROUNDTRUTH_SCREENSHOTS':str(D/'screenshots')}
 npm='C:/Program Files/nodejs/npm.cmd'
 main=run([npm,'exec','--','playwright','test','--config','playwright.live.config.ts'],'connected.log',W/'apps/web',browserenv)
 diagnostic=run([npm,'exec','--','playwright','test','--config','playwright.diagnostic.config.ts'],'diagnostic.log',W/'apps/web',browserenv)
 with sqlite3.connect(data/'groundtruth.sqlite') as db:
  row=db.execute("SELECT id FROM queries WHERE outcome='completed' AND answer LIKE '%Anika%' ORDER BY created_at DESC LIMIT 1").fetchone();assert row
  counts={t:db.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['documents','chunks','queries']}
 identifier=str(UUID(row[0]));headers={'X-API-Key':seed['principals']['admin-a']['api_key']}
 def snapshot():
  with httpx.Client(timeout=60) as c:
   a=c.get(seed['api_url']+'/api/queries/'+identifier,headers=headers);a.raise_for_status();b=c.get(seed['api_url']+'/api/queries/'+identifier+'/sources/1',headers=headers);b.raise_for_status()
  record={k:a.json()[k] for k in ['answer','sources','provenance','refused','outcome']}
  digest=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
  return {'query_id':identifier,'record_sha256':digest(record),'source_sha256':digest(b.json())}
 before=snapshot();stop(pair);pair=None
 pair=start('restart-api.log');after=snapshot();assert before==after
 with sqlite3.connect(data/'groundtruth.sqlite') as db:assert counts=={t:db.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in counts}
 (D/'restart.json').write_text(json.dumps({'before':before,'after':after,'domain_counts':counts,'equal':True},indent=2)+'\n')
 (D/'result.json').write_text(json.dumps({'connected_exit':main,'diagnostic_exit':diagnostic,'restart':'passed','quality_acceptance':'Pending fresh blind; browser is functional only'},indent=2)+'\n')
 assert main==diagnostic==0,'Preserve failed browser acceptance, inspect logs'
finally:
 if pair:stop(pair)
print('Real connected/restart browser observations complete.',flush=True)
