"""Generic source-scope command grammar; authored after the sealed failed trial."""
import pytest
from app.services.reader_questions import named_anchors, question_parts, scope_matches


@pytest.mark.parametrize('directive', ['Limit the answer', 'LIMIT THE ANSWER', 'Please limit the answer'])
def test_answer_scope_directive_is_not_an_entity(directive):
    text=f'Who supervises Aurora trials? {directive} to the document titled Aurora guide.'
    assert named_anchors(text)==('aurora',)
    assert all(scope_matches(p,'Aurora trials are supervised by the recorder.') for p in question_parts(text))


@pytest.mark.parametrize('question', [
    'Who supervises the Limit fixture?',
    'Limit fixture inspection: who supervises it?',
    'What is the Limit answer register?',
])
def test_limit_in_a_proper_name_remains_an_entity(question):
    assert 'limit' in named_anchors(question)
    assert not all(scope_matches(p,'Borealis is supervised by the recorder.') for p in question_parts(question))
