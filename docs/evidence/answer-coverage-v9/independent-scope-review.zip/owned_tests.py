"""Execute only copied pure-helper unit tests, no application fixtures."""
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
app=types.ModuleType('app');app.__path__=[str(O/'current/app')];sys.modules['app']=app
services=types.ModuleType('app.services');services.__path__=[str(O/'current/app/services')];sys.modules['app.services']=services
import pytest
status=pytest.main(['--noconftest','--confcutdir',str(O),'-o','addopts=','-p','no:cacheprovider','-q',str(O/'current/tests/test_reader_scope_directive.py')])
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
raise SystemExit(status)
