"""Answer-scope grammar must not create entities or erase real proper names."""

import pytest
from app.services.reader_questions import named_anchors, question_parts, scope_matches


@pytest.mark.parametrize(
    "directive", ["Limit the answer", "LIMIT THE ANSWER", "Please limit the answer"]
)
def test_answer_scope_directive_is_not_an_entity(directive):
    question = (
        f"Who supervises Aurora trials? {directive} "
        "to the document titled Aurora guide."
    )
    assert named_anchors(question) == ("aurora",)
    assert all(
        scope_matches(part, "Aurora trials are supervised by the recorder.")
        for part in question_parts(question)
    )


@pytest.mark.parametrize(
    "question",
    [
        "Who supervises the Limit fixture?",
        "Limit fixture inspection: who supervises it?",
        "What is the Limit answer register?",
    ],
)
def test_limit_in_a_proper_name_remains_an_entity(question):
    assert "limit" in named_anchors(question)
    assert not all(
        scope_matches(part, "Borealis is supervised by the recorder.")
        for part in question_parts(question)
    )
