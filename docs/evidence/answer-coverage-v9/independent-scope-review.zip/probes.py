"""Pure request-helper recheck only; no corpus/model/API execution."""
import json
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
app=types.ModuleType('app');app.__path__=[str(O/'current/app')];sys.modules['app']=app
services=types.ModuleType('app.services');services.__path__=[str(O/'current/app/services')];sys.modules['app.services']=services
from app.services.reader_questions import named_anchors,question_parts,scope_matches
rows=[]
def check(name,actual,expected):
    rows.append({'name':name,'actual':actual,'expected':expected,'passed':actual==expected})
    print(('PASS' if actual==expected else 'FAIL')+' '+name+': '+repr(actual))
body='Aurora trials are supervised by the recorder.'
for directive in ['Limit the answer','LIMIT THE ANSWER','Please limit the answer','LiMiT tHe AnSwEr']:
    question=f'Who supervises Aurora trials? {directive} to the document titled Aurora guide.'
    check('directive-'+directive,named_anchors(question),('aurora',))
    check('body-unchanged-'+directive,question_parts(question)[0].question,question)
    check('body-scope-'+directive,all(scope_matches(p,body) for p in question_parts(question)),True)
for question in ['Who supervises the Limit fixture?','Limit fixture inspection: who supervises it?','What is the Limit answer register?','Limit answer register: who owns it?','Who supervises Aurora trials? Limit fixture inspection needs a separate answer.']:
    check('proper-name-'+question,'limit' in named_anchors(question),True)
for question in ['Who supervises Aurora trials? Limit the answer to the document titled Borealis guide.','Who supervises Aurora trials? Limit the answer to the Limit fixture.']:
    check('topic-not-dropped-'+question,len(named_anchors(question))>=2,True)
    check('wrong-topic-not-granted-'+question,all(scope_matches(p,body) for p in question_parts(question)),False)
question='Who supervises Aurora trials? Limit the answer TO the document titled Aurora guide.'
check('capitalized-preposition-same-directive',named_anchors(question),('aurora',))
check('capitalized-preposition-correct-source-not-rejected',all(scope_matches(p,body) for p in question_parts(question)),True)
check('capitalized-preposition-body-unchanged',question_parts(question)[0].question,question)
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'probe-result.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'{sum(r["passed"] for r in rows)} PASS / {sum(not r["passed"] for r in rows)} FAIL')
raise SystemExit(any(not r['passed'] for r in rows))
