# Scope directive — focused final recheck

2026-10-24. **The retained residual uppercase-TO finding is resolved. No additional material finding remains within this focused scope.** The earlier22PASS/2FAIL probes, source copies and report remain unchanged in the parent directory.

Current named_anchors consumes the complete bounded `Limit the answer to` grammar and optional `the document titled` phrase only at the recognized sentence boundary, leaving the actual source/title name as an anchor. Metadata remains reader-parts-v14. Original question/provider text is unchanged; no permission/filter/current-source code changes appear in this repair.

Actual commands, all exit0:

- probes.py is a byte copy of the retained original script. All24 assertions now pass, including both exact uppercase-TO failures. Genuine Limit names, wrong-topic constraints and unchanged question strings remain passing.
- case_controls.py:21PASS. Uppercase full DOCUMENT TITLED, optional Please/the, direct topic, Borealis title and Limit fixture/register names retain the expected anchors and eligibility. All seven question strings remain byte-for-byte unchanged by preparation.
- owned_tests.py:13PASS in0.04s, running only the copied new scope-directive tests, without repository conftest or pytest cache.
- Three scoped source/test before/after hashes match; see source-before.json/source-after.json. Current snapshots are under current/. The support helper is copied only as an unchanged pure dependency.

Commands use the existing original .venv interpreter with -B, UTF-8 and disabled bytecode writes. No torch/transformers modules, application fixtures, models, APIs, corpus measurement, full suite, source/data writes or authorization requests execute. All reviewer writes stay in this new recheck directory.

This is finite pure-helper verification, not general entity recognition, semantic entailment, QA correctness or permission acceptance. The original frozen bf candidate still failed69/120+62/80. Eligibility becoming true for a formerly blocked question does not establish a new answer,74/120, a successful exposed rerun or unseen acceptance. Parent owns current full gates and any controlled actual API regression; no promotion follows from this recheck.
