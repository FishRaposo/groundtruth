"""Bounded uppercase head/title-name and unchanged-body controls."""
import json
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
app=types.ModuleType('app');app.__path__=[str(O/'current/app')];sys.modules['app']=app
services=types.ModuleType('app.services');services.__path__=[str(O/'current/app/services')];sys.modules['app.services']=services
from app.services.reader_questions import named_anchors,question_parts,scope_matches
rows=[]
body='Aurora trials are supervised by the recorder.'
variants=[
 ('LIMIT THE ANSWER TO THE DOCUMENT TITLED Aurora guide.',('aurora',),True),
 ('Please LIMIT THE ANSWER TO THE DOCUMENT TITLED Aurora guide.',('aurora',),True),
 ('Limit the answer to document titled Aurora guide.',('aurora',),True),
 ('Limit the answer TO Aurora.',('aurora',),True),
 ('LIMIT THE ANSWER TO THE DOCUMENT TITLED Borealis guide.',('aurora','borealis'),False),
 ('LIMIT THE ANSWER TO THE DOCUMENT TITLED Limit fixture.',('aurora','limit'),False),
 ('Please limit the answer to the Limit answer register.',('aurora','limit'),False),
]
for suffix,expected,eligible in variants:
    question='Who supervises Aurora trials? '+suffix
    parts=question_parts(question)
    values=[('anchors',named_anchors(question),expected),('unchanged_question',parts[0].question,question),('source_scope',all(scope_matches(p,body) for p in parts),eligible)]
    for name,actual,wanted in values:rows.append({'case':suffix,'check':name,'actual':actual,'expected':wanted,'passed':actual==wanted})
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'case-controls-result.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(f'{sum(r["passed"] for r in rows)} PASS / {sum(not r["passed"] for r in rows)} FAIL')
raise SystemExit(any(not r['passed'] for r in rows))
