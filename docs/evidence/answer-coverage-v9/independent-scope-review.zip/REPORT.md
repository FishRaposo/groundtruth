# Post-seal Limit scope-grammar review

2026-10-24. The original lowercase `Limit the answer to ...` false entity is repaired. **One residual material case-variant finding remains** in this snapshot. No model/API/quality rerun was performed, and the original frozen69/120+62/80 result is unchanged.

## P2 — Capitalized TO remains a false entity in the same directive

In reader_questions.py:38–42, the recognized bounded phrase stops before `to` through a lookahead. For:

`Who supervises Aurora trials? Limit the answer TO the document titled Aurora guide.`

the copied current helper returns anchors `('aurora', 'to')`. The correct context `Aurora trials are supervised by the recorder.` is rejected by scope_matches because it lacks the word `to`. The equivalent directive with lowercase `to` returns only `aurora` and accepts that context. This is a residual case variant of the intended grammar fix, not a new access grant or an observed model-quality regression. Original question text remains unchanged in both cases.

Reproducer: probes.py, retained assertions `capitalized-preposition-same-directive` and `capitalized-preposition-correct-source-not-rejected`. Exit1:22PASS/2FAIL. No application code is imported beyond copied pure request/support helpers; no model or database exists in this probe.

## Passing checks and scope

The four ordinary/mixed/uppercase directive-head variants with lowercase `to` remove only grammar from entity extraction, retain the exact original question body, and permit the matching source. Genuine Limit names remain anchors: `the Limit fixture`, sentence-head `Limit fixture inspection`, `Limit answer register`, and the same name in a later sentence. Different Borealis and Limit source topics remain anchors and continue to reject an Aurora-only context. No authorization, source-title or body constraint is intentionally removed in the inspected diff; permissions, filters and current-source checks are untouched.

The two production-file diff against d95899d consists only of the bounded named_anchors alternative and metadata reader-parts-v13→reader-parts-v14. New test_reader_scope_directive.py is the only added test in scope. The copied six owned tests pass in0.05s, exit0, using pytest without repository conftest or cache. Independent probes deliberately expose the additional uppercase-preposition case.

source-before.json/source-after.json record matching raw SHA256s for reader_questions.py, answer_reader.py and the new test. Their snapshots are under current/. The unchanged reader_support.py is copied only as a pure dependency. Commands use the existing original .venv interpreter with -B, UTF-8 and disabled bytecode writes. Model libraries are not loaded; no model, QA/API, full suite, corpus, labels, source records or owner data were run or edited.

Original preflight/final audit artifacts and sealed results remain unchanged. This finite grammar review does not establish support/entailment, new correctness totals or unseen acceptance. Parent owns any further bounded repair and verification; no promotion or completion claim follows from these passing controls.
