# D373 independent exposed-DEV margin grid — select margin2, QUIET

Checked 2026-10-26. FTH-016 / Project05; cash unknown. **The predeclared rule selects margin2.** No source, label, threshold, model, default or evaluation artifact was changed by this review. No model/server/process/network execution occurred.

Inspection began only after `typed-margin-grid-v361/completed.json` and all five margin0..4 preservation manifests existed. The audit read only the completed/sealed runs. The original grid completion declaration covers margins1..4; margin0 is the existing separately sealed reference named by the predeclared grid.

## Independent result

Every saved response was rescored against the immutable development corpus using the frozen source30 portable-evidence scorer. The recomputed complete summaries equal the recorded summaries.

| Margin | Correct positives | Correct negatives | Required opposing identities | Execution/access/citation/span errors | Eligible |
| --- | --- | --- | --- | --- | --- |
| 0 | 48/48 | 32/32 | 8/8 | 0/0/0/0 | yes |
| 1 | 48/48 | 32/32 | 8/8 | 0/0/0/0 | yes |
| **2** | **48/48** | **32/32** | **8/8** | **0/0/0/0** | **yes, selected** |
| 3 | 30/48 | 32/32 | 8/8 | 0/0/0/0 | no, below46 positives |
| 4 | 3/48 | 32/32 | 8/8 | 0/0/0/0 | no, below46 positives |

The immutable declaration says to maximize correct reranked positives subject to32/32 negatives, eight required opposing identities and zero execution/access/citation/span errors, require at least46/48 positives, and break ties toward the higher margin. Margins0/1/2 tie at48; **2 wins that predeclared tie-break**. This review did not search another threshold or alter the selection rule. It does not promote a default.

## Exact evidence bindings

| Margin | SHA256 of complete report |
| --- | --- |
| 0 | `30f9536debb5817569c4280b0a76ebbac3ce5482e0134b3413725ea9a81c3ce6` |
| 1 | `188bc1912832ea7cbb5e3ae1a222e8fbba9a86e5acd7cce524f04f0c7556c768` |
| 2 | `f73f00f1c43c95e726edbf029ebc48b6d5d32c317f99fa3cdb17ff770d7cbc11` |
| 3 | `7b8a97fbd1cd2b193bd497caf60bb4da2bf276ae438392dfdb0b9664ffd3363a` |
| 4 | `749dba9f3567541699fa0b5d9b92d0aa80c63c2fb3e0f72eadec37134ac0235e` |

All five `*-preservation.json` manifests match every bound file: **97 entries each,485 total manifest entries**. All SEALED payload hashes match and the saved file inventories are exact. Each run has children_closed=true/inspection_allowed=true, matching owned PID cleanup with stopped=true, port_closed=true and tree_kill_exit0, complete_report status, false quality/blind claims and matching evaluator/controller exit. Margins0..2 record exit0; margins3..4 record exit1 for complete but insufficient positive results. Each run's ten staged source/corpus integrity checks passes. This verifies recorded closed execution; no current port/process inspection was performed.

Frozen source30 manifest SHA256 is `fd0e693629aaae190d1d3759784d857a77bac0e45c4fa5b45a83d3efd1879772`; all231 source files match. Corpus manifest remains `22c7cf7ccbc229d641b26ea359bdb74420c313b411505734681c843a7ba54cf4`; all bound corpus files match. The canonical scorer was imported only from frozen source30, not current W.

The five configurations share the exact same source, corpus, model bindings and locked runtime executable. Report settings differ only by support margin; explicit child environment differences are limited to that margin and each disposable output/database/storage path. All24 model payload files and three model manifests match their bindings and were checked unchanged after the audit. The16 locked runtime distribution versions and RECORD-file hashes match `locked-runtime-before-source30.json` without importing the model libraries. Package RECORD matching is distribution-metadata evidence, not execution of the optional environment.

Separate JSON-only runtime checks independently confirm all five readiness records and all400 retained observed-response selections: reader/model revision/null threshold4, local NLI/model revision/CPU/configured margin, profile-v4/note-v2 policy, and actual health generation/ingestion/storage/authentication fields match the recorded configuration. The eight required opposing identities are checked from canonical case expectations through each report's logical-to-actual document map, version and full-body hash to `inspected_sources`. There are eight required identities in four cases per margin; a required document may correctly have multiple inspected chunks. Full identity records are in `audit-result.json`.

## Commands and outputs

Commands ran from W=`C:/Projects/operation-fan-the-hammer/.tmp/groundtruth-coverage-20261024/delivery-worktree` with existing W Python; optional-model Python was never invoked.

| Command | Exit / result | Evidence |
| --- | --- | --- |
| `.venv/Scripts/python.exe -B ../quality-v6/typed-margin-independent-v373/audit_grid.py` | final **exit0**, five sealed runs/400 canonical rescores, margin2 selected, all preservation/input/model checks pass | `audit-final.log`, `audit-result.json`, `preservation-before.json`, `model-runtime-before.json`, `preservation-after.json` |
| `.venv/Scripts/python.exe -B ../quality-v6/typed-margin-independent-v373/check_runtime.py` | **exit0**, five health records and400 retained response runtime records match | `runtime-check.log`, `runtime-check.json` |

`audit-first.log` retains an audit-checker error: the first version incorrectly required one matching inspected chunk per expected document identity. Some valid identities have multiple chunks. The checker was corrected to require the exact expected document/version/hash identity in at least one inspected chunk and record the matched chunk count; the canonical corpus, reports, labels and product code were untouched. The final exact identity count is eight canonical expectations per run, not an invented chunk cardinality gate. No product defect was inferred from this checker error.

The scripts set only process-local offline/in-memory import flags, disable bytecode, and install an import guard that raises for torch/transformers/sentence_transformers. Final checks confirm none was imported. No inference, API call, subprocess, source write, tuning, model installation or evaluation rerun was performed. Before/after preservation verifies every tracked input unchanged; all writes are new review artifacts under this directory.

## Scope and next action

The frozen portable scorer's runtime-selection verification flag is false because no final frozen selection artifact was supplied; this is preserved explicitly in `audit-result.json`. Independent runtime/settings/package/model bindings above support these recorded DEV observations, without converting them into final candidate/blind acceptance.

This selection uses already exposed synthetic DEVELOPMENT80 only. It is not new blind evidence, a quality result on fresh cases, release readiness or authority to change defaults. Source29 failure evidence and all weaker grid arms remain preserved. Root owns integration and the shared handoff; no ledger/handoff was edited here.

Root: measure all four retrieval methods at the explicitly selected margin2 configuration under the unchanged gates, then complete required freeze/commit and genuinely fresh independent blind work. **D373 is QUIET; all audit processes completed.**
