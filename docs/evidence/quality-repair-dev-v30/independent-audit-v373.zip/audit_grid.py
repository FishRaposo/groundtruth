"""Sealed exposed-DEV margin audit only; no model import, process or network."""
import hashlib
import importlib.abc
import importlib.metadata
import importlib.util
import json
import os
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent;Q=HERE.parent;SOURCE=Q/'requirements-source-v30';CORPUS=Q/'dev-arm-candidate-v115'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
names=[f'development-v30-typed-context-v2-locked329-margin{m}-reranked' for m in range(5)]
assert (Q/'typed-margin-grid-v361/completed.json').is_file()
assert all((Q/(name+'-preservation.json')).is_file() for name in names)
completed=read(Q/'typed-margin-grid-v361/completed.json')
assert [x['margin'] for x in completed]==[1,2,3,4] and all(x['complete'] and x['preservation_exit']==0 for x in completed)
declared=read(Q/'typed-margin-grid-v361/predeclared-grid.json')
assert declared['margin0']==names[0] and [x['name'] for x in declared['commands']]==names[1:]
preservation=[];tracked={}
for m,name in enumerate(names):
    manifest=Q/(name+'-preservation.json');saved=read(manifest)
    rows=[]
    for rel,expected in saved['files'].items():
        actual=sha(Q/rel);assert actual==expected,rel;tracked[str(Q/rel)]=actual
        rows.append(dict(path=rel,sha256=actual))
    tracked[str(manifest)]=sha(manifest)
    preservation.append(dict(margin=m,manifest_sha256=sha(manifest),files=len(rows),all_match=True))
source_manifest=read(Q/'requirements-source-v30.json')
assert len(source_manifest['files'])==231
for rel,expected in source_manifest['files'].items():
    actual=sha(SOURCE/rel);assert actual==expected;tracked[str(SOURCE/rel)]=actual
for rel,expected in read(CORPUS/'manifest.json')['files'].items():assert sha(CORPUS/rel)==expected;tracked[str(CORPUS/rel)]=expected
tracked[str(CORPUS/'manifest.json')]=sha(CORPUS/'manifest.json')
for p in [Q/'typed-margin-grid-v361/predeclared-grid.json',Q/'typed-margin-grid-v361/completed.json',Q/'requirements-source-v30.json']:tracked[str(p)]=sha(p)
(HERE/'preservation-before.json').write_text(json.dumps(dict(groups=preservation,files=tracked),indent=2)+'\n')

class NoModels(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'torch','transformers','sentence_transformers'}:raise AssertionError('Model import forbidden in D373 audit')
sys.meta_path.insert(0,NoModels());sys.dont_write_bytecode=True;sys.path.insert(0,str(SOURCE/'apps/api'))
os.environ['DATABASE_URL']='sqlite+aiosqlite:///:memory:';os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
from app.portfolio import load_corpus
assert Path(sys.modules['app.portfolio'].__file__).resolve().is_relative_to(SOURCE)
spec=importlib.util.spec_from_file_location('d373_frozen_scorer',SOURCE/'scripts/verify_answer_coverage_delivery.py');scorer=importlib.util.module_from_spec(spec);spec.loader.exec_module(scorer)
from app.portfolio.evaluation import summarize

baseline=read(Q/names[0]/'execution-settings.json')
corpus=load_corpus(CORPUS,expected_representation_profile='connected-paragraphs-v1',expected_common_manifest_sha256=baseline['common_manifest_sha256'])
cases={x['id']:x for x in corpus['cases'] if x['split']=='development'}
assert len(cases)==80
all_models=[]
for kind,binding in baseline['model_binding'].items():
    root=Path(binding['root']);assert sha(root/binding['manifest'])==binding['manifest_sha256']
    tracked[str(root/binding['manifest'])]=binding['manifest_sha256']
    for rel,expected in binding['files'].items():
        actual=sha(root/rel);assert actual==expected;tracked[str(root/rel)]=actual;all_models.append(dict(kind=kind,path=str(root/rel),sha256=actual))
assert len(all_models)==24
runtime=read(Q/'locked-runtime-before-source30.json');assert Path(runtime['executable'])==Path(baseline['python'])
site=Path(runtime['executable']).parent.parent/'Lib/site-packages';normalize=lambda n:n.lower().replace('_','-').replace('.','-')
installed={normalize(d.metadata['Name']):d for d in importlib.metadata.distributions(path=[str(site)]) if d.metadata['Name']}
for name,value in runtime['packages'].items():
    d=installed[normalize(name)];assert d.version==value['version'];p=Path(d._path)/'RECORD';assert sha(p)==value['record_sha256'];tracked[str(p)]=value['record_sha256']
assert len(runtime['packages'])==16
tracked[str(Q/'locked-runtime-before-source30.json')]=sha(Q/'locked-runtime-before-source30.json')
(HERE/'model-runtime-before.json').write_text(json.dumps(dict(model_files=all_models,package_record_files={p:d for p,d in tracked.items() if p.endswith('/RECORD') or p.endswith('\\RECORD')}),indent=2)+'\n')

results=[]
for m,name in enumerate(names):
    run=Q/name;settings=read(run/'execution-settings.json');seal=read(run/'SEALED.json');result=read(run/'result.json');cleanup=read(run/'cleanup.json');process=read(run/'process.json')
    assert settings['margin']==m and settings['method']=='reranked' and settings['source_context_policy']=='scoped_note_context_v2'
    assert settings['source_manifest_sha256']==sha(Q/'requirements-source-v30.json')==baseline['source_manifest_sha256']
    assert settings['corpus_manifest_sha256']==sha(CORPUS/'manifest.json')==baseline['corpus_manifest_sha256']
    assert settings['model_binding']==baseline['model_binding'] and settings['python']==baseline['python']
    assert settings['settings']=={**baseline['settings'],'support_min_margin':m}
    expectedenv={**baseline['environment_overrides'],'SUPPORT_MIN_MARGIN':str(m),'DATABASE_URL':settings['environment_overrides']['DATABASE_URL'],'STORAGE_ROOT':settings['environment_overrides']['STORAGE_ROOT']}
    assert settings['environment_overrides']==expectedenv
    assert settings['environment_overrides']['SOURCE_CONTEXT_POLICY']=='scoped_note_context_v2' and settings['environment_overrides']['SOURCE_CONTEXT_MODE']=='body'
    assert seal['children_closed'] is True and seal['inspection_allowed'] is True
    for rel,expected in seal['files'].items():assert sha(run/rel)==expected
    assert set(seal['files'])=={p.relative_to(run).as_posix() for p in run.rglob('*') if p.is_file() and p.name!='SEALED.json'}
    assert cleanup['pid']==process['owned_pid'] and cleanup['stopped'] is True and cleanup['port_closed'] is True and cleanup['tree_kill_exit']==0
    assert Path(process['source'])==SOURCE and result['status']=='complete_report' and result['quality_gate_claimed'] is False and result['blind_acceptance'] is False
    assert all(result[k] is True for k in ['source_unchanged','corpus_unchanged','models_unchanged'])
    stages=read(run/'input-checks.json');assert len(stages)==10 and all(x['source'] and x['corpus'] for x in stages)
    commands=read(run/'commands.json');assert all(Path(x['cwd'])==SOURCE and Path(x['argv'][0])==Path(settings['python']) for x in commands)
    assert all(x['exit']==0 for x in commands if x['stage'] not in {'api','evaluate'})
    evaluation=next(x for x in commands if x['stage']=='evaluate');assert evaluation['exit']==result['evaluation_exit']==result['controller_exit']
    assert evaluation['argv'][evaluation['argv'].index('--expected-support-margin')+1]==str(m)
    assert evaluation['argv'][evaluation['argv'].index('--expected-source-context-policy')+1]=='scoped_note_context_v2'
    health=read(run/'readiness.json');assert health['status']=='ready' and all(health['checks'][x]=='ok' for x in ['database','embeddings','reader','evidence_support'])
    profile=health['runtime']['evidence_profile'];assert profile['contract']=='evidence-profile-v4' and profile['source_context_contract']=='source-note-context-v2' and profile['source_context_policy']=='scoped_note_context_v2'
    assert health['runtime']['evidence_support']['minimum_entailment_margin']==m
    report=read(run/'report.json');assert report['split']=='development' and list(report['results'])==['reranked'] and report['span_integrity_required'] is True
    assert all(report['settings'][k]==v for k,v in settings['settings'].items())
    canonical=scorer.audit_report(report,corpus);assert canonical['verified'] and canonical['case_rows']==80
    documents=scorer.portable_documents(report,corpus);rows=report['results']['reranked']['cases'];mapping={x['case_id']:x for x in rows}
    rescored=[scorer.audit_row(row,cases[row['case_id']],documents,True,settings=report['settings'],arm=report.get('execution_arm'),frozen_runtime=False) for row in rows]
    recomputed=summarize(rescored);assert recomputed==report['results']['reranked']['summary']
    refs=[]
    for case in cases.values():
        response=mapping[case['id']]['observed_response'];selection=(response.get('provenance') or {}).get('answer_selection') or {}
        for ref in case.get('inspection_expected_sources',[]):
            actual=report['source_document_ids'][ref['document_id']]
            matches=[x for x in selection['inspected_sources'] if x['document_id']==actual and x['document_version']==ref['version_number'] and x['content_hash']==ref['content_hash']]
            # One required document identity may span multiple inspected chunks.
            assert matches
            refs.append(dict(case_id=case['id'],authored_id=ref['document_id'],actual_id=actual,version=ref['version_number'],content_hash=ref['content_hash'],matched_chunk_count=len(matches)))
    assert len(refs)==8 and len({x['case_id'] for x in refs})==4
    observed=dict(answerable_correct=recomputed['answerable_correct'],answerable_total=recomputed['answerable_total'],negative_correct=recomputed['negative_correct'],negative_total=recomputed['negative_total'],execution_errors=recomputed['execution_errors'],unauthorized_source_exposures=recomputed['unauthorized_source_exposures'],citation_integrity_failures=recomputed['citation_integrity_failures'],span_integrity_failures=recomputed['span_integrity_failures'])
    eligible=observed['answerable_correct']>=46 and observed['negative_correct']==32 and not any(observed[k] for k in ['execution_errors','unauthorized_source_exposures','citation_integrity_failures','span_integrity_failures'])
    results.append(dict(margin=m,name=name,report_sha256=sha(run/'report.json'),sealed_payload_files=len(seal['files']),preservation_files=preservation[m]['files'],closed=True,controller_exit=result['controller_exit'],source_corpus_models_unchanged=True,canonical_audit=canonical,recomputed=observed,required_opposing_identities=refs,required_opposing_identity_count=8,eligible=eligible))
selected=max([x for x in results if x['eligible']],key=lambda x:(x['recomputed']['answerable_correct'],x['margin']))
assert not {'torch','transformers','sentence_transformers'}.intersection(sys.modules)
after={p:sha(Path(p)) for p in tracked};assert after==tracked
(HERE/'preservation-after.json').write_text(json.dumps(dict(files=after,all_match=True,model_files=all_models),indent=2)+'\n')
answer=dict(scope='Predeclared exposed DEVELOPMENT margin selection only',selection_rule=declared['selection'],selected_margin=selected['margin'],runs=results,canonical_runtime_selection_artifact_supplied=False,locked_runtime_distribution_records_match=16,model_files_match=24,all_preservation_matches=True,all_sources_unchanged_after_audit=True,model_imports=False,inference=False,default_promotion=False,blind_acceptance=False)
(HERE/'audit-result.json').write_text(json.dumps(answer,indent=2)+'\n')
print(json.dumps(dict(selected_margin=selected['margin'],runs=[dict(margin=x['margin'],**x['recomputed'],opposing=x['required_opposing_identity_count'],eligible=x['eligible'],report_sha256=x['report_sha256']) for x in results],model_files_match=24,all_preservation_matches=True),indent=2))
