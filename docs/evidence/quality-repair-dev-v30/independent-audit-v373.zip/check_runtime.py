import hashlib,json,pathlib
out=pathlib.Path(__file__).resolve().parent;q=out.parent
read=lambda p:json.loads(p.read_text())
results=[]
for margin in range(5):
    run=q/f'development-v30-typed-context-v2-locked329-margin{margin}-reranked'
    s=read(run/'execution-settings.json');runtime=read(run/'readiness.json')['runtime']
    for field,binding in [('answer_selection','reader'),('evidence_support','support'),('embedding','embedding')]:
        assert runtime[field]['model']==s['model_binding'][binding]['model']
        assert runtime[field]['revision']==s['model_binding'][binding]['revision']
    assert runtime['answer_selection']['mode']=='reader' and runtime['answer_selection']['threshold']==4 and runtime['answer_selection']['readiness']=='ready'
    assert runtime['evidence_support']['mode']=='local_nli' and runtime['evidence_support']['device']=='cpu' and runtime['evidence_support']['readiness']=='ready'
    assert runtime['evidence_support']['minimum_entailment_margin']==margin
    assert runtime['generation_mode']=='extractive' and runtime['ingestion_mode']=='inline' and runtime['persistence']=='sqlite' and runtime['authentication']=='api-key'
    rows=read(run/'report.json')['results']['reranked']['cases'];checked=0
    for row in rows:
        selection=(row['observed_response'].get('provenance') or {}).get('answer_selection') or {}
        if not selection:continue
        assert selection['mode']=='reader' and selection['model']==s['model_binding']['reader']['model'] and selection['revision']==s['model_binding']['reader']['revision'] and selection['threshold']==4
        support=selection['evidence_support']
        assert support['mode']=='local_nli' and support['model']==s['model_binding']['support']['model'] and support['revision']==s['model_binding']['support']['revision'] and support['minimum_entailment_margin']==margin and support['device']=='cpu'
        p=selection['evidence_profile'];assert p['contract']=='evidence-profile-v4' and p['source_context_policy']=='scoped_note_context_v2' and p['source_context_contract']=='source-note-context-v2'
        checked+=1
    assert checked==80
    results.append(dict(margin=margin,health_runtime_matches=True,observed_response_runtime_matches=checked,report_sha256=hashlib.sha256((run/'report.json').read_bytes()).hexdigest()))
(out/'runtime-check.json').write_text(json.dumps(dict(runs=results,total_responses=400),indent=2)+'\n')
print(json.dumps(dict(health_records=5,observed_response_records=400,all_match=True)))
