# Q362 source30 margin0 development audit — QUIET

2026-10-26. FTH-016; cash unknown. Independent read-only audit of the closed
`development-v30-typed-context-v2-locked329-margin0-reranked` observation only.
Writes are confined to this new review directory. No current W source, API8402,
current DB or unsealed grid run was used or changed.

**Bounded result verified:** the frozen canonical scorer independently re-scores
all80 synthetic DEVELOPMENT cases with48/48 positives and32/32 negatives.
Recall@5 is0.9895833333333334 and MRR0.9652777777777778. Execution errors,
unauthorized-source exposures, citation failures and span failures are all zero.
This exact reranked/margin0 DEV80 observation meets its stated development
qualification counts. It is not blind acceptance, overall completion, default
promotion, method selection or authorization to open a fresh blind set.

## Preservation before inspection and after review

The first executed check hashed all97 source30 preserved files before case
inspection. It also verified the original source29 registry99, locked source29
ablation97 and all231 frozen source30 files. Every hash matched. The same
97+99+97+231 inputs remain unchanged after the audit. All four corpus files
remain unchanged; all24 model asset files and3 model manifests match their
recorded checksums. Locked source29 on the same declared L interpreter remains
FAILED45/48 positives+32/32 negatives. Original source29 evidence remains intact.

- Source30 report SHA256: `30f9536debb5817569c4280b0a76ebbac3ce5482e0134b3413725ea9a81c3ce6`.
- Frozen231-file source manifest SHA256: `fd0e693629aaae190d1d3759784d857a77bac0e45c4fa5b45a83d3efd1879772`.
- Source30 preservation manifest SHA256: `8108e9194088002c37230714fa673134f74073154a35b566b9f50aaf38cefbfc`.
- Original source29 preservation manifest SHA256: `a8feb0192b67c7f54114f38723c1908abdfc62cba5d18a057f2da0a9ea31ff46`.
- Locked source29 preservation manifest SHA256: `679b6ed9b17739eab3bdbbda90782f2f030600af3f41b810e37ae042c0e99383`.
- Unchanged corpus manifest SHA256: `22c7cf7ccbc229d641b26ea359bdb74420c313b411505734681c843a7ba54cf4`.

Full per-file before/after values are in `preservation-before.json` and
`preservation-after.json`.

## Independent evidence checks

The audit imports only the checksummed frozen source30 application and canonical
scorer. The scorer/evaluation/coverage files are byte-identical to source29's
frozen versions. It binds the unchanged corpus and actual captured HTTP
question/answer/citations/source observations, re-scores each case and verifies
the reported fields and aggregate summary. It checked all80 HTTP200 rows against
the recorded runtime configuration. Required facts, ordering, negative refusal
behavior, evidence access and exact spans therefore use the frozen canonical
scoring contract rather than producer pass flags.

All8 required opposing document/version/hash identities are present in actual
inspection provenance across4 cases. The6 context notes each retain22 actual
supported NLI records plus1 mandatory typed reference obligation, for23 total.
The audit reconstructs every complete reading, obligation plan and exact
reference proof from the body and checks the source premise ranges, hypotheses
and assessment arithmetic. The exact obligation has no NLI label, logits,
margin, token, pair or hypothesis fields. Canonical reconstruction preserves all
25 occurrences, exact slots, card/event distinction, cover ownership,
two-member conjunction guard, generic negative predicate, raw/adopted domains
and complete-body edges. Exact linkage does not stand in for the22 NLI results.

Sixteen actual procedure outputs replay successfully against the actual question,
answer, citations, frozen sources and retained capture. The immutable run DB was
opened read-only with SQLite `mode=ro&immutable=1`. All80 captured query records
equal persisted question, answer, outcome, refusal, sources, provenance and trace.
All76 immutable source versions and175 chunk identities/order/literals equal
their corpus-bound snapshots. This is persisted-history evidence; no live GET
or model rerun was performed.

Recorded settings and readiness agree on body-source mode, typed context v2,
evidence-profile-v4, margin0, QA null threshold4, composite proposals, activity
scope, source-declared copying, local NLI and extractive output. Model binding
records equal the locked source29 ablation records. All16 L runtime distribution
versions/RECORD hashes still match `locked-runtime-before-source30.json`, read
without importing model packages.

The run's94-payload SEALED inventory matches, declares children closed and allows
inspection. The recorded owned process source points to frozen source30, and its
PID agrees with successful tree-kill cleanup and closed-port evidence. Inventory,
migration, seeding and evaluation commands exit0; evaluator/controller exit0.
The API command records exit1 after owned taskkill. The first reviewer attempt
wrongly required every command exit0, failed before case replay, and was corrected
using the explicit cleanup evidence; both reviewer logs are retained.

## Limits and next owner

Torch, Transformers and sentence_transformers imports were explicitly blocked;
none was imported. No inference, model/API server, browser, install, build,
provider, corpus/label/threshold edit or credential export occurred. No current
API port was polled because root is reusing8402 for separate grid work. Process
closure is established from the sealed per-run records, not a claim that the
currently reused port is closed.

Canonical `runtime_verification.verified` remains false because this development
observation has no final frozen selection artifact. The separate checks bind
recorded settings/source/runtime distribution records; installed binaries were
not independently rehashed. This result does not establish a general model
guarantee or the later114/120+80/80 blind/improvement/evidence gates.

No material contradiction was found in this bounded margin0 DEV80 observation.
Exact commands/exits are in `commands-and-results.json`; detailed results are in
`audit-result.json`. Root owns the separate grid/method work, later candidate
freeze and any subsequent blind qualification decisions. Reviewer Q362 is QUIET.
