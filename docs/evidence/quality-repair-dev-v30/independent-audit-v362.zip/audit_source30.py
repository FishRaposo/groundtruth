"""Independent frozen-source30 DEV80 replay; no model/API/current-W authority."""
from __future__ import annotations
import hashlib
import importlib.abc
import importlib.metadata
import importlib.util
import json
import os
import sqlite3
import sys
from pathlib import Path
from uuid import UUID

HERE=Path(__file__).resolve().parent
Q=HERE.parent
SOURCE=Q/'requirements-source-v30'
RUN=Q/'development-v30-typed-context-v2-locked329-margin0-reranked'
CORPUS=Q/'dev-arm-candidate-v115'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (HERE/'preservation-before.json').is_file()
before=read(HERE/'preservation-before.json')
assert all(x['all_match'] for x in before.values())

class NoModels(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'torch','transformers','sentence_transformers'}:
            raise AssertionError('Model import forbidden by independent Q362 audit')

sys.meta_path.insert(0,NoModels())
sys.dont_write_bytecode=True
sys.path.insert(0,str(SOURCE/'apps/api'))
os.environ['DATABASE_URL']='sqlite+aiosqlite:///:memory:'
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'

settings=read(RUN/'execution-settings.json')
assert sha(Q/'requirements-source-v30.json')==settings['source_manifest_sha256']
assert sha(CORPUS/'manifest.json')==settings['corpus_manifest_sha256']=='22c7cf7ccbc229d641b26ea359bdb74420c313b411505734681c843a7ba54cf4'
corpus_files={name:sha(CORPUS/name) for name in ('cases.json','documents.json','manifest.json','profile.json')}
for name,digest in read(CORPUS/'manifest.json')['files'].items():
    assert corpus_files[name]==digest
oldsettings=read(Q/'development-v29-context-v1-runtime-locked329-margin0-reranked/execution-settings.json')
assert settings['corpus_manifest_sha256']==oldsettings['corpus_manifest_sha256']
assert settings['model_binding']==oldsettings['model_binding']
for name,digest in read(Q/'requirements-source-v29.json')['files'].items():
    if name in {'scripts/verify_answer_coverage_delivery.py','apps/api/app/portfolio/evaluation.py','apps/api/app/portfolio/coverage.py'}:
        assert sha(SOURCE/name)==digest

for key,value in {
    'support_min_margin':0, 'reader_null_threshold':4, 'top_k':5,
    'answer_proposal_profile':'qa_plus_source_patterns_v1',
    'role_scope_policy':'ordinary_session_activity_v1',
    'procedure_verification_profile':'source_declared_procedure_copy_v1',
    'source_context_policy':'scoped_note_context_v2',
    'answer_selection_mode':'reader','answer_support_mode':'local_nli',
    'generation_mode':'extractive','selection_contract':'requirement-evidence-v2',
}.items():
    assert settings['settings'][key]==value
assert settings['environment_overrides']['SOURCE_CONTEXT_MODE']=='body'
assert settings['environment_overrides']['SOURCE_CONTEXT_POLICY']=='scoped_note_context_v2'
assert settings['environment_overrides']['INGESTION_MODE']=='inline'
assert str(SOURCE)==str(Path(settings['source']))
seal=read(RUN/'SEALED.json')
assert seal['children_closed'] is True and seal['inspection_allowed'] is True
for name,digest in seal['files'].items():assert sha(RUN/name)==digest
cleanup=read(RUN/'cleanup.json');process=read(RUN/'process.json')
assert cleanup['stopped'] and cleanup['port_closed'] and cleanup['tree_kill_exit']==0
assert cleanup['pid']==process['owned_pid'] and Path(process['source'])==SOURCE
assert read(RUN/'result.json')['controller_exit']==read(RUN/'result.json')['evaluation_exit']==0
checks=read(RUN/'input-checks.json')
assert len(checks)==10 and all(x['source'] and x['corpus'] for x in checks)
commands=read(RUN/'commands.json')
assert all(row['cwd']==str(SOURCE) for row in commands)
assert all(row['exit']==0 for row in commands if row['stage']!='api')
assert next(row for row in commands if row['stage']=='api')['exit']==1
assert all(Path(row['argv'][0])==Path(settings['python']) for row in commands)
assert 'requirements-source-v30' in (RUN/'inventory.log').read_text()

# Compare frozen L runtime distribution metadata without importing any library.
runtime=read(Q/'locked-runtime-before-source30.json')
site=Path(runtime['executable']).parent.parent/'Lib/site-packages'
normalize=lambda n:n.lower().replace('_','-').replace('.','-')
installed={normalize(d.metadata['Name']):d for d in importlib.metadata.distributions(path=[str(site)]) if d.metadata['Name']}
for name,value in runtime['packages'].items():
    dist=installed[normalize(name)]
    assert dist.version==value['version']
    assert sha(Path(dist._path)/'RECORD')==value['record_sha256']
assert len(runtime['packages'])==16

from app.portfolio import load_corpus
assert Path(sys.modules['app.portfolio'].__file__).resolve().is_relative_to(SOURCE)
corpus=load_corpus(CORPUS,expected_representation_profile='connected-paragraphs-v1',expected_common_manifest_sha256=settings['common_manifest_sha256'])
spec=importlib.util.spec_from_file_location('independent_frozen_source30_scorer',SOURCE/'scripts/verify_answer_coverage_delivery.py')
scorer=importlib.util.module_from_spec(spec);spec.loader.exec_module(scorer)
report=read(RUN/'report.json')
assert report['split']=='development' and list(report['results'])==['reranked']
assert report['span_integrity_required'] is True
assert all(report['settings'][k]==v for k,v in settings['settings'].items())
canonical=scorer.audit_report(report,corpus)
assert canonical['verified'] and canonical['case_rows']==80
assert canonical['runtime_verification']['verified'] is False
summary=report['results']['reranked']['summary']
for key,value in {'cases':80,'passed':80,'failed':0,'answerable_total':48,'answerable_correct':48,'negative_total':32,'negative_correct':32,'execution_errors':0,'unauthorized_source_exposures':0,'citation_integrity_failures':0,'span_integrity_failures':0}.items():assert summary[key]==value

from app.portfolio.coverage import _procedure_output_context
from app.services.procedure_output import verify_output
from app.services.source_context_scope import parse_context_note,semantic_checks
from app.services.source_context_references import compile_reference_obligation,obligation_plan,exact_structure_equal
from app.services.requirement_contract import valid_condition_assessment
documents=scorer.portable_documents(report,corpus)
cases={x['id']:x for x in corpus['cases'] if x['split']=='development'}
rows=report['results']['reranked']['cases'];bycase={x['case_id']:x for x in rows}
identities=[];context_notes=[];output_replays=0
for case in cases.values():
    row=bycase[case['id']];response=row['observed_response']
    selection=(response.get('provenance') or {}).get('answer_selection') or {}
    for ref in case.get('inspection_expected_sources',[]):
        actual=report['source_document_ids'][ref['document_id']]
        assert any(x['document_id']==actual and x['document_version']==ref['version_number'] and x['content_hash']==ref['content_hash'] for x in selection['inspected_sources'])
        identities.append({'case_id':case['id'],'authored_id':ref['document_id'],'actual_id':actual,'version':ref['version_number'],'hash':ref['content_hash']})
    context=_procedure_output_context(case,response,documents)
    if context and response.get('answer'):
        assert verify_output(selection,**context)
        output_replays+=1
    for conflict in selection.get('conflicts',[]):
        for extent in conflict.get('source_extent_checks',[]):
            scope=extent.get('condition_scope')
            if not scope or scope.get('contract')!='procedure-condition-scope-v3':continue
            reading=scope['context_reading'];adopted=reading['adopted_context']
            rebuilt=parse_context_note(reading['source_body'],adopted['operation'],adopted['state'],policy='scoped_note_context_v2')
            assert exact_structure_equal(reading,rebuilt)
            assert exact_structure_equal(scope['obligation_plan'],obligation_plan(rebuilt))
            assert exact_structure_equal(scope['reference_obligations'],[compile_reference_obligation(rebuilt)])
            checks=scope['semantic_checks'];assert len(checks)==22
            assert [x['name'] for x in checks]==[x['name'] for x in semantic_checks(rebuilt)]
            exact=scope['reference_obligations'][0]
            assert not {'label','logits','entailment_margin','pair_tokens','pair','hypothesis'}.intersection(exact)
            assert scope['obligation_plan']['mandatory_obligation_count']==23
            assert all(valid_condition_assessment(x['assessment'],scope['model_settings']) for x in checks)
            for check in checks:
                span=check['premise_range'];assert reading['source_body'][span['start']:span['end']]==check['pair']['premise']
                assert check['hypothesis']==check['pair']['hypothesis']
            context_notes.append({'case_id':case['id'],'actual_id':extent['document_id'],'actual_nli':22,'exact_reference_obligations':1,'typed_references':len(exact['reference_plan']['reference_occurrences'])})
assert len(identities)==8 and len({x['case_id'] for x in identities})==4
assert len(context_notes)==6

# Cross-bind retained HTTP answers/proofs/capture to immutable persisted history.
db=sqlite3.connect((RUN/'data/groundtruth.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
db.row_factory=sqlite3.Row
history=0;version_count=0;chunk_count=0
for row in rows:
    response=row['observed_response']
    if not response.get('id'):continue
    saved=db.execute('SELECT * FROM queries WHERE id=?',(UUID(response['id']).hex,)).fetchone()
    assert saved is not None
    for field in ('question','answer','outcome','refusal_reason'):assert saved[field]==response[field]
    assert bool(saved['refused'])==response['refused']
    for field in ('provenance','sources','retrieval_trace'):assert json.loads(saved[field])==response[field]
    history+=1
for logical,document in documents.items():
    for number,snapshot in document.get('source_snapshots',{}).items():
        saved=db.execute('SELECT * FROM document_versions WHERE document_id=? AND version_number=?',(UUID(document['document_id']).hex,int(number))).fetchone()
        assert saved is not None and saved['normalized_content']==snapshot['body'] and saved['content_hash']==snapshot['content_hash']
        chunks=json.loads(saved['chunks'])
        assert [(str(UUID(x['id'])),x['index'],x['content']) for x in chunks]==[(x['id'],x['index'],x['content']) for x in snapshot['chunks']]
        version_count+=1;chunk_count+=len(chunks)
db.close()
assert 'torch' not in sys.modules and 'transformers' not in sys.modules and 'sentence_transformers' not in sys.modules
result={'scope':'Independent frozen-source30 margin0 synthetic DEVELOPMENT80 audit only','report_sha256':sha(RUN/'report.json'),'source_manifest_sha256':sha(Q/'requirements-source-v30.json'),'corpus_files':corpus_files,'summary':summary,'frozen_canonical_scorer':canonical,'recorded_process_closed_and_sealed':True,'sealed_payload_files':len(seal['files']),'runtime_distribution_records_match':16,'opposing_identities':identities,'typed_context_notes':context_notes,'canonical_output_replays':output_replays,'persisted_history_rows_equal':history,'immutable_db_versions_equal':version_count,'immutable_db_chunks_equal':chunk_count,'model_imports':False,'inference':False,'blind_acceptance':False,'overall_completion':False}
(HERE/'audit-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in {'opposing_identities','typed_context_notes','corpus_files'}},indent=2))
