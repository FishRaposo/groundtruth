"""Verify every preservation input before inspecting case outcomes."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
Q = HERE.parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifests = {
    "source30": "development-v30-typed-context-v2-locked329-margin0-reranked-preservation.json",
    "source29_first": "development-v29-first-result-preservation.json",
    "source29_locked": "development-v29-context-v1-runtime-locked329-margin0-reranked-preservation.json",
}
results = {}
for label, name in manifests.items():
    value = json.loads((Q / name).read_text(encoding="utf-8"))
    rows = [{"path": path, "expected": expected, "actual": sha(Q / path)} for path, expected in value["files"].items()]
    assert all(row["expected"] == row["actual"] for row in rows), label
    results[label] = {"manifest": name, "manifest_sha256": sha(Q / name), "count": len(rows), "all_match": True, "files": rows}
assert results["source30"]["count"] == 97
assert results["source29_first"]["count"] == 99
assert results["source29_locked"]["count"] == 97
source = json.loads((Q / "requirements-source-v30.json").read_text(encoding="utf-8"))
rows = [{"path": path, "expected": expected, "actual": sha(Q / "requirements-source-v30" / path)} for path, expected in source["files"].items()]
assert len(rows) == 231 and all(row["expected"] == row["actual"] for row in rows)
results["frozen_source30"] = {"manifest_sha256": sha(Q / "requirements-source-v30.json"), "count": len(rows), "all_match": True, "files": rows}
(HERE / "preservation-before.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
print(json.dumps({label: {key: value for key, value in result.items() if key != "files"} for label, result in results.items()}, indent=2))
