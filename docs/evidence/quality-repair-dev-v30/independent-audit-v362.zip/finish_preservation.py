"""After-review read-only preservation and model-file checks; no inference."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;Q=HERE.parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
before=read(HERE/'preservation-before.json');after={}
for label,record in before.items():
    root=Q/'requirements-source-v30' if label=='frozen_source30' else Q
    rows=[]
    for row in record['files']:
        actual=sha(root/row['path'])
        assert actual==row['expected']==row['actual']
        rows.append({'path':row['path'],'before':row['actual'],'after':actual})
    after[label]={'count':len(rows),'unchanged':True,'files':rows}
run=Q/'development-v30-typed-context-v2-locked329-margin0-reranked'
settings=read(run/'execution-settings.json')
models=[]
for kind,binding in settings['model_binding'].items():
    root=Path(binding['root'])
    assert sha(root/binding['manifest'])==binding['manifest_sha256']
    for name,expected in binding['files'].items():
        actual=sha(root/name);assert actual==expected
        models.append({'kind':kind,'name':name,'sha256':actual})
assert len(models)==24
audit=read(HERE/'audit-result.json')
for name,expected in audit['corpus_files'].items():assert sha(Q/'dev-arm-candidate-v115'/name)==expected
old=read(Q/'development-v29-context-v1-runtime-locked329-margin0-reranked/report.json')['results']['reranked']['summary']
assert old['answerable_correct']==45 and old['answerable_total']==48 and old['negative_correct']==old['negative_total']==32
result={'all_before_after_unchanged':True,'groups':after,'corpus_files_unchanged':4,'model_files_match':models,'model_manifests_match':3,'source29_locked_summary':old}
(HERE/'preservation-after.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_before_after_unchanged':True,'groups':{k:v['count'] for k,v in after.items()},'corpus_files_unchanged':4,'model_files_match':24,'model_manifests_match':3,'source29_locked_positive':45,'source29_locked_negative':32},indent=2))
