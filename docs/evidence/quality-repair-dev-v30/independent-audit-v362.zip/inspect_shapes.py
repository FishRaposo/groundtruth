import json, sqlite3
from pathlib import Path
Q=Path(__file__).resolve().parent.parent
R=Q/'development-v30-typed-context-v2-locked329-margin0-reranked'
r=json.loads((R/'report.json').read_text())
row=r['results']['reranked']['cases'][0]
readiness=json.loads((R/'readiness.json').read_text())
output={'report_keys':list(r),'row_keys':list(row),'response_keys':list(row['observed_response']), 'source_manifest_keys':list(r['source_manifest']),'readiness_keys':list(readiness), 'settings':r['settings']}
seed=json.loads((R/'data/seed-manifest.json').read_text())
output['seed_structure']={k:type(v).__name__ for k,v in seed.items()}
output['observation_structure']={k:type(v).__name__ for k,v in next(iter(r['source_manifest']['documents'].values()))[0].items()}
c=sqlite3.connect((R/'data/groundtruth.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
output['tables']={table:[column[1] for column in c.execute('pragma table_info('+table+')')] for table in ('queries','document_versions','documents','chunks')}
c.close()
print(json.dumps(output,indent=2))
