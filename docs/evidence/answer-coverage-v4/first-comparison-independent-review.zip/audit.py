"""Offline audit only: frozen bytes and stored responses; no model/API calls."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile
from datetime import datetime
from collections import Counter

OUT = Path(__file__).resolve().parent
S = OUT.parents[2]
W = S / 'delivery-worktree'
E = W / 'docs/evidence/answer-coverage-v4'
C = W / 'apps/api/app/portfolio/assets/coverage-blind-v4'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args])
def blobs(revision, paths):
    queries = [revision + ':' + name for name in paths]
    stream = io.BytesIO(subprocess.run(['git', '-C', str(W), 'cat-file', '--batch'], input=('\n'.join(queries)+'\n').encode(), stdout=subprocess.PIPE, check=True).stdout)
    result = {}
    for name in paths:
        header = stream.readline().split()
        assert header[1] == b'blob', (name, header)
        result[name] = stream.read(int(header[2]))
        assert stream.read(1) == b'\n'
    return result

f, seal, cf, binding = [read(E / p) for p in ['candidate-freeze.json', 'first-comparison-seal.json', 'blind-corpus-freeze.json', 'validation-binding.json']]
result = {'hashes': {}, 'archives': {}, 'issues': []}
for sidecar in sorted(E.glob('*.sha256')):
    path = sidecar.with_name(sidecar.name.removesuffix('.sha256'))
    digest = sha(path.read_bytes())
    assert sidecar.read_text().split()[0].lower() == digest
    result['hashes'][path.name] = digest
assert result['hashes']['first-comparison-seal.json'] == '787ed5101e35aea4e583b150adc279592494ee06f1ffb0fc76c50043dddc5388'
assert sha((E/'candidate-freeze.json').read_bytes()) == seal['candidate_freeze_sha256'] == binding['candidate_freeze_sha256']
assert sha((E/'validation-binding.json').read_bytes()) == seal['binding_sha256']
assert sha((C/'manifest.json').read_bytes()) == seal['corpus_manifest_sha256'] == cf['corpus_manifest_sha256']
for name, expected in cf['corpus_files'].items():
    assert sha((C/name).read_bytes()) == expected
source_before = {n: sha((W/n).read_bytes()) for n in f['source_files_sha256']}
assert source_before == f['source_files_sha256']
canonical = blobs(f['candidate_commit'], list(f['git_source_files_sha256']))
assert {n:sha(b) for n,b in canonical.items()} == f['git_source_files_sha256']
for n, b in canonical.items():
    assert (W/n).read_bytes().replace(b'\r\n',b'\n') == b.replace(b'\r\n',b'\n'), n
result['candidate_bindings'] = {'raw':len(source_before), 'git':len(canonical)}
base = read(E/'baseline-source-binding.json')
basegit = blobs(f['baseline_commit'], list(base['python_source']))
for name, record in base['python_source'].items():
    actual = (S/'baseline-source'/name).read_bytes()
    assert sha(actual) == record['observed_windows_sha256']
    assert sha(basegit[name]) == record['git_canonical_sha256']
    assert actual.replace(b'\r\n',b'\n') == basegit[name].replace(b'\r\n',b'\n')
result['baseline_bindings'] = len(basegit)
for p in sorted(E.glob('*.zip')):
    with zipfile.ZipFile(p) as z:
        hashes = json.loads(z.read('archive-file-hashes.json'))
        assert set(z.namelist()) == set(hashes) | {'archive-file-hashes.json'}
        for name, expected in hashes.items():
            assert sha(z.read(name)) == expected
        result['archives'][p.name] = len(hashes)
        if p.name == 'blind-author-inputs-v1.zip':
            for name in ['cases.json','documents.json']:
                assert z.read(name) == (C/name).read_bytes()
            author_freeze = json.loads(z.read('FREEZE_SHA256.json'))
            result['author_freeze_record'] = author_freeze
            (OUT/'author-handoff-copy.md').write_bytes(z.read('AUTHOR_HANDOFF.md'))
times = {k:datetime.fromisoformat(v) for k,v in {'candidate':f['frozen_at'],'author':cf['author_frozen_at'],'binding':cf['bound_at'],'started':seal['started_at'],'sealed':seal['sealed_at']}.items()}
assert times['candidate'] < times['author'] < times['binding'] < times['started'] < times['sealed']
result['chronology'] = {k:v.isoformat() for k,v in times.items()}
result['commit_times'] = {r:git('show','-s','--format=%cI %s',r).decode().strip() for r in [f['candidate_commit'],'8f49632','75e652f']}
assert 'apps/api/app/portfolio/assets/coverage-blind-v4/cases.json' not in git('ls-tree','-r','--name-only',f['candidate_commit']).decode().splitlines()
for p in ['candidate-freeze.json','candidate-freeze.json.sha256']:
    assert git('show','8f49632:docs/evidence/answer-coverage-v4/'+p) == (E/p).read_bytes()
for name in cf['corpus_files']:
    assert git('show','75e652f:apps/api/app/portfolio/assets/coverage-blind-v4/'+name) == (C/name).read_bytes()
assert seal['source_runtime_assets_corpus_unchanged'] and not seal['post_state_issues']
reports = {arm:read(E/('first-'+arm+'-blind-v4.json')) for arm in ['baseline','candidate']}
for record in seal['reports']:
    assert sha((E/record['path']).read_bytes()) == record['sha256']
    assert (S/record['path']).read_bytes() == (E/record['path']).read_bytes()
    assert record['case_rows'] == 800 and record['exit_code'] == 1
assert json.loads((OUT/'portable-verifier.log').read_text(encoding='utf-16') if (OUT/'portable-verifier.log').read_bytes().startswith(b'\xff\xfe') else (OUT/'portable-verifier.log').read_text(encoding='utf-8-sig')) == read(E/'first-comparison-gate.json')
cases = {x['id']:x for x in read(C/'cases.json')}
docs = {x['id']:x for x in read(C/'documents.json')}
sample_ids = ['v4-01-a4','v4-01-a5','v4-01-a6','v4-02-a3','v4-11-a2','v4-16-a5','v4-17-a1']
samples = []
for row in reports['candidate']['results']['reranked']['cases']:
    if row['category'] != 'answerable' and not row['answer_quality_passed'] or row['case_id'] in sample_ids:
        case = cases[row['case_id']]
        response = row['observed_response']
        selection = (row.get('provenance') or {}).get('answer_selection') or {}
        candidates = selection.get('candidates',[])
        chunkmap = {x['chunk_id']:x for x in row['retrieval_trace']['scores']}
        reverse = {v:k for k,v in reports['candidate']['source_document_ids'].items()}
        diagnostic = []
        for candidate in candidates:
            identity = chunkmap.get(candidate['chunk_id'])
            if not identity:
                continue
            logical = reverse[identity['document_id']]
            version = next(x for x in docs[logical]['versions'] if x['version_number']==identity['document_version'])
            # The frozen fixture snapshots are single canonical chunks, so these
            # raw-offset excerpts are diagnostic only; actual source spans are
            # independently verified by the frozen portable verifier.
            raw = candidate.get('raw_span') or {}
            diagnostic.append({'document':logical,'decision':candidate['decision'],'margin':candidate.get('null_margin'),'raw_offset_excerpt':version['content'][raw['start']:raw['end']] if raw else None,'parts':candidate.get('question_parts'), 'part_decisions':[{k:p.get(k) for k in ['index','decision','support_rejection','evidence_rejection','null_margin']} for p in candidate.get('parts',[])]})
        samples.append({'id':case['id'],'question':case['question'],'required_facts':case['required_facts'],'ordered_steps':case['ordered_steps'],'expected_sources':case['expected_sources'],'rationale':case['label_rationale'],'refused':row['refused'],'answer':response.get('answer'),'sources':response.get('sources'),'diagnostic_candidates':diagnostic,'citation_selection':selection.get('citation_selection')})
(OUT/'samples.json').write_text(json.dumps(samples,indent=2,ensure_ascii=False),encoding='utf-8')
rows = reports['candidate']['results']['reranked']['cases']
result['candidate_positive_failures'] = {'total':sum(x['category']=='answerable' and not x['answer_quality_passed'] for x in rows),'refused':sum(x['category']=='answerable' and x['refused'] for x in rows),'answered_incorrect':sum(x['category']=='answerable' and not x['refused'] and not x['answer_quality_passed'] for x in rows)}
result['negative_failure_ids'] = [x['case_id'] for x in rows if x['category']!='answerable' and not x['answer_quality_passed']]
result['sample_ids'] = [x['id'] for x in samples]
emitted = 0
for method in reports['candidate']['results'].values():
    for row in method['cases']:
        response = row['observed_response']
        if not response.get('refused') and response.get('answer'):
            extracts = []
            for i, source in enumerate(response['sources'],1):
                assert len(source['answer_spans']) == 1
                extracts.append(source['answer_spans'][0]['text'] + f' [{i}]')
            assert response['answer'] == 'Source extracts (not model-generated):\n\n' + '\n\n'.join(extracts)
            emitted += 1
result['literal_candidate_answer_assemblies_verified'] = emitted
source_after = {n:sha((W/n).read_bytes()) for n in source_before}
assert source_after == source_before
(OUT/'source-before.json').write_text(json.dumps(source_before,indent=2),encoding='utf-8')
(OUT/'source-after.json').write_text(json.dumps(source_after,indent=2),encoding='utf-8')
(OUT/'audit-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='author_freeze_record'},indent=2))
