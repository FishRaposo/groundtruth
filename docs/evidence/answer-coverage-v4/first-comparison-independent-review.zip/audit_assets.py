"""Hash existing frozen selected assets; no model imports or execution."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
O = Path(__file__).resolve().parent
S = O.parents[2]
W = S/'delivery-worktree'
F = json.loads((W/'docs/evidence/answer-coverage-v4/candidate-freeze.json').read_text())
roots = {'reader_assets':S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4','embedding_assets':W.parents[2]/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41'}
result = {'files':{},'runtime':{}}
for label, root in roots.items():
    result['files'][label] = {}
    for name, expected in F[label]['files'].items():
        digest = hashlib.sha256()
        with (root/name).open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):
                digest.update(block)
        assert digest.hexdigest() == expected, (label,name)
        result['files'][label][name] = digest.hexdigest()
for name, expected in F['runtime'].items():
    actual = platform.python_version() if name=='python' else importlib.metadata.version(name)
    assert actual==expected,(name,actual,expected)
    result['runtime'][name] = actual
(O/'asset-runtime-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'verified_asset_files':sum(map(len,result['files'].values())),'runtime':result['runtime']},indent=2))
