"""Independent non-model fixtures showing boundaries seen in sealed results."""
import json
from pathlib import Path
import sys
import types
if '--frozen' in sys.argv:
    # Bypass service-package convenience imports (unrelated model dependencies).
    # The two implementation modules themselves remain exact Git bytes.
    for package, relative in [('app','app'),('app.services','app/services')]:
        module = types.ModuleType(package)
        module.__path__ = [str(Path(__file__).parent/'frozen-source'/relative)]
        sys.modules[package] = module
from app.services.reader_questions import question_parts, scope_matches, mismatch_reason

results = []
def check(name, expected, observed):
    results.append({'name':name,'expected':expected,'observed':observed,'passed':expected==observed})

parts = question_parts('As the source owner, what planned size is recorded for the alternate sheet?')
check('discourse_prefix_is_not_an_extra_question',1,len(parts))
check('role_prefix_is_not_a_named_source_entity',True,all(scope_matches(p,'The planned size of the alternate sheet is 31 test cells.') for p in parts))
parts = question_parts('I am preparing the Willow workbook. Copy the entire procedure in its stated order.')
check('copy_instruction_is_not_a_named_source_entity',True,scope_matches(parts[0],'Willow workbook. Complete procedure: 1. Duplicate the worksheet. 2. Recalculate the sandbox.'))
parts = question_parts('For the Willow workbook, identify the review owner plus the session day and start time.')
check('compound_nominal_request_is_not_one_coverage_unit',True,len(parts)>1)
context = 'The review of the Willow workbook takes 23 minutes.'
start = context.index('23 minutes')
check('explicit_payment_request_rejects_duration',True,mismatch_reason('What exact amount must a participant pay for the Willow workbook review?', context,start,start+len('23 minutes')) is not None)
context = 'The coordinator accepts reservations for the Willow workbook until four days before the session.'
start = context.index('four days')
check('review_duration_does_not_borrow_reservation_deadline',True,mismatch_reason('How long does the review of the Willow workbook take?',context,start,start+len('four days')) is not None)
check('positive_explicit_compound_control',2,len(question_parts('Who owns the Willow workbook review, and how long is that review?')))
context = 'The Willow workbook review takes 23 minutes.'
start = context.index('23 minutes')
check('positive_duration_control',None,mismatch_reason('How long does the Willow workbook review take?',context,start,start+len('23 minutes')))
out = Path(__file__).with_name('boundary-probe-result.json')
out.write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
raise SystemExit(1 if any(not r['passed'] for r in results) else 0)
