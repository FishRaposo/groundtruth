# Raw author handoff

Status: source packet authored, independently source-checked, and frozen before any author-side measurement.

Author: independent-synthetic-author-v4. Synthetic agent-authored labels; no human validation.
Authoring started UTC: 2026-10-24T10:25:01.4054873Z.
Authoring/raw-freeze completed UTC: 2026-10-24T10:31:13.603923+00:00.
Candidate freeze timestamp supplied in assignment: 2026-10-24T10:22:31.244855Z. The candidate freeze artifact and its internals were not inspected.

Composition: 200 held_out/blind cases: 120 answerable, 40 unanswerable, 20 conflicting_stale, 20 adversarial. There are 20 fresh semantic families, 100 logical documents, and 120 contiguous-version immutable snapshots. Forty positives genuinely need two logical documents. Twenty complete procedures have four steps each (80 ordered step groups). All 120 positives have nonempty source-backed required_facts (260 groups), 160 exact current quotations, and nonempty exact acceptable spans. Four cases explicitly declare a source scope; all remaining document_ids are null.

Authority composition: 4 owner-private positives; 10 other-user-private adversarial refusals; 10 cross-workspace public-source adversarial refusals; 10 stale-only current-fact refusals; 10 curated incompatible-current-exception reviews; 20 absent-price refusals; 20 explicit wrong-entity refusals. Both ops-a aliases are active case principals; custodian-b owns ops-b sources. Public/organization/private visibility, negation, quantities, durations, roles, grammatical variants, and nearby misleading facts are included.

Checks run: python author_corpus.py; python check_corpus.py (exit 0). The separate standard-library checker verified counts, uniqueness, 20-family ID exclusion, UTF-8/LF and no BOM, canonical source whitespace, every source/file SHA256, contiguous versions, current-version citations, quoted substrings, nonempty fact and step alternatives with normalized word boundaries, complete ordered coverage, one grounded fact per necessary document, all permissions, explicit scopes, all forbidden references, negative empty answer fields, source ownership, ten matching curated conflict groups, and all 200 label records. The author separately read generated family specifications/questions and reviewed subject novelty and substantive conflict semantics; see INDEPENDENT_REVIEW.md, label-review.json and validation-report.json.

Execution settings: deliberately deferred. profile.json contains only schema_version, revision and a deferral note. Preserve this raw author manifest before integrating a separately supplied frozen operational profile; source/question/label bytes must remain unchanged.

Rights: GroundTruth project; MIT; no third-party content. Fixtures are invented test material, not real professional instructions. No credentials, real personal data or real clients.

Limits: source-backed authored expectations, not a human gold standard, general entailment certification, performance measurement, or representative natural-world benchmark distribution. Semantic novelty and contradiction are agent judgments. No implementation, configuration, previous results/questions, threshold, memory, repository onboarding, network/API/model execution, peer agent or project validator was accessed. Inputs were not modified. No blocker or schema ambiguity was encountered.

Input hashes:

- CONTRACT.md: `c3633c562d339dcfab0d5230b2c5bd2a12623300a00696e78386b9467f8b5d9a`
- excluded-families.json: `4d5e29190024f0a3dd381e6b09f3cc4bc09fd6cfe0f43ad30177d616d40d113d`

Frozen artifact SHA256 values:

- documents.json: `d5150627dfcc3d4c2755610042b76ffdf85c1bd839ca1a44a50ba8265bf09c8f`
- cases.json: `351fb6a33d574014002deb6f4559df2a731f7ec62ae8647f2f054f9bb91c0ecc`
- profile.json: `95be021b31ba1815fcecef765a0b67578006c615c62ad00c4367e49ad9ddfe71`
- manifest.json: `ed94aab66626e0ab6a9c08994089d560e8bc08ad961acdf6627a4bb1829c2281`
- author_corpus.py: `12e367cb62992e8babe1016341d399b6556bc80b1617d1e3271ac93c69eeb445`
- check_corpus.py: `a85dc26bb8bfb609b28c4cb503993ea7b037bc569ffdc0e287019cafde4053de`
- label-review.json: `8b04498a106ce351d521109a741ae1f8c266a860d2efa4576be5ac416fd09422`
- validation-report.json: `2dd59d4397337715ccb800e9288cfcf9e1fb07551ec04dfd4bbdd57e8128c226`
- INDEPENDENT_REVIEW.md: `65a2abd2963ba70bd84de38d7796b5b169afb44456e0a8583391578e827c172f`

FREEZE_SHA256.json also records this handoff hash. Its own hash is returned in the final handoff to avoid circular hashing.
