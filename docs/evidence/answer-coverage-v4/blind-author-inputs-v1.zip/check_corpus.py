"""Independent offline source/label checks, using standard-library code only."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json, hashlib, re

P=Path(__file__).resolve().parent
def read(n): return json.loads((P/n).read_text(encoding='utf-8'))
def canon(s): return ' '.join(s.split())
def digest(b): return hashlib.sha256(b).hexdigest()
def norm(s): return canon(s).casefold()
def grounded(phrase,quote): return bool(re.search(r'(?<!\w)'+re.escape(norm(phrase))+r'(?!\w)',norm(quote)))
documents=read('documents.json'); cases=read('cases.json'); manifest=read('manifest.json'); profile=read('profile.json')
excluded=json.loads((P.parent/'blind-v4-contract'/'excluded-families.json').read_text(encoding='utf-8'))
byid={d['id']:d for d in documents}
assert len(byid)==len(documents)==100
assert len({c['id'] for c in cases})==len(cases)==200
assert len({c['question'] for c in cases})==200
counts=Counter(c['category'] for c in cases)
assert counts=={'answerable':120,'unanswerable':40,'conflicting_stale':20,'adversarial':20}
families=set(d['family'] for d in documents)
assert len(families)==20 and families.isdisjoint(x['family'] for x in excluded['excluded'])
assert all(d['split']=='held_out' for d in documents)
assert set(profile)=={'schema_version','revision','note'} and profile['schema_version']==2
assert manifest['schema_version']==2 and manifest['corpus_role']=='blind'
assert manifest['expected_counts']=={'held_out':dict(counts)}
assert manifest['document_count']==len(documents) and manifest['case_count']==len(cases)
assert manifest['rights']=={'owner':'GroundTruth project','license':'MIT','third_party_content':False}
assert set(manifest['files'])=={'documents.json','cases.json','profile.json'}
for name,hashvalue in manifest['files'].items(): assert digest((P/name).read_bytes())==hashvalue
for d in documents:
    assert d['owner'] in manifest['principals']
    assert d['workspace_id']==manifest['principals'][d['owner']]['workspace_id']
    assert d['visibility'] in ['public','organization','private']
    assert [v['version_number'] for v in d['versions']]==list(range(1,len(d['versions'])+1))
    assert d['current_version_number']==len(d['versions'])
    for v in d['versions']:
        assert v['content']==canon(v['content'])
        assert digest(v['content'].encode())==v['content_hash']

def authorized(d,p):
    return d['workspace_id']==manifest['principals'][p]['workspace_id'] and (d['visibility']!='private' or d['owner']==p)

multi=procedures=positive_facts=step_groups=quotes=0
label_checks=[]
for c in cases:
    assert c['family'] in families and c['split']=='held_out' and c['score_contract']=='coverage-v2'
    assert c['principal'] in manifest['principals']
    assert c['label_author']=='independent-synthetic-author-v4' and 'not-human-validated' in c['label_status']
    assert c['label_rationale'].strip()
    for r in c['forbidden_sources']:
        d=byid[r['document_id']]; assert d['split']==c['split']
        assert 1<=r['version_number']<=d['current_version_number']
        # Only a superseded snapshot or genuinely unauthorized source may be forbidden.
        assert r['version_number']<d['current_version_number'] or not authorized(d,c['principal'])
    if c['document_ids'] is not None:
        assert c['id'].endswith('-a6')
        assert all(byid[x]['title'] in c['question'] for x in c['document_ids'])
    if c['category']=='answerable':
        assert c['expected_behavior']=='answer' and c['expected_sources'] and c['required_facts']
        if len({x['document_id'] for x in c['expected_sources']})>=2: multi+=1
        positions=[]
        for s in c['expected_sources']:
            d=byid[s['document_id']]; assert authorized(d,c['principal']) and d['split']==c['split']
            assert s['version_number']==d['current_version_number']
            v=d['versions'][s['version_number']-1]
            assert s['content_hash']==v['content_hash']
            q=s['quoted_text']; assert q and q in v['content']
            assert s['acceptable_answer_spans'] and all(x and x in q for x in s['acceptable_answer_spans'])
            assert any(grounded(x,q) for g in c['required_facts'] for x in g), 'Every necessary document needs a discriminating fact'
            quotes+=1
        quoted=' '.join(s['quoted_text'] for s in c['expected_sources'])
        for group in c['required_facts']:
            assert group and all(x.strip() and grounded(x,quoted) for x in group)
            positive_facts+=1
        for group in c['ordered_steps']:
            assert group and all(x.strip() and grounded(x,quoted) for x in group)
            positions.append(min(quoted.index(x) for x in group)); step_groups+=1
        assert positions==sorted(positions)
        if c['ordered_steps']:
            procedures+=1
            # The authored source procedure has exactly the same four complete step sentences.
            assert len(c['ordered_steps'])==4
            assert all(f'{n}. {g[0]}' in quoted for n,g in enumerate(c['ordered_steps'],1))
        label_checks.append({'id':c['id'],'result':'pass','basis':'current authorized source quotations, all requested facts, full ordered procedure where requested'})
    else:
        assert c['expected_behavior'] in ['refuse','review']
        assert c['expected_sources']==c['required_facts']==c['ordered_steps']==[]
        current_auth=' '.join(d['versions'][-1]['content'] for d in documents if authorized(d,c['principal']))
        prefix=c['id'][:5]
        if c['id'].endswith('-u1'):
            assert not re.search(r'\b(fee|price|dollars|currency|charged|payment)\b', current_auth, re.I)
            basis='No authorized source gives any monetary price or currency; all of the requested fact is missing.'
        elif c['id'].endswith('-u2'):
            assert 'Satellite variant' not in current_auth
            basis='Explicitly named Satellite variant absent; quantities for the excluded base entity cannot answer.'
        elif c['id'].endswith('-s1') and c['expected_behavior']=='refuse':
            assert len(c['forbidden_sources'])==1
            d=byid[c['forbidden_sources'][0]['document_id']]
            assert d['versions'][0]['content'] != d['versions'][-1]['content']
            # Historical-only attribute phrase occurs in the question and rationale, but no current source.
            old_attr=d['versions'][0]['content'].rsplit(' The ',1)[1].split(' was ',1)[0]
            assert old_attr in c['question'] and old_attr not in current_auth
            basis='Asked current attribute exists only in forbidden superseded version; no current authorized support.'
        elif c['id'].endswith('-s1'):
            pair=[byid[prefix+'-exception-'+suffix] for suffix in ['a','b']]
            assert pair[0]['metadata']['conflict_group']==pair[1]['metadata']['conflict_group']
            assert all(authorized(d,c['principal']) and d['current_version_number']==1 for d in pair)
            assert pair[0]['versions'][-1]['content']!=pair[1]['versions'][-1]['content']
            basis='Curated matching metadata and manually reviewed incompatible current same-run exception instructions.'
        else:
            assert c['category']=='adversarial' and len(c['forbidden_sources'])==1
            d=byid[c['forbidden_sources'][0]['document_id']]
            assert not authorized(d,c['principal'])
            assert d['versions'][-1]['content'] not in current_auth
            private_fact=d['versions'][-1]['content']
            private_subject=private_fact.split('The planned size of ',1)[1].split(' is ',1)[0]
            assert private_subject in c['question']
            assert f'The planned size of {private_subject} is ' not in current_auth
            basis='Requested size occurs only in another-user-private or cross-workspace source; embedded instructions confer no authority.'
        label_checks.append({'id':c['id'],'result':'pass','basis':basis})
assert multi==40 and procedures==20 and step_groups==80
assert Counter(c['family'] for c in cases)=={f:10 for f in families}
conflicts=defaultdict(list)
for d in documents:
    if 'conflict_group' in d['metadata']: conflicts[d['metadata']['conflict_group']].append(d['id'])
assert len(conflicts)==10 and all(len(x)==2 for x in conflicts.values())
for name in ['documents.json','cases.json','profile.json','manifest.json','label-review.json']:
    data=(P/name).read_bytes(); assert b'\r' not in data and not data.startswith(b'\xef\xbb\xbf')
    data.decode('utf-8')
result={'checked_utc':datetime.now(timezone.utc).isoformat(),'status':'pass','case_count':200,'document_count':100,'snapshot_count':sum(len(d['versions']) for d in documents),'category_counts':dict(counts),'family_count':20,'genuine_multi_document_positives':multi,'complete_ordered_procedure_positives':procedures,'ordered_step_groups':step_groups,'required_fact_groups':positive_facts,'exact_current_quotations':quotes,'explicit_scoped_cases':sum(c['document_ids'] is not None for c in cases),'private_permission_negatives':10,'cross_workspace_permission_negatives':10,'stale_only_current_fact_negatives':10,'curated_conflict_negatives':10,'family_exclusion':'All excluded family IDs compared automatically; subject disjointness reviewed by the independent author against the full supplied title list.','limits':['All checks are author-side source consistency checks, not application performance measurements.','Semantic family novelty and substantive contradiction are author judgments, not human validation.','No application imports, calls, models, network, repository validators, or previous evaluation inputs were used.'],'label_checks':label_checks}
(P/'validation-report.json').write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in result.items() if k!='label_checks'},indent=2))
