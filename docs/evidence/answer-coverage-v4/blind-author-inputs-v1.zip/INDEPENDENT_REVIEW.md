# Independent author review

Author: independent-synthetic-author-v4. Review date: 2026-10-24 UTC.
This is the source author's separate source/label consistency pass, independent of any application or measured output. It is not a second human annotator or human validation.

All 200 labels were reviewed through the generated per-case checks and a family-by-family reading of current specification sentences and questions. The checker separately rereads the serialized files, resolves every source reference, verifies literal fact/step grounding, and applies the declared principal's current authority. Every answer has all its requested components. Each four-step procedure includes its final step. Multi-document questions require distinct ownership/duration and appointment/reservation sources.

The four operator-a private-source positives were checked against the same sources forbidden to viewer-a in adversarial counterparts. Ten other adversarial requests target ops-b public sources; public visibility does not bridge workspaces. Pasted messages contain access-granting instructions but no trial-size facts. Neither these messages nor question instructions are operational evidence for the unavailable requested size. Forty unanswerable requests ask only for absent money amounts or explicitly absent Satellite variants. Ten stale cases ask for current attributes supplied only by version 1, not historical values. Ten conflict cases request only incompatible same-run exception instructions, with matching conflict_group metadata and neither source privileged over the other. The exception sources explicitly place their scope outside the ordinary review procedure.

Subject novelty was checked against the entire supplied exclusion packet. The 20 semantic subjects are:

- Font kerning specimens: letter-pair spacing, distinct from physical label proofing or paper stock.
- Formula locale conversion: numeric formula syntax and recalculation, absent from the excluded subjects.
- Mesh UV seam baking: digital surface parameterization, distinct from physical exhibit crating.
- Audiobook chapter markers: boundaries within an audio file, distinct from radio guest arrivals or film-reel transfers.
- Stitch-file simulation: virtual instruction preview, distinct from textile dye sample approval or physical machine operation.
- Stop-motion alignment: overlaying adjacent animation frames, absent from the excluded subjects.
- Braille-dot fixtures: virtual cell rendering, distinct from account access review and physical specimen cabinets.
- Comic reading order: digital panel linking, distinct from museum labels and paper issue.
- Interactive-fiction branches: directed story-node review, distinct from board-game token sorting.
- Synonym dictionary curation: distinguishing word senses, distinct from ingestion recovery and source permissions.
- Avatar pose blending: fictional digital gesture transitions, distinct from instrument or theatre equipment handling.
- Fractal palette interpolation: digital color anchor interpolation, distinct from textile dyes and mosaic grading.
- Crossword numbering: grid clue-start indexing, distinct from tournament scoring and chess prize reserves.
- Virtual hint timing: digital cue sequencing, distinct from physical game tokens or event scheduling subjects.
- CAD dimension annotations: attaching labels to imaginary drawing edges, distinct from survey-map drawer storage.
- Knot-diagram crossings: mathematical overpass notation, distinct from physical straps, ropes or rigging.
- MIDI quantization: note-onset grid placement, distinct from piano delivery and harp-cover handling.
- Viseme timing: silent animation mouth-pose cues, distinct from cinema caption delivery and guest arrival.
- Pixel dithering: per-cell image masks, distinct from physical display spacing or stock dispensing.
- Invented-lexicon stress marks: textual syllable annotation, distinct from poetry stipends and reading grants.

Limits: the fixtures use repeated ordinary operational sentence forms and four question phrasings in several request classes. This provides source-backed coverage, not an estimate of natural-world question distribution. Novelty and semantic incompatibility are the author's reviewed judgments. No measured performance, application behavior, retrieval strategy, model selection, execution thresholds, or execution configuration was inspected or inferred. No network, API, model, peer agent, repository validator, candidate implementation, memory, onboarding, or prior question packet was accessed. Only the supplied contract/exclusion files and this output directory were read. No input was modified.
