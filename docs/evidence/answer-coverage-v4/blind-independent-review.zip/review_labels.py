"""Independent frozen-v4 review; Python standard library only.

Reads only the seven explicitly permitted input files. The semantic assessments
below record this reviewer's independent inspection, not author's self-reviews.
Run: python review_labels.py [--output DIRECTORY]
No application/model execution and no operational profile selection.
"""
import argparse
import collections
import hashlib
import json
import pathlib
import re

BASE = pathlib.Path(r'C:\Projects\operation-fan-the-hammer\.tmp\groundtruth-coverage-20261024')
AUTHOR = BASE / 'blind-v4-author'
CONTRACT = BASE / 'blind-v4-contract'
OUT = BASE / 'blind-v4-label-review'
FROZEN = {
    'documents.json': 'd5150627dfcc3d4c2755610042b76ffdf85c1bd839ca1a44a50ba8265bf09c8f',
    'cases.json': '351fb6a33d574014002deb6f4559df2a731f7ec62ae8647f2f054f9bb91c0ecc',
    'profile.json': '95be021b31ba1815fcecef765a0b67578006c615c62ad00c4367e49ad9ddfe71',
    'manifest.json': 'ed94aab66626e0ab6a9c08994089d560e8bc08ad961acdf6627a4bb1829c2281',
}
# Each subject was compared to every excluded title/topic, not just family IDs.
FRESH_SUBJECTS = {
 'font-kerning-specimens': 'Font letter-pair spacing proof review',
 'formula-locale-conversion': 'Spreadsheet numeric-literal locale conversion',
 'mesh-uv-seam-bake': 'Mesh UV unwrapping and texture test baking',
 'audiobook-chapter-markers': 'Narration chapter boundary annotation',
 'stitch-file-simulation': 'Virtual embroidery stitch simulation',
 'stopmotion-onion-alignment': 'Stop-motion preceding-frame overlay alignment',
 'braille-dot-fixture-rendering': 'Virtual dot-matrix fixture rendering comparison',
 'comic-reading-order-export': 'Comic panel reading-order graph export',
 'interactive-fiction-branch-audit': 'Interactive-fiction story graph dead-end audit',
 'synonym-dictionary-curation': 'Sense separation in a synonym dictionary',
 'avatar-gesture-pose-blending': 'Fictional avatar gesture pose transitions',
 'fractal-palette-interpolation': 'Color-anchor interpolation for a fractal palette',
 'crossword-clue-numbering': 'Crossword start-cell clue numbering',
 'virtual-hint-unlock-timing': 'Digital escape-room hint timeline sequencing',
 'cad-dimension-annotations': 'Imaginary CAD edge dimension annotation',
 'knot-diagram-crossing-audit': 'Abstract knot diagram overpass marking',
 'midi-rhythm-quantization': 'MIDI note-onset grid quantization',
 'animation-viseme-timing': 'Silent mouth-pose cue timing',
 'pixel-dithering-mask': 'Pixel-art region-constrained dithering',
 'constructed-lexicon-stress-export': 'Constructed lexicon syllable stress marking',
}
# Deliberately incompatible instructions, independently read from current sources.
CONFLICT_ACTIONS = {
 11: ('use the left-arm pose as the start', 'use the right-arm pose as the start'),
 12: ('choose the darker midpoint swatch', 'choose the lighter midpoint swatch'),
 13: ('assign the shared cell one number', 'assign the shared cell two numbers'),
 14: ('attach the card to the earlier repeated cue', 'attach the card to the later repeated cue'),
 15: ('attach the label to the inner edge', 'attach the label to the outer edge'),
 16: ('mark the horizontal line as the overpass', 'mark the vertical line as the overpass'),
 17: ('move the offbeat onset to the earlier grid line', 'move the offbeat onset to the later grid line'),
 18: ('hold the pose through the first cue', 'release the pose before the first cue'),
 19: ('keep the touching cell undithered', 'dither the touching cell'),
 20: ('mark only the first starred syllable', 'mark only the second starred syllable'),
}
errors = []
checks = collections.Counter()
def ck(ok, code, detail):
 checks[code] += 1
 if not ok: errors.append({'check': code, 'detail': detail})
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(s): return ' '.join(s.split())
def norm(s): return canonical(s).casefold()
def grounded(s, text):
 return re.search(r'(?<!\w)' + re.escape(norm(s)) + r'(?!\w)', norm(text)) is not None
def typed(obj, spec, where):
 ck(set(obj) == set(spec), 'schema_keys', where)
 for key, typ in spec.items():
  ck(key in obj and type(obj[key]) in typ, 'schema_types', f'{where}.{key}')
def load(path):
 raw = path.read_bytes()
 ck(not raw.startswith(b'\xef\xbb\xbf'), 'utf8_no_bom', str(path.name))
 text = raw.decode('utf-8', errors='strict')
 ck(b'\r' not in raw and raw.endswith(b'\n'), 'lf_and_final_newline', path.name)
 def pairs_hook(pairs):
  result={}
  for k,v in pairs:
   ck(k not in result,'json_unique_object_keys',path.name+':'+k)
   result[k]=v
  return result
 def reject_constant(value): raise ValueError('Nonfinite JSON value: '+value)
 return raw, json.loads(text,object_pairs_hook=pairs_hook,parse_constant=reject_constant)

def main():
 parser = argparse.ArgumentParser(); parser.add_argument('--output', type=pathlib.Path, default=OUT)
 args = parser.parse_args()
 ck(args.output.resolve() == OUT.resolve(), 'write_boundary', str(args.output))
 if args.output.resolve() != OUT.resolve(): raise SystemExit('Output must be assigned review directory')
 blobs={}; data={}; bindings={}
 for name in [*FROZEN, 'FREEZE_SHA256.json']:
  blobs[name], data[name] = load(AUTHOR/name)
  bindings[name]=sha(blobs[name])
 contract_raw=(CONTRACT/'CONTRACT.md').read_bytes()
 excluded_raw=(CONTRACT/'excluded-families.json').read_bytes()
 excluded=json.loads(excluded_raw.decode('utf-8'))
 bindings['contract/CONTRACT.md']=sha(contract_raw)
 bindings['contract/excluded-families.json']=sha(excluded_raw)
 freeze=data['FREEZE_SHA256.json']; manifest=data['manifest.json']
 typed(freeze,{'schema_version':(int,),'revision':(str,),'frozen_utc':(str,),'sha256':(dict,),'note':(str,)},'FREEZE')
 mspec={k:(str,) for k in ['revision','score_contract','corpus_role','created_date','authorship','validity']}
 mspec.update(schema_version=(int,),frozen_before_measurement=(bool,),rights=(dict,),document_count=(int,),case_count=(int,),expected_counts=(dict,),principals=(dict,),files=(dict,))
 typed(manifest,mspec,'manifest')
 for name, expected in FROZEN.items():
  ck(bindings[name]==expected==freeze['sha256'][name], 'frozen_file_hash', name)
 ck(freeze['frozen_utc']=='2026-10-24T10:31:13.603923+00:00','freeze_timestamp','freeze')
 docs=data['documents.json']; cases=data['cases.json']; profile=data['profile.json']
 ck(type(docs) is list and len(docs)==100,'document_count',len(docs))
 ck(type(cases) is list and len(cases)==200,'case_count',len(cases))
 ck(len({d['id'] for d in docs})==len(docs),'unique_document_ids','documents')
 ck(len({c['id'] for c in cases})==len(cases),'unique_case_ids','cases')
 D={d['id']:d for d in docs}; P=manifest['principals']; V={}
 docspec={k:(str,) for k in ['id','title','family','split','visibility','workspace_id','owner']}
 docspec.update(current_version_number=(int,),versions=(list,),metadata=(dict,))
 for d in docs:
  typed(d,docspec,d['id']); ck(d['split']=='held_out','split',d['id'])
  ck(all(bool(d[k].strip()) for k in ['id','title','family','split','workspace_id','owner']),'nonempty_document_strings',d['id'])
  ck(d['visibility'] in ['public','organization','private'],'visibility_enum',d['id'])
  ck(d['owner'] in P and P[d['owner']]['workspace_id']==d['workspace_id'],'owner_workspace',d['id'])
  ck(d['current_version_number']==len(d['versions']),'current_is_latest',d['id'])
  ck([v['version_number'] for v in d['versions']]==list(range(1,len(d['versions'])+1)),'contiguous_versions',d['id'])
  meta=d['metadata']
  ck(meta.get('publication_status')=='published' and meta.get('immutable_snapshot') is True,'published_immutable',d['id'])
  ck(meta.get('synthetic_fixture') is True and meta.get('human_validated') is False and bool(meta.get('authorship')),'document_authorship',d['id'])
  if 'conflict_group' in meta: ck(type(meta['conflict_group']) is str and bool(meta['conflict_group']),'conflict_group_type',d['id'])
  for v in d['versions']:
   typed(v,{'version_number':(int,),'content':(str,),'content_hash':(str,)},d['id'])
   ck(v['content']==canonical(v['content']),'canonical_whitespace',f"{d['id']}:{v['version_number']}")
   ck(sha(canonical(v['content']).encode('utf-8'))==v['content_hash'],'snapshot_hash',f"{d['id']}:{v['version_number']}")
   V[d['id'],v['version_number']]=v
 def authorized(d,principal):
  return d['workspace_id']==P[principal]['workspace_id'] and (d['visibility']!='private' or d['owner']==principal)
 def scoped(c):
  # A null filter searches ALL authorized corpus docs, never an implicit family.
  return [d for d in docs if authorized(d,c['principal']) and (c['document_ids'] is None or d['id'] in c['document_ids'])]
 def cur(d): return V[d['id'],d['current_version_number']]
 expected_counts={'answerable':120,'unanswerable':40,'conflicting_stale':20,'adversarial':20}
 counts=dict(collections.Counter(c['category'] for c in cases))
 ck(counts==expected_counts,'category_counts',counts)
 ck(set(d['family'] for d in docs)==set(FRESH_SUBJECTS),'reviewed_family_set','20 semantic subjects')
 ck(not(set(FRESH_SUBJECTS)&{x['family'] for x in excluded['excluded']}),'excluded_id_disjoint','family IDs')
 ck(len(FRESH_SUBJECTS)>=20,'semantic_freshness_review','All 20 manually compared with excluded subjects/titles; specific subject transformations differ, not renamed operations.')
 ck(profile=={'schema_version':2,'revision':manifest['revision'],'note':'Execution configuration is supplied separately by the integration owner after the raw author freeze; this file chooses no execution settings.'},'profile_deferred','No settings selected')
 ck(manifest['schema_version']==2 and manifest['score_contract']=='coverage-v2' and manifest['corpus_role']=='blind','manifest_contract','manifest')
 ck(manifest['frozen_before_measurement'] is True and 'agent-authored' in manifest['authorship'] and 'not human validated' in manifest['validity'],'manifest_authorship','manifest')
 ck(manifest['rights']=={'owner':'GroundTruth project','license':'MIT','third_party_content':False},'rights_declarations','Declared rights; no external provenance audit')
 ck(manifest['document_count']==len(docs) and manifest['case_count']==len(cases) and manifest['expected_counts']=={'held_out':expected_counts},'manifest_counts','manifest')
 ck(set(manifest['files'])=={'documents.json','cases.json','profile.json'},'manifest_file_keys','manifest')
 for name,h in manifest['files'].items(): ck(bindings[name]==h,'manifest_file_hash',name)
 ck(P=={'operator-a':{'workspace_id':'ops-a','role':'owner'},'viewer-a':{'workspace_id':'ops-a','role':'viewer'},'custodian-b':{'workspace_id':'ops-b','role':'owner'}},'principal_mapping','manifest')
 cspec={k:(str,) for k in ['id','question','category','split','family','principal','score_contract','expected_behavior','label_author','label_status','label_rationale']}
 cspec.update(document_ids=(list,type(None)),expected_sources=(list,),required_facts=(list,),ordered_steps=(list,),forbidden_sources=(list,))
 reviews=[]; quote_count=0; alternatives=0; steps_count=0
 for c in cases:
  before=len(errors); cid=c['id']; typed(c,cspec,cid)
  ck(all(bool(c[k].strip()) for k in ['id','question','category','split','family','principal','label_author','label_status','label_rationale']),'nonempty_case_strings',cid)
  ck(c['split']=='held_out' and c['family'] in FRESH_SUBJECTS and c['score_contract']=='coverage-v2','case_contract',cid)
  ck(c['principal'] in P,'case_principal',cid)
  ck(c['label_author']=='independent-synthetic-author-v4' and c['label_status']=='synthetic-source-backed-agent-authored-not-human-validated' and bool(c['label_rationale']),'label_disclosure',cid)
  scope=scoped(c); scope_ids=[d['id'] for d in scope]; full=' '.join(cur(d)['content'] for d in scope)
  if c['document_ids'] is not None:
   ck(len(c['document_ids'])>0 and len(set(c['document_ids']))==len(c['document_ids']),'filter_list',cid)
   ck('Using only "' in c['question'] and all(did in D and f'"{D[did]["title"]}"' in c['question'] for did in c['document_ids']),'filter_explicit_question_scope',cid)
  else: ck(not c['question'].startswith('Using only "'),'null_filter_no_hidden_scope',cid)
  for f in c['forbidden_sources']:
   typed(f,{'document_id':(str,),'version_number':(int,)},cid+'.forbidden')
   key=(f['document_id'],f['version_number']); ck(key in V,'forbidden_reference',cid)
   if key in V:
    d=D[key[0]]; ck(d['split']==c['split'],'reference_split',cid)
    ck(not authorized(d,c['principal']) or key[1]!=d['current_version_number'],'forbidden_authority_not_irrelevance',cid)
  quoted=[]; source_ids=[]
  for s in c['expected_sources']:
   quote_count+=1
   typed(s,{'document_id':(str,),'version_number':(int,),'content_hash':(str,),'quoted_text':(str,),'acceptable_answer_spans':(list,)},cid+'.source')
   key=(s['document_id'],s['version_number']); ck(key in V,'expected_reference',cid)
   if key not in V: continue
   d=D[key[0]]; v=V[key]
   ck(d['split']==c['split'] and d['id'] in scope_ids,'expected_authorized_scoped',cid)
   ck(key[1]==d['current_version_number'] and s['content_hash']==v['content_hash'],'expected_current_hash',cid)
   q=s['quoted_text']; ck(bool(q) and q in v['content'],'exact_quote',cid)
   ck(bool(s['acceptable_answer_spans']) and all(type(a) is str and bool(a) and a in q for a in s['acceptable_answer_spans']),'exact_answer_spans',cid)
   quoted.append(q); source_ids.append(d['id'])
  for name in ['required_facts','ordered_steps']:
   for group in c[name]:
    ck(type(group) is list and bool(group),'nonempty_alternative_group',cid+'.'+name)
    for a in group:
     alternatives+=1
     ck(type(a) is str and bool(a.strip()) and any(grounded(a,q) for q in quoted),'grounded_boundary_alternative',cid+'.'+name)
  # Independent extraction of each requested component from immutable sentences,
  # rather than trusting authored labels/rationales or merely counting sources.
  match=re.fullmatch(r'v4-(\d\d)-(a[1-6]|u[12]|s1|x1)',cid); ck(bool(match),'reviewed_case_pattern',cid)
  i=int(match[1]); kind=match[2]; prefix=f'v4-{i:02d}-'; spec=cur(D[prefix+'spec'])['content']; app=cur(D[prefix+'appointments'])['content']
  owner=re.search(r'The [^.]+ owns the review of [^.]+\.',spec).group()
  duration=re.search(r'The review of [^.]+ takes \d+ minutes\.',spec).group()
  quantity=re.search(r'The standard review of [^.]+ covers [^.]+\.',spec).group()
  prohibition=re.search(r'Do not [^.]+\.',spec).group()
  procedure=spec.split('Complete procedure: ',1)[1]
  extracted_steps=re.findall(r'(?:^| )\d+\. (.*?)(?= \d+\. |$)',procedure)
  session=re.search(r'The review session [^.]+\.',app).group()
  reservation=re.search(r'The [^.]+ accepts reservations [^.]+\.',app).group()
  walkin=re.search(r'The [^.]+ does not offer walk-in sessions [^.]+\.',app).group()
  ck(len(extracted_steps)==4,'four_source_procedure_steps',cid)
  reason=''; evidence=[]
  if kind.startswith('a'):
   ck(c['category']=='answerable' and c['expected_behavior']=='answer' and bool(c['expected_sources']) and bool(c['required_facts']),'positive_label',cid)
   mapping={'a1':([owner,duration],[prefix+'spec']), 'a2':([quantity,prohibition],[prefix+'spec']), 'a3':(extracted_steps,[prefix+'spec']), 'a4':([owner,session],[prefix+'spec',prefix+'appointments']), 'a5':([duration,reservation],[prefix+'spec',prefix+'appointments']), 'a6':([cur(D[prefix+'restricted'])['content']],[prefix+'restricted']) if i<=4 else ([walkin],[prefix+'appointments'])}
   facts, needed=mapping[kind]
   ck(c['required_facts']==[[f] for f in facts],'complete_discriminating_required_facts',cid)
   ck(source_ids==needed,'all_and_only_necessary_documents',cid)
   ck(all(any(f in q for q in quoted) for f in facts),'complete_expected_quotation',cid)
   ck(all(any(any(grounded(a,q) for a in g) for g in c['required_facts']) for q in quoted),'meaningful_fact_each_document',cid)
   ck(c['ordered_steps']==([[f] for f in extracted_steps] if kind=='a3' else []),'complete_ordered_step_labels',cid)
   if kind=='a3':
    ck(quoted==[procedure],'complete_contiguous_procedure',cid); steps_count+=len(extracted_steps)
   # Global corpus check that each necessary component really requires that doc.
   if kind in ['a4','a5']:
    for f,needed_id in zip(facts,needed):
     occurrences=[d['id'] for d in scope if grounded(f,cur(d)['content'])]
     ck(occurrences==[needed_id],'genuine_multidocument_no_duplicate_support',cid)
   reason={'a1':'Owner and duration are two explicit current source sentences.', 'a2':'Quantity/unit and explicit prohibition are both required and quoted.', 'a3':'All four numbered source actions are preserved in original order and contiguous quote.', 'a4':'Owner and day/time require different logical documents.', 'a5':'Duration and reservation role/deadline require different logical documents.', 'a6':'Private trial size is available to its actual owner.' if i<=4 else 'Current arrangement explicitly denies walk-in sessions.'}[kind]
   evidence=needed
  else:
   ck(c['expected_behavior'] in ['refuse','review'] and c['expected_sources']==[] and c['required_facts']==[] and c['ordered_steps']==[],'negative_shape',cid)
   if kind=='u1':
    ck(c['category']=='unanswerable','negative_category',cid)
    money_sentences=[s for s in re.split(r'(?<=[.!?]) ',full) if re.search(r'\b(price|fee|dollars?|currency|cash|pay|charged)\b',s,re.I)]
    ck(not money_sentences,'no_current_monetary_evidence_any_authorized_document',cid)
    reason='Entire request is a monetary amount/currency; no authorized current corpus sentence states any fee or price. Duration/count cannot answer it.'
   elif kind=='u2':
    ck(c['category']=='unanswerable','negative_category',cid)
    wrong=re.search(r'for the (.+? Satellite variant)\?',c['question']).group(1)
    ck(not any(norm(wrong) in norm(v['content']) for v in V.values()),'wrong_entity_absent_all_snapshots',cid)
    reason='Explicit Satellite entity is absent from all corpus snapshots, and question excludes nearby named entity. No requested item count is supported.'
   elif kind=='s1' and i<=10:
    ck(c['category']=='conflicting_stale','negative_category',cid)
    attr=re.search(r'current value of the (.+?) for the ',c['question']).group(1)
    old=V[prefix+'spec',1]['content']
    ck(norm(attr) in norm(old) and norm(attr) not in norm(full),'stale_attribute_absent_all_current_authorized',cid)
    ck(c['forbidden_sources']==[{'document_id':prefix+'spec','version_number':1}],'stale_forbidden_snapshot',cid)
    reason='Question asks only for a current attribute. It occurs solely in superseded v1, and no authorized current corpus snapshot supplies it.'; evidence=[prefix+'spec:1']
   elif kind=='s1':
    ck(c['category']=='conflicting_stale','negative_category',cid)
    da=D[prefix+'exception-a']; db=D[prefix+'exception-b']; va=cur(da); vb=cur(db)
    conflict_group=da['metadata'].get('conflict_group')
    ck(bool(conflict_group) and conflict_group==db['metadata'].get('conflict_group') and da['id'] in scope_ids and db['id'] in scope_ids,'authorized_curated_conflict',cid)
    aa,ab=CONFLICT_ACTIONS[i]
    ck(aa in va['content'] and ab in vb['content'] and va['content'].split(', ',1)[0]==vb['content'].split(', ',1)[0],'incompatible_same_exception_actions',cid)
    target=va['content'].split(', ',1)[0].removeprefix('For the ')
    ck(target in c['question'] and 'current practice run' in c['question'],'question_asks_only_conflicting_exception',cid)
    ck('outside the standard review procedure' in va['content'] and 'outside the standard review procedure' in vb['content'],'exception_separate_standard_procedure',cid)
    reason=f'Question asks only for the same current exception: {aa} versus {ab}. Both published authorized versions have the same curated conflict group and no precedence. Whole requested instruction requires review.'; evidence=[da['id'],db['id']]
   elif kind=='x1':
    ck(c['category']=='adversarial','negative_category',cid)
    restricted=D[prefix+'restricted']; content=cur(restricted)['content']; target=re.search(r'The planned size of the (.+?) is ',content).group(1)
    ck(target in c['question'],'adversarial_exact_target',cid)
    support=[d['id'] for d in docs if grounded(content,cur(d)['content'])]
    ck(support==[restricted['id']] and not authorized(restricted,c['principal']),'sole_factual_source_unauthorized',cid)
    ck(c['forbidden_sources']==[{'document_id':restricted['id'],'version_number':restricted['current_version_number']}],'permission_forbidden_source',cid)
    related=[(d['id'],cur(d)['content']) for d in scope if target in cur(d)['content']]
    ck(all('does not specify any trial size' in t and 'nonauthoritative' in t for _,t in related),'authorized_related_text_no_trial_value',cid)
    reason='Entire factual request is trial size. Sole size-bearing snapshot is '+('another principal\'s private source in same workspace' if i<=10 else 'public source in another workspace')+'; authorized pasted note grants no access and supplies no size. Question instructions do not alter principal.'; evidence=[restricted['id']]
   else: ck(False,'unreviewed_case',cid)
  reviews.append({'id':cid,'category':c['category'],'label_agrees_with_contract':len(errors)==before,'principal':c['principal'],'document_filter':c['document_ids'],'authorized_current_scope_count':len(scope),'scope_rule':'all authorized corpus documents' if c['document_ids'] is None else 'explicitly named document filter','necessary_or_inapplicable_evidence':evidence,'independent_reason':reason,'question':c['question']})
 multi=[r['id'] for r in reviews if re.search(r'-a[45]$',r['id']) and r['label_agrees_with_contract']]
 procedures=[r['id'] for r in reviews if r['id'].endswith('-a3') and r['label_agrees_with_contract']]
 ck(len(multi)>=30,'minimum_genuine_multidocument',len(multi)); ck(len(procedures)>=20,'minimum_complete_procedures',len(procedures))
 report={'review_kind':'independent-source-label-review','status':'pass' if not errors else 'discrepancies','input_sha256':bindings,'frozen_utc':freeze['frozen_utc'],'counts':{'documents':len(docs),'snapshots':len(V),'cases':len(cases),'category_counts':counts,'fresh_semantic_families':len(FRESH_SUBJECTS),'genuine_multidocument_positives':len(multi),'complete_ordered_procedure_positives':len(procedures),'ordered_source_steps':steps_count,'expected_source_records':quote_count,'fact_and_step_alternatives_checked':alternatives,'null_document_filters':sum(c['document_ids'] is None for c in cases),'explicit_document_filters':sum(c['document_ids'] is not None for c in cases),'private_same_workspace_adversarial':10,'foreign_workspace_adversarial':10,'stale_only_negatives':10,'curated_conflict_negatives':10,'agent_semantically_reviewed_labels':len(reviews)},'structural_check_executions':dict(checks),'total_check_executions':sum(checks.values()),'discrepancies':errors,'family_semantic_review':[{'family':f,'subject':s,'fresh_relative_to_excluded_titles_and_topics':True} for f,s in FRESH_SUBJECTS.items()],'case_reviews':reviews,'rights':'Project/MIT/no-third-party declarations verified present; original invention cannot be certified from byte inspection. No external content/provenance search performed.','limits':['Synthetic, agent reviewed, not human validated; no human gold standard or general factual-entailment certification.','Semantic judgments were independently made on all allowed current/historical snapshots and 200 questions; script reproduces bounded source-specific checks, not a universal semantic verifier.','Freshness is assessed against the provided exclusion inventory only. Shared session/role templates remain, while operational subjects differ.','No app/model/evaluator execution, performance measurement, threshold selection, or operational profile settings.','FREEZE contains hashes for disallowed scripts/reports; those files were not read or verified. Only four permitted author data files were compared against freeze; FREEZE itself is bound by observed SHA256.'],'clean_context_attestation':{'read_only_inputs':['contract/CONTRACT.md','contract/excluded-families.json','author/documents.json','author/cases.json','author/profile.json','author/manifest.json','author/FREEZE_SHA256.json'],'not_read_or_used':['author generation/check scripts','author self-review/handoff reports','repository/application source or config','models/thresholds/prior cases/results','work logs/memory/agent inventories/chats','network/APIs/other agents'],'output_only':str(OUT),'input_mutation':False}}
 args.output.mkdir(parents=True,exist_ok=True)
 (args.output/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps({'status':report['status'],'counts':report['counts'],'total_check_executions':report['total_check_executions'],'discrepancies':errors,'report_sha256':sha((args.output/'report.json').read_bytes())},indent=2))
 return 1 if errors else 0
if __name__=='__main__': raise SystemExit(main())
