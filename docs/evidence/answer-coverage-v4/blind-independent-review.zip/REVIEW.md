# Independent frozen-v4 source and label review

**Status: pass within the stated review scope.** No material source/label discrepancy found. Reviewed on 2026-10-24 against the author freeze at `2026-10-24T10:31:13.603923+00:00`. Inputs were not modified.

## Counts and judgments

| Check | Verified result |
| --- | --- |
| Logical documents / immutable snapshots | 100 / 120 |
| Labels independently reviewed | 200 of 200 agree with contract |
| Categories | 120 answerable; 40 unanswerable; 20 conflicting_stale; 20 adversarial |
| Fresh semantic source families | 20, compared with every provided excluded title/topic |
| Genuine multi-document positives | 40; each requires facts unique to two distinct logical documents |
| Complete ordered procedures | 20; all four source steps present and ordered, 80 steps total |
| Expected source records | 160, all current, authorized, exact version/hash/quotation |
| Fact/step alternatives | 340 grounded alternatives checked with normalized word boundaries |
| Document filters | 196 null, 4 explicit; all four name exactly the document stated in the question |
| Negative cases | 40 fully unsupported requests; 10 stale-only; 10 curated current conflicts; 20 unauthorized trial-size requests |
| Permission negatives | 10 another user's private ops-a source; 10 public sources in ops-b unavailable to viewer-a |
| Reproducible check assertions | 17,593 executions; zero failed assertions |

The independent semantic review read all source versions and all 200 questions. Positives require the owner/duration, quantity/prohibition, full procedure, owner/session, duration/reservation, or owner-visible private size/walk-in rule actually requested. The script independently extracts these components from source sentences and compares the authored expectations to them. Each necessary document contributes a meaningful discriminating fact, including entity, role, unit, duration, deadline or negation as applicable.

All 80 negative questions require refusal/review in full. Monetary requests have no price/currency evidence anywhere in the authorized current corpus. Each wrong-entity request expressly excludes the nearby supported entity. Ten stale requests ask only for current attributes omitted from all authorized current sources. Ten conflict requests ask only for the same exception subject governed by two incompatible, published, equally current instructions with a matching conflict group. These sources explicitly separate exceptions from the standard procedure. Twenty adversarial requests ask solely for sizes found in unauthorized sources; authorized copied messages provide no size and cannot grant access. No legitimate answerable partial request was classified negative merely because an injection appears nearby.

Null document filters were treated as all current documents authorized for the actual principal across the corpus, with no implicit family restriction. Forbiddance was verified to concern unauthorized or superseded versions, never an authorized current document merely irrelevant to a question. Public visibility does not cross workspaces. All sources are marked published, immutable, synthetic and agent-authored; all case/source splits are held_out and manifest corpus role is blind.

## Reproduce and evidence

Run from any directory with Python 3 using only its standard library:

```powershell
python 'C:\Projects\operation-fan-the-hammer\.tmp\groundtruth-coverage-20261024\blind-v4-label-review\review_labels.py'
```

The script writes `report.json` only in this assigned review directory. It verifies UTF-8 without BOM, LF/final newline, JSON object-key uniqueness, field/type schemas, IDs/references, canonical source whitespace, contiguous versions/current pointers, SHA256s, exact quotes/answer spans, fact/step alternatives, scope/permissions, required category counts, and source-specific complete labels. The report contains one independent reason and the authorized search scope count for every case, plus the 20 semantic-family judgments. Semantic assessments are agent judgments recorded in the script, not a general semantic-verifier algorithm.

| Artifact | SHA256 |
| --- | --- |
| review_labels.py | `39f52dfc7040e2c0ead58cf2a3062a4f5052d30a2391b55e9efd6f136e9883d1` |
| report.json | `38b3426e28248654b5dcb1c92d0538414c796ec22dec868cb161418336543198` |

## Exact input binding

The four author data hashes independently match both the frozen checksum file and the supplied freeze values. The manifest's three file hashes also match. The checksum file does not hash itself; its observed hash is recorded below. Disallowed scripts/self-reviews named inside that checksum inventory were not accessed or checked.

| Permitted input | SHA256 |
| --- | --- |
| author/documents.json | `d5150627dfcc3d4c2755610042b76ffdf85c1bd839ca1a44a50ba8265bf09c8f` |
| author/cases.json | `351fb6a33d574014002deb6f4559df2a731f7ec62ae8647f2f054f9bb91c0ecc` |
| author/profile.json | `95be021b31ba1815fcecef765a0b67578006c615c62ad00c4367e49ad9ddfe71` |
| author/manifest.json | `ed94aab66626e0ab6a9c08994089d560e8bc08ad961acdf6627a4bb1829c2281` |
| author/FREEZE_SHA256.json | `74c84280854bbbf1c8fec67938c506759359e30fcd6f6254aaea9d53e3e58f60` |
| contract/CONTRACT.md | `c3633c562d339dcfab0d5230b2c5bd2a12623300a00696e78386b9467f8b5d9a` |
| contract/excluded-families.json | `4d5e29190024f0a3dd381e6b09f3cc4bc09fd6cfe0f43ad30177d616d40d113d` |

## Limits and clean-context attestation

This is synthetic agent source/label review, not human validation, a human gold standard, or general quality/factual-entailment certification. Freshness is assessed against the supplied exclusion inventory only; repeated role/session/question templates remain despite distinct technical subjects. Project ownership, MIT licensing, no third-party content and agent authorship are verified declarations; originality/rights cannot be externally certified from these files alone. No human validation was claimed.

Only the seven permitted input files were read. No author generator/checker, self-review/handoff report, application/repository source, configuration, model, threshold, prior cases/results, work log, memory, agent inventory/chat, network/API or other agent was consulted. All writes stayed in `blind-v4-label-review`. The operational profile remains deferred; no settings were chosen, no application/model was evaluated, and no execution-performance claim is made.
