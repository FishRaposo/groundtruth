"""Bounded V8 adjacent instruction adversarial controls; no model."""
import pytest
from app.services.reader_questions import mismatch_reason
from app.services.reader_support import adjacent_before_steps

QUESTION='What must be paused before restoring the staging snapshot?'

@pytest.mark.parametrize(('context','answer'),[
    ('Pausing the deployment queue is prohibited. Restore the staging snapshot.','deployment queue'),
    ('Pause neither the deployment queue nor its worker. Restore the staging snapshot.','deployment queue'),
    ('Pause the deployment queue? Restore the staging snapshot.','deployment queue'),
])
def test_noninstruction_or_negative_first_clause_does_not_waive_rejection(context,answer):
    start=context.index(answer)
    assert mismatch_reason(QUESTION,context,start,start+len(answer))=='requested_topic_is_introduced_after_selected_clause'

@pytest.mark.parametrize(('question','context','answer'),[
    ('What should be stopped before swapping the reserve cartridge?','Stop the supply pump. Swap the reserve cartridge.','supply pump'),
    ('What must be isolated before moving the Orion console?','Isolate the battery. Move the Orion console.','battery'),
])
def test_regular_suffix_forms_preserve_adjacent_commands(question,context,answer):
    start=context.index(answer)
    assert mismatch_reason(question,context,start,start+len(answer)) is None

@pytest.mark.parametrize('context',[
    'Pause the deployment queue. Restore the Cedar snapshot. Review the staging snapshot.',
    'Pause the deployment queue. Diagram: restore the staging snapshot.',
    'Pause the deployment queue. Never restore the staging snapshot.',
])
def test_wrong_topic_intervening_caption_or_negative_second_clause_is_not_exempt(context):
    answer='deployment queue'
    start=context.index(answer)
    assert mismatch_reason(QUESTION,context,start,start+len(answer))=='requested_topic_is_introduced_after_selected_clause'

def test_after_question_and_reversed_commands_do_not_activate_before_helper():
    assert adjacent_before_steps('What must be paused after restoring the staging snapshot?','Pause the deployment queue','Restore the staging snapshot') is False
    assert adjacent_before_steps(QUESTION,'Restore the staging snapshot','Pause the deployment queue') is False
