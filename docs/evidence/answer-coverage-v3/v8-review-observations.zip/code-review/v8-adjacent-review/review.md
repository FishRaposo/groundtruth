# V8 adjacent-step independent review (2026-10-24)

One material defect remains: the new rejection exemption recognizes verb-like first words without establishing that the first clause is a plain positive instruction. Three existing-boundary counterexamples are newly accepted. No model/grid/browser was run by reviewer. The failed V7 browser and earlier measurement history remain untouched.

## Overbroad plain-instruction exemption

Production references: `reader_support.py:161-192` adjacent_before_steps compares suffix-form intersections for both source first words; `reader_support.py:223` allows question punctuation in the adjacency separator; `:224-229` then waives topic-introduced-later rejection. The plan explicitly excludes negative commands/narrative subjects and permits adjacent plain instructions only.

Exact question: `What must be paused before restoring the staging snapshot?`; raw selected span `deployment queue`.

Each context below now returns `mismatch_reason=None`:

1. `Pausing the deployment queue is prohibited. Restore the staging snapshot.` A gerund subject and explicit prohibition are not a positive imperative. Stripping `ing` from the source first word makes it match the requested passive verb.
2. `Pause neither the deployment queue nor its worker. Restore the staging snapshot.` This is an explicitly negative first command. Matching only its first verb ignores its negation.
3. `Pause the deployment queue? Restore the staging snapshot.` The first clause is a question, and the punctuation eligibility currently accepts `?` as an imperative separator.

The old53e59bf binding_rejection returns `requested_topic_is_introduced_after_selected_clause` for all three (`baseline-rejections.log`, read-only git-show execution of the pure old support module). Current assertions retain that expected result and fail. No claim is made that an actual model necessarily chooses these spans; the changed application surface rejection accepts them if QA does. Exact copied text would still be preserved, but preservation alone does not justify waiving this guard. Narrow source-instruction eligibility without removing the demonstrated legitimate Pause/Restore and Close/Replace behavior or generating a different model answer.

Passing independent controls: regular suffix forms Stop/stopped/Swap/swapping and Isolate/isolated/Move/moving; intervening wrong-topic command; Diagram caption; Never-negated following command; explicit after rather than before; reversed command order at the helper seam. Owned7 tests and mocked real multiple-document answer control pass. This does not prove every ordering or discourse relation is understood; unchanged preexisting behavior outside this helper remains a limitation rather than a new finding here.

## Existing development predicate proof and comparison scope

The independent audit extracts the exact requested-question regex constant from the actual helper AST, then uses only the `question` field from exposed coverage-development-v3 and the actual `question_parts` preparation used by LocalReader/mismatch_reason.

-80 raw questions,154 actual prepared question parts.
-0 raw matches,0 prepared-part matches.
-Cases SHA25668f1e41d2ba336d2f5edfc9ece3fe7e417fe05f17c22eadabea20c35732d3976.
-Reader support hash9639757e9d50e0b3a76d53ae558e46672562734772e590b1d9e96f7829cee4ed for this observation.

`development-predicate-audit.json` records the pattern and proof scope. No expected answers, source text or model labels are used to choose a rule; no future author material accessed. The new helper cannot change rejection outcomes for any current development question under this exact predicate. Tightening only source-instruction eligibility keeps that unreachable scope; if the question predicate broadens, rerun this proof.

It is defensible to retain predeclared V7 RoBERTa4 as prior-source model/threshold selection, do no new tuning, then record a separately source-bound V8 selected-profile/all4 development run plus focused regressions, browser/fullPython/installed-wheel gates. No material reason identified to repeat all14model/threshold cells solely for this unreachable development predicate. Do not call old V7 grids a V8 matched comparison; metadata contract changes to reader-parts-v6 and the new browser behavior require fresh V8 observations. This efficiency conclusion does not clear the three material guard counterexamples or imply unseen quality.

## Exact commands/results

1. `python <this-dir>/audit_development_predicate.py`: exit0; zero raw/prepared matches as above (`development-predicate-audit.log`).
2. `python -m pytest <this-dir>/test_independent_adjacent_steps.py tests/test_reader_adjacent_steps.py tests/test_answer_reader.py::test_reader_preserves_genuine_multiple_document_answers -c pyproject.toml -q --basetemp=<this-dir>/t1 -o cache_dir=<this-dir>/cache`: exit1, **3 failed,14 passed in1.34s** (`probes-1.log`). Nine independent cases, seven owned cases, one existing multiple-document case.
3. Read-only Python/git-show old pure support binding comparison: exit0, all three reject (`baseline-rejections.log`). No application/model process.

Original interpreter, isolated apps/api PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, offline flags/blank provider key, deterministic fixture generation and mocked QA/disposable scratch SQLite only. Source hash window began after parent confirmed formatting complete. `source-before.json`/`source-after.json` match for all five inspected reader/pipeline modules. Reviewer writes scratch artifacts only; no application/repository tests/evidence/assets/services changes.

Limits: guard-seam/mocked pipeline evidence, not a new model/baseline/fresh-blind measurement. No arbitrary grammar expansion or entailment claims. Actual V8 browser/installed-wheel/full-suite and final source/model/scorer/settings freeze remain parent-owned pending gates before any new200-case authoring.
