"""The following instruction cannot be a question either."""
from app.services.reader_questions import mismatch_reason

def test_following_question_is_not_a_plain_instruction():
    question='What must be paused before restoring the staging snapshot?'
    context='Pause the deployment queue. Restore the staging snapshot?'
    answer='deployment queue'
    start=context.index(answer)
    assert mismatch_reason(question,context,start,start+len(answer))=='requested_topic_is_introduced_after_selected_clause'
