# V8 adjacent-step final bounded recheck (2026-10-24)

The three retained unsafe-exemption counterexamples are repaired. No additional unsafe acceptance found within the exercised scope. The current deliberately narrow grammar still has conservative false-refusal limits, recorded below rather than expanded into an unbounded taxonomy. This is not a model-quality/browser/release or blind-freeze verdict.

## Verified repair and controls

Suffix normalization now applies to requested passive/gerund verbs, while source command heads retain bare/silent-e forms. Gerund narrative `Pausing ... is prohibited` no longer qualifies. Explicit neither/negative commands are excluded. A question mark between selected and following clauses, or at the following clause end, no longer qualifies as plain instructions.

Exact retained3 previously failing cases now pass their rejection assertions. Regular Stop/stopped/Swap/swapping and Isolate/isolated/Move/moving controls remain accepted. Wrong-topic/intervening command, Diagram/Violet captions, negative following command, after-question and reversed-helper-order controls pass. The existing genuine multiple-document answer control passes. The original accepted Pause/Restore and Close/Replace cases remain accepted.

Remaining conservative language scope was observed explicitly (`conservative-negation-scope.log`): `Close the inlet valve, not the outlet. Replace the intake filter.` and `Pause the deployment queue. Restore the staging snapshot with no traffic.` still get the topic-later rejection for the corresponding before question. The exemption intentionally excludes every no/not/never/neither/nor token in either clause, even a positive instruction's contrast or constraint. These are not claimed passing forms and were not counted as normative regression passes. This narrow limitation should stay explicit; no new heuristic/grammar expansion was requested or implemented here. Semantic subject/negation scope and general ordering/entailment remain beyond this surface exemption.

## Refreshed syntax proof and comparison recommendation

`audit_development_predicate_recheck.py` extracts the exact requested-question regex from current helper AST and checks only existing exposed development question strings plus actual question_parts preparation. Result remains80questions/154preparedparts, zero raw/prepared predicate matches. Corpus cases SHA256 remains68f1e41d2ba336d2f5edfc9ece3fe7e417fe05f17c22eadabea20c35732d3976. Current reader_support SHA256be022fb16b82d41ff3210ede3288f4ce090a8f5d9f492fca607b4534891c9f4f. Original proof/log and original3RED evidence remain preserved separately.

With this source-narrowing delta and unchanged question predicate, retaining V7's predeclared RoBERTa4 selection without new threshold tuning is defensible. Record a new V8 selected-profile/all4 development observation and current-source fullPython/browser/installed-wheel checks; do not relabel V7 as a V8 matched14grid. No material need identified to rerun all14cells solely for a branch unreachable on those80development questions. This does not predict unseen-case accuracy or close the required eventual200-case blind gate. If application/question predicate/corpus/settings change beyond this scope, reassess the proof and source-bound claims.

## Exact commands/results

1. `python <this-dir>/audit_development_predicate_recheck.py`: exit0, zero raw/prepared matches (`development-predicate-audit-recheck.log`/`.json`). No source/expected-answer/model labels used to design a rule.
2. `python -m pytest <this-dir>/test_independent_adjacent_steps.py <this-dir>/test_following_question_control.py tests/test_reader_adjacent_steps.py tests/test_answer_reader.py::test_reader_preserves_genuine_multiple_document_answers -c pyproject.toml -q --basetemp=<this-dir>/t2 -o cache_dir=<this-dir>/cache`: exit0, **21 passed in0.94s** (`recheck-1.log`). Nine retained independent cases, one following-question control, ten owned cases and one multiple-document control.
3. Read-only Python calls for the two conservative-negation-limit examples: exit0, both still rejected (`conservative-negation-scope.log`); not a model evaluation or a claim they are semantically unsupported.

Original interpreter, isolated apps/api PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, offline model flags/blank provider key, mocked QA and disposable scratch SQLite only. No live server/browser/model/grid/download was started or touched. `recheck-source-before.json` and `recheck-source-after.json` match across five inspected pipeline files. Reviewer writes scratch artifacts only, with no app/tests/evidence/assets/services changes and no future-author material access.

Parent's earlier540-pass full run predates this repair and is intermediate evidence only. Actual final-source full suite, selected profile, browser, installed package and formal freeze remain separate parent-owned gates. Preserve the failed V7 browser/old stale-contract diagnostics and qualify later harness corrections; none were overwritten or promoted by this review.
