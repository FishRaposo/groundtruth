"""Question-syntax reachability only; no sources/labels/model inference."""
import ast,hashlib,inspect,json,re
from pathlib import Path
from app.services.reader_support import adjacent_before_steps
from app.services.reader_questions import question_parts
R=Path(r'C:/Projects/operation-fan-the-hammer/.tmp/groundtruth-coverage-20261024')
W=R/'delivery-worktree'
D=W/'apps/api/app/portfolio/assets/coverage-development-v3/cases.json'
O=R/'coverage-v3/code-review/v8-adjacent-review'
tree=ast.parse(inspect.getsource(adjacent_before_steps))
assignment=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='requested' for t in n.targets))
pattern=ast.literal_eval(assignment.value.args[0])
cases=json.loads(D.read_text(encoding='utf-8'))
raw=[]
prepared=[]
count=0
for i,case in enumerate(cases):
    question=case['question']
    if re.match(pattern,question,re.I): raw.append(i)
    for j,part in enumerate(question_parts(question)):
        count+=1
        if re.match(pattern,part.question,re.I): prepared.append([i,j])
output={'scope':'existing exposed development-v3 question strings only; no expected answers or sources used','question_count':len(cases),'prepared_part_count':count,'raw_predicate_matches':raw,'actual_prepared_predicate_matches':prepared,'cases_sha256':hashlib.sha256(D.read_bytes()).hexdigest(),'predicate_pattern':pattern,'reader_support_sha256':hashlib.sha256((W/'apps/api/app/services/reader_support.py').read_bytes()).hexdigest(),'implication':'new adjacent-before exemption cannot activate on any existing development question part' if not prepared else 'predicate reachability exists; no equivalence claim'}
(O/'development-predicate-audit-recheck.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps(output))

