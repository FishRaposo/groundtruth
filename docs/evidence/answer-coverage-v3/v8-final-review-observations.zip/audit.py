import hashlib
import importlib.util
import json
from pathlib import Path
from contextlib import nullcontext
import zipfile

V = Path(__file__).resolve().parents[2]
W = V.parent / 'delivery-worktree'
E = W / 'docs/evidence/answer-coverage-v3'
OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
result = {'archives': {}, 'scanner_controls': {}}
for p in sorted(E.glob('v8-*.zip')):
    digest = sha(p.read_bytes())
    assert p.with_name(p.name + '.sha256').read_text().split()[0].lower() == digest
    with zipfile.ZipFile(p) as z:
        hashes = json.loads(z.read('archive-file-hashes.json'))
        assert set(z.namelist()) == set(hashes) | {'archive-file-hashes.json'}
        for name, expected in hashes.items():
            assert sha(z.read(name)) == expected, name
            assert z.read(name) == (V / name).read_bytes(), name
    result['archives'][p.name] = {'sha256': digest, 'verified_entries': len(hashes)}
report = E / 'v8-development-all-methods.json'
assert report.read_bytes() == (V / 'default-profile-v8/report.json').read_bytes()
assert sha(report.read_bytes()) == report.with_name(report.name + '.sha256').read_text().split()[0].lower()
before = json.loads((V / 'default-profile-v8/source-before.json').read_text())
after = json.loads((V / 'default-profile-v8/source-after.json').read_text())
assert before == after
for name, expected in after.items():
    assert sha((W / name).read_bytes()) == expected, name
result['profile_source_bindings'] = len(after)
result['profile_report_sha256'] = sha(report.read_bytes())
summary = json.loads((V / 'default-profile-v8/result.json').read_text())
assert summary['evaluation_exit'] == 1
for name, counts in summary['summary'].items():
    assert (counts['answerable_correct'], counts['answerable_total'], counts['negative_correct'], counts['negative_total']) == (47, 48, 32, 32)
    for key in ['unauthorized_source_exposures', 'execution_errors', 'citation_integrity_failures', 'span_integrity_failures']:
        assert counts[key] == 0
result['profile_summary'] = 'all four:47/48+32/32; evaluator1; development only'
spec = importlib.util.spec_from_file_location('scan', W / 'scripts/check_forbidden_dependencies.py')
scan = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scan)
with nullcontext(OUT / 'fixture') as tmp:
    root = Path(tmp)
    root.mkdir(exist_ok=True)
    app = root / 'apps'
    for directory in ['.next-v8', '.next-coverage', '.nextish']:
        p = app / 'web' / directory / 'source.ts'
        p.parent.mkdir(parents=True)
        p.write_text('import shared_core', encoding='utf-8')
    source = app / 'web/.next-config.ts'
    source.write_text('import shared_core', encoding='utf-8')
    found = scan._files(app)
    assert set(found) == {source, app / 'web/.nextish/source.ts'}
    scan.ROOT, scan.TARGETS = root, (app,)
    assert scan.main() == 1
    result['scanner_controls'] = {'generated_custom_build_excluded': True, 'ordinary_similar_directory_scanned': True, 'similar_filename_scanned': True, 'real_source_forbidden_import_exit': 1}
initial = json.loads((OUT / 'source-before.json').read_text(encoding='utf-8-sig'))
final = [{'Path': entry['Path'], 'Hash': sha(Path(entry['Path']).read_bytes()).upper()} for entry in initial]
(OUT / 'source-after.json').write_text(json.dumps(final, indent=2), encoding='utf-8')
assert final == initial
result['review_source_bindings_unchanged'] = len(final)
coverage = json.loads((V / 'v8-final-python-coverage.json').read_text())['totals']
result['final_coverage'] = coverage
(OUT / 'audit-result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
