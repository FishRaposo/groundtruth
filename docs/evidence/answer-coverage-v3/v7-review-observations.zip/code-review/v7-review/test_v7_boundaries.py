"""Bounded V7 topic/marker/window counterexamples; no model."""
import pytest
from app.services.reader_support import procedure_features
from app.services.reader_questions import mismatch_reason

QUESTION='What are the steps for Orion seal inspection?'

@pytest.mark.parametrize('other_heading',['Office closing:','Cedar packaging:'])
def test_explicit_other_heading_with_new_markers_does_not_inherit(other_heading):
    text='At Orion, Morgan supervises seal inspection. '+other_heading+' Begin by locking the desk. After that, turn off the lights. Finish by signing the card.'
    start=text.index('locking')
    result=procedure_features(QUESTION,text,start=start,end=start+len('locking the desk'),anchors=('orion',))
    assert result['explicit_sequence'] is True
    assert result['selected_sequence'] is False

def test_multiple_begin_sequences_keep_their_own_immediate_topic():
    text='At Orion, Morgan supervises seal inspection. Begin by isolating the console. Finish by inspecting the seal. Cedar packaging is supervised by Lian. Begin by closing the carton. Finish by applying tape.'
    for raw,expected in [('isolating the console',True),('closing the carton',False)]:
        start=text.index(raw)
        assert procedure_features(QUESTION,text,start=start,end=start+len(raw),anchors=('orion',))['selected_sequence'] is expected

def test_intervening_other_topic_sentence_is_not_skipped():
    text='At Orion, Morgan supervises seal inspection. Cedar packaging needs a carton. Begin by closing the carton. After that, apply tape.'
    start=text.index('closing')
    assert procedure_features(QUESTION,text,start=start,end=start+len('closing the carton'),anchors=('orion',))['selected_sequence'] is False

@pytest.mark.parametrize('question',[
    'Regarding Orion inspection, what is the box count for the session window?',
    'What is the total number of boxes in the time window?',
])
def test_temporal_window_qualifier_does_not_turn_count_into_schedule(question):
    text='Orion inspections are booked from 09:20 to 10:30.'
    start=text.index('09:20')
    assert mismatch_reason(question,text,start,start+len('09:20 to 10:30')) is not None

@pytest.mark.parametrize('question',[
    'What is the Orion session window?',
    'What is its time window?',
])
def test_direct_window_request_remains_temporal(question):
    text='Orion inspections are booked from 09:20 to 10:30.'
    start=text.index('09:20')
    assert mismatch_reason(question,text,start,start+len('09:20 to 10:30')) is None
