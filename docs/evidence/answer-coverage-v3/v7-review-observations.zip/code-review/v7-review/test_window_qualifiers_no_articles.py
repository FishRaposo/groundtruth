"""Qualified counts without an article do not request a clock window."""
import pytest
from app.services.reader_questions import mismatch_reason

@pytest.mark.parametrize('question',[
    'What is the box count for session window?',
    'What is the total number of boxes in time window?',
    'What is its box count during session window?',
])
def test_count_window_qualifier_without_article_is_not_temporal(question):
    source='Orion inspections are booked from 09:20 to 10:30.'
    start=source.index('09:20')
    assert mismatch_reason(question,source,start,start+len('09:20 to 10:30')) is not None
