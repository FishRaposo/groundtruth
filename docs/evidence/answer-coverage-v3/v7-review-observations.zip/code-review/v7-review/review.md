# V7 bounded review (2026-10-24)

One material regression found; two independent assertions reproduce it. No additional procedure-continuation regression found within the requested bounds. Prior reviews/failed evidence remain preserved.

## Count questions qualified by a temporal window now accept a schedule interval

`apps/api/app/services/reader_support.py:35-37` adds an arbitrary optional noun phrase before the end-anchored `session window` or `time window`. Consequently the rule matches questions whose requested attribute is a count, while a window merely qualifies that count.

Both exact seam reproducers return `mismatch_reason=None` for source `Orion inspections are booked from 09:20 to 10:30.`, raw span34:48 (`09:20 to 10:30`):

- `Regarding Orion inspection, what is the box count for the session window?`
- `What is the total number of boxes in the time window?`

A clock interval cannot establish those requested counts; the existing non-temporal-attribute guard should continue rejecting it. The suffix anchor protects `window size` but does not protect a requested count before the window phrase. This is within the expressly retained count/window boundary, not a new grammar feature or a request for general entailment. Valid direct session/time-window questions must remain accepted.

Retained scratch assertion: `test_v7_boundaries.py::test_temporal_window_qualifier_does_not_turn_count_into_schedule` (two parameter cases). This is an acceptance-seam finding, not a claim that a real model/grid emitted either answer. The old8e8062d temporal_question/asks_elapsed functions were independently loaded by AST from git show without importing an old application, and classify both questions False (`baseline-temporal-classification.log`). The new optional prefix causes the regression.

## Passing bounded checks

The new Begin by/After that/Finish by structure is recognized without new inference. Explicit Office/Cedar headings do not inherit earlier Orion scope. Two restarted Begin/Finish sequences bind to their own immediate topic sentences. An intervening different-topic sentence is not skipped. Direct requested session/time windows retain exact clock-range acceptance. All new owned continuation tests and directly related old numbered/bullet/legacy/normalization/wrong-heading/interval controls pass. No change found to multiple-document input, span exactness, source privacy, primary-document selection or QA call count in this narrow diff.

The lead-empty-only fallback remains a surface ranking prior: a named topic's presence in an adjacent sentence does not generally prove procedure identity. Unsupported ambiguous discourse/formatting beyond the tested boundaries is a limitation, not an additional defect assertion here.

## Commands/results and hashes

Original interpreter, isolated delivery-worktree/apps/api PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, legacy import defaults/lexical selection, offline HF/Transformers and blank provider key. Fixture-only deterministic/extractive generation, mocked QA and dedicated scratch SQLite; no model/grid/browser/listening service/ownerDB.

`python -m pytest <this-dir>/test_v7_boundaries.py tests/test_reader_procedure_continuation.py tests/test_reader_procedure_evidence.py tests/test_reader_procedure_review.py -c pyproject.toml -q --basetemp=<this-dir>/t1 -o cache_dir=<this-dir>/cache`

Exit1: **2 failed,26 passed in2.03s**, exact `probes-1.log`. Eight independent cases plus twenty owned controls. Only the two qualified-count assertions fail.

Read-only baseline comparison command uses Python ast to select only asks_elapsed/temporal_question functions from `git show 8e8062d:apps/api/app/services/reader_support.py`, then evaluates the same two strings; exit0, both False. No old application/model/service execution.

`source-before.json` and `source-after.json` contain identical SHA256s for answer_reader.py and reader_support.py. Inspected diff only those two changed modules/new continuation tests against8e8062d, plus directly related procedure controls. Reviewer writes scratch artifacts only; no app/tests/evidence/models changes.

Limits: no model-quality/latency/performance/full-suite/release verdict, and no implication the recorded failed v6 comparison is repaired or invalid. Fresh model comparison remains a separate gate after source stabilization. Local sequence features and null margins are ranking/rejection heuristics, not NLI or general factual support proof.
