# V7 focused recheck (2026-10-24)

The original two qualified-count regressions are fixed. One retained positive now fails because the repair deliberately narrows the new branch to an exact direct noun phrase. This is not a new grammar expansion or new model finding.

Retained direct-window positive:

`mismatch_reason('What is the Orion session window?', 'Orion inspections are booked from 09:20 to 10:30.',34,48)`

Previously accepted in the first V7 review; current result is `clock_does_not_establish_requested_attribute` rather than None. The question directly requests a named session's time window, and its exact source interval is rejected. `What is its time window?` and owned `Regarding Nova inspection, what is the session window?` remain accepted. The original count/window-size/When protections, different headings, multiple sequences and continuation controls pass.

Production reference: reader_support.py new session/time-window alternative now allows no text between its determiner and `session|time window`. This removes the unsafe arbitrary-prefix behavior, but also loses the existing named-window control. Owner may repair this bounded false rejection or explicitly document the narrower unsupported form; all30 cannot truthfully be reported passing in current source. No additional forms or speculative grammar assertions were added.

## Exact result

Same selection as the original28 plus two newly owned parameter cases:

`python -m pytest <this-dir>/test_v7_boundaries.py tests/test_reader_procedure_continuation.py tests/test_reader_procedure_evidence.py tests/test_reader_procedure_review.py -c pyproject.toml -q --basetemp=<this-dir>/t2 -o cache_dir=<this-dir>/cache`

Exit1: **1 failed,29 passed in2.04s**, `recheck-1.log`. Original interpreter, isolated PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, blank provider key/offline model flags, fixture-only deterministic/extractive generation and scratch SQLite. No model/live server/browser/evidence/source writes.

`recheck-source-before.json` and `recheck-source-after.json` contain identical SHA256s for both inspected source modules. Original review and RED counterexamples preserved. No full-suite/model-quality/latency/release verdict; existing heuristic/formatting/entailment limits remain unchanged.
