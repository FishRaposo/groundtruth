# Bounded connected-profile review (2026-10-24)

No material defect found in the changed launcher/default-profile behavior within the inspected and mocked scope. This is configuration evidence, not a live helper/API/browser run, model-quality pass or blind-freeze/release verdict.

Inspected only scripts/portfolio_local.py diff/new tests and direct reader_catalog/config/reader_setup context. The already reviewed V7 NLU changes were not re-reviewed or changed.

## Verified behavior

- Actual no-extra-flags helper default is local embedding, reader selection, catalog-pinned RoBERTa revision adc3b06f79f797d1c575d5479d6f5efe54a9e3b4, threshold4, and distinct `.tmp/models/reader-roberta`. Default serve command remains host127.0.0.1/port8400; dispatch is mocked, so no port is opened.
- Explicit `--reader-model minilm` uses MiniLM revision934656cdda79824eabf503ed56e15c01ddbdbe3f, legacy `.tmp/models/reader`, threshold-8. Stale inherited revision/path/threshold/selection are overwritten by the chosen explicit profile.
- Explicit relative reader directory resolves as before; threshold0 is preserved, not treated as missing. Deterministic embedding defaults lexical; explicit lexical/local or reader/deterministic overrides remain preserved.
- migrate/serve/seed commands use the same offline/extractive profile, propagate subprocess return status, and strip known provider credential prefixes. Model/download dispatch is not part of profile resolution; only the immutable dataclass catalog is imported. Importing the helper does not parse arguments, create directories or import model runtime. main intentionally prepares the data directory before launching, as in the preexisting script.
- Invalid model choice, port0/65536, refusal threshold1.1/NaN and nonnumeric reader threshold produce argparse exit2 without dispatch. Reader-threshold NaN/Infinity are still accepted as floats by argparse (preexisting generic float behavior); downstream Settings explicitly rejects nonfinite values. This was reviewed as a fail-closed input limitation, not a changed-profile defect; no invalid startup was launched.
- Library Settings reader revision and reader_setup.download/CLI legacy MiniLM defaults remain unchanged; Settings null threshold remains0.0. The helper now deliberately owns its selected profile rather than changing library defaults.

## Exact command/result

Original GroundTruth venv interpreter; isolated delivery-worktree/apps/api PYTHONPATH; PYTHONDONTWRITEBYTECODE=1; blank provider key/offline model flags/legacy import defaults. Both owned and independent tests replace subprocess.run, preventing service/model/download/seed actions. All filesystem preparation is confined to dedicated scratch tmp_path directories.

`python -m pytest <this-dir>/test_independent_profile.py tests/test_portfolio_reader_profile.py -c pyproject.toml -q --basetemp=<this-dir>/t1 -o cache_dir=<this-dir>/cache`

Exit0: **19 passed in0.25s**, exact `probes-1.log` (sixteen independent cases plus three owned cases). Only safe selected environment keys/synthetic provider-key presence are captured by independent tests, not credential values or full inherited environment output.

`source-before.json` and `source-after.json` contain matching SHA256s for launcher, owned profile test, reader_catalog, reader_setup and config. Reviewer wrote only scratch tests/logs/report, with no application/repository tests/evidence/model/service edits.

Limits: dispatch is mocked; this does not prove installed assets exist at the new default path, that a running API loaded that profile, that server/browser flows pass, or that comparison quality/latency is acceptable. Actual helper API and browser checks remain separate parent-owned gates. No download/model/server was started and no blind artifacts were accessed.
