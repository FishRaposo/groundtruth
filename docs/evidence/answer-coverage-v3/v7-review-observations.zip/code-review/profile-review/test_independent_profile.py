"""Independent launcher profile parsing; dispatch is always mocked."""
import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace
import pytest
from app.reader_catalog import MINILM,ROBERTA

ROOT=Path(r'C:/Projects/operation-fan-the-hammer/.tmp/groundtruth-coverage-20261024/delivery-worktree')

def load_script():
    spec=importlib.util.spec_from_file_location('independent_portfolio_profile',ROOT/'scripts/portfolio_local.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

@pytest.fixture
def invocation(monkeypatch,tmp_path):
    module=load_script()
    monkeypatch.setattr(sys,'path',sys.path.copy())
    captured=[]
    safe_keys=('READER_MODEL_PATH','READER_MODEL_REVISION','READER_NULL_THRESHOLD','ANSWER_SELECTION_MODE','GENERATION_MODE','OPENAI_API_KEY','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','EMBEDDING_MODE')
    provider_keys=('ANTHROPIC_API_KEY','AZURE_OPENAI_KEY','GOOGLE_API_KEY','GEMINI_API_KEY')
    for key,value in {'READER_MODEL_REVISION':'stale','READER_NULL_THRESHOLD':'99','READER_MODEL_PATH':'stale-path','ANSWER_SELECTION_MODE':'stale-mode',**dict.fromkeys(provider_keys,'scratch-sentinel')}.items():
        monkeypatch.setenv(key,value)
    def dispatch(command,**kwargs):
        env=kwargs['env']
        captured.append({'command':list(command),'cwd':kwargs['cwd'],'profile':{key:env[key] for key in safe_keys},'provider_keys_remaining':[key for key in provider_keys if key in env]})
        return SimpleNamespace(returncode=17)
    monkeypatch.setattr(module.subprocess,'run',dispatch)
    def invoke(action='serve',extra=(),name='data'):
        data=tmp_path/name
        monkeypatch.setattr(sys,'argv',['portfolio_local.py',action,'--data-dir',str(data),*extra])
        result=module.main()
        return result,captured[-1],data
    return invoke,captured,module

@pytest.mark.parametrize('action',['migrate','serve','seed'])
def test_default_actual_flags_and_actions_are_pinned_and_offline(invocation,action):
    invoke,captured,module=invocation
    result,observed,data=invoke(action)
    profile=observed['profile']
    assert result==17 and len(captured)==1
    assert profile['READER_MODEL_REVISION']==ROBERTA.revision
    assert float(profile['READER_NULL_THRESHOLD'])==4
    assert Path(profile['READER_MODEL_PATH'])==(ROOT/'.tmp/models/reader-roberta').resolve()
    assert profile['ANSWER_SELECTION_MODE']=='reader' and profile['GENERATION_MODE']=='extractive'
    assert profile['OPENAI_API_KEY']=='' and observed['provider_keys_remaining']==[]
    assert profile['HF_HUB_OFFLINE']==profile['TRANSFORMERS_OFFLINE']=='1'
    assert observed['cwd']==ROOT and data.is_dir()
    if action=='serve':
        assert observed['command'][1:4]==['-m','uvicorn','app.main:app']
        assert observed['command'][observed['command'].index('--port')+1]=='8400'
    elif action=='migrate': assert observed['command'][1:]==['-m','app.db.migrate']
    else: assert '--confirm-disposable-database' in observed['command']

def test_explicit_minilm_replaces_stale_profile_and_keeps_legacy_dir(invocation):
    invoke,_,_=invocation
    _,observed,_=invoke(extra=['--reader-model','minilm'])
    profile=observed['profile']
    assert profile['READER_MODEL_REVISION']==MINILM.revision
    assert float(profile['READER_NULL_THRESHOLD'])==-8
    assert Path(profile['READER_MODEL_PATH'])==(ROOT/'.tmp/models/reader').resolve()

@pytest.mark.parametrize('extra,expected',[
    (['--embedding','deterministic'],'lexical'),
    (['--embedding','local','--answer-selection','lexical'],'lexical'),
    (['--embedding','deterministic','--answer-selection','reader'],'reader'),
])
def test_selection_flags_preserve_explicit_and_legacy_modes(invocation,extra,expected):
    invoke,_,_=invocation
    _,observed,_=invoke(extra=extra)
    assert observed['profile']['ANSWER_SELECTION_MODE']==expected

def test_explicit_relative_dir_and_zero_threshold_are_not_lost(invocation):
    invoke,_,_=invocation
    _,observed,_=invoke(extra=['--reader-dir','relative-reader','--reader-threshold','0'])
    assert Path(observed['profile']['READER_MODEL_PATH'])==Path('relative-reader').resolve()
    assert float(observed['profile']['READER_NULL_THRESHOLD'])==0

@pytest.mark.parametrize('extra',[
    ['--reader-model','unapproved'],['--port','0'],['--port','65536'],
    ['--refusal-threshold','1.1'],['--refusal-threshold','nan'],['--reader-threshold','nonsense'],
])
def test_invalid_parse_exits_before_directory_or_dispatch(invocation,extra):
    invoke,captured,module=invocation
    with pytest.raises(SystemExit) as raised: invoke(extra=extra,name='invalid')
    assert raised.value.code==2 and captured==[]

def test_import_does_not_dispatch_or_import_reader_runtime(monkeypatch):
    import builtins
    original=builtins.__import__
    imported=[]
    def guarded(name,*args,**kwargs):
        imported.append(name)
        if name.split('.')[0] in {'torch','transformers','huggingface_hub'}:
            raise AssertionError('reader runtime imported during script import')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',guarded)
    module=load_script()
    assert callable(module.main)
    assert not any(name.startswith('app.') for name in imported)

def test_library_setup_and_settings_defaults_remain_legacy():
    from app.config import Settings
    from app.reader_setup import download,MODEL,REVISION
    assert Settings.model_fields['READER_MODEL_REVISION'].default==MINILM.revision
    assert Settings.model_fields['READER_NULL_THRESHOLD'].default==0.0
    assert MODEL==MINILM.model and REVISION==MINILM.revision
    assert download.__kwdefaults__['model']=='minilm'
