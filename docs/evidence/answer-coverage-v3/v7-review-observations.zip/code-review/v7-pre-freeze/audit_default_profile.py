"""Audit newly completed default-profile evidence only; never starts a service."""
import hashlib,json
from pathlib import Path
R=Path(r'C:/Projects/operation-fan-the-hammer')
W=R/'.tmp/groundtruth-coverage-20261024/delivery-worktree'
V=R/'.tmp/groundtruth-coverage-20261024/coverage-v3'
D=V/'default-profile-v7'
OUT=V/'code-review/v7-pre-freeze'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
launch=read(D/'launch.json')
assert '--reader-model' not in launch['command'] and '--reader-threshold' not in launch['command']
assert launch['reader_model_and_threshold_overrides'] is False
source=read(D/'source-before.json')
assert source==read(D/'source-after.json')
assert all(sha(W/relative)==digest for relative,digest in source.items())
report=read(D/'report.json')
result=read(D/'result.json')
assert result['evaluation_exit']==1
assert result['summary']=={k:v['summary'] for k,v in report['results'].items()}
assert set(report['results'])=={'keyword','vector','hybrid','reranked'}
for method,body in report['results'].items():
    assert len(body['cases'])==80
    s=body['summary']
    assert (s['answerable_correct'],s['answerable_total'],s['negative_correct'],s['negative_total'])==(47,48,32,32)
    assert s['refusal_false_positives']==1
    assert not any(s[k] for k in ('unauthorized_source_exposures','execution_errors','citation_integrity_failures','span_integrity_failures'))
health=read(D/'readiness.json')
assert health['status']=='ready'
# Record only source digests and non-sensitive summary values.
output={'status':'completed_default_launcher_observation_verified_not_acceptance','model_threshold_overrides':False,'reader_directory_explicit': '--reader-dir' in launch['command'],'source_files_verified_current':len(source),'raw_report_sha256':sha(D/'report.json'),'results':result['summary'],'evaluation_exit':result['evaluation_exit'],'unique_exposed_development_cases':80,'method_case_executions':320}
(OUT/'default-profile-audit.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:output[k] for k in ('status','source_files_verified_current','model_threshold_overrides','reader_directory_explicit','evaluation_exit','unique_exposed_development_cases','method_case_executions')}))
