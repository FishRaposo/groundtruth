"""Read-only completed V7 evidence audit; never accesses future author material."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(r'C:/Projects/operation-fan-the-hammer')
W=R/'.tmp/groundtruth-coverage-20261024/delivery-worktree'
V=R/'.tmp/groundtruth-coverage-20261024/coverage-v3'
OUT=V/'code-review/v7-pre-freeze'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
comparison=read(V/'matched-readers-v7.json')
assert comparison==read(W/'docs/evidence/answer-coverage-v3/matched-readers-v7.json')
rule=read(V/'matched-readers-v7-rule.json')
assert rule==comparison['rule']==read(W/'docs/evidence/answer-coverage-v3/matched-readers-v7-rule.json')
errors=[]
readers=[]
all_sources=[]
selection=[]
for entry in comparison['readers']:
    name=entry['reader']
    directory=V/f'development-{name}-continuation-v7'
    before=read(directory/'source-before.json')
    after=read(directory/'source-after.json')
    assert before==after
    all_sources.append(before)
    mismatches=[relative for relative,digest in before.items() if sha(W/relative)!=digest]
    assert not mismatches,mismatches
    assert read(directory/'model-before.json')==read(directory/'model-after.json')
    manifest_digest=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest()
    assert manifest_digest==comparison['application_source_manifest_sha256']
    verified=[]
    for row in entry['grid']:
        threshold=row['threshold']
        report_path=directory/f'threshold-{threshold:g}.json'
        digest=sha(report_path)
        assert digest==row['report_sha256']==(report_path.with_suffix('.json.sha256')).read_text().strip()
        report=read(report_path)
        result=report['results']['reranked']
        assert result['summary']==row['summary']
        cases=result['cases']
        assert len(cases)==80
        assert sum(bool(case['refused']) for case in cases)==row['refused_count']
        summary=row['summary']
        assert summary['answerable_total']==48 and summary['negative_total']==32
        eligible=summary['negative_correct']==32 and not any(summary[k] for k in ('unauthorized_source_exposures','execution_errors','citation_integrity_failures','span_integrity_failures'))
        verified.append({'threshold':threshold,'positive_correct':summary['answerable_correct'],'negative_correct':summary['negative_correct'],'eligible':eligible,'quality_exit_code':row['exit_code'],'report_sha256':digest})
        if eligible: selection.append({'reader':name,**row})
    archive=W/f'docs/evidence/answer-coverage-v3/{name}-continuation-v7-observations.zip'
    advertised=archive.with_suffix('.zip.sha256').read_text().split()[0]
    assert sha(archive)==advertised
    with zipfile.ZipFile(archive) as z:
        integrity=z.testzip()
        assert integrity is None
        manifests=[n for n in z.namelist() if n.endswith('archive-file-hashes.json')]
        # Record internal layout without presuming the archive contract shape.
        manifest_names=manifests
        archive_reports=[]
        for filename in z.namelist():
            if filename.endswith('.json') and Path(filename).name.startswith('threshold-'):
                data=z.read(filename)
                expected=sha(directory/Path(filename).name)
                assert hashlib.sha256(data).hexdigest()==expected
                archive_reports.append(filename)
        assert len(archive_reports)==7
    readers.append({'reader':name,'source_files_verified_current':len(before),'source_manifest_sha256':manifest_digest,'model_snapshot_before_after_equal':True,'reports':verified,'archive_sha256':sha(archive),'archive_raw_reports_verified':len(archive_reports),'archive_manifest_names':manifest_names})
assert all_sources[0]==all_sources[1]
selection.sort(key=lambda row:(-row['summary']['answerable_correct'],-row['refused_count'],row['threshold'],row['reader']!='minilm'))
assert selection[0]==comparison['best_eligible_development']
log=(V/'v7-combined-python.log').read_text(encoding='utf-8-sig')
assert '533 passed, 1 skipped in 143.09s' in log
output={'status':'bounded_completed_development_evidence_verified_not_acceptance','rule':rule,'selected':{'reader':selection[0]['reader'],'threshold':selection[0]['threshold'],'answerable_correct':selection[0]['summary']['answerable_correct'],'negative_correct':selection[0]['summary']['negative_correct'],'quality_exit_code':selection[0]['exit_code']},'readers':readers,'combined_log_sha256':sha(V/'v7-combined-python.log'),'combined_log_result':'533 passed, 1 skipped in 143.09s'}
(OUT/'evidence-audit.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'selected':output['selected'],'current_source_count':len(all_sources[0]),'verified_reports':14,'archive_raw_reports':14,'combined_log_result':output['combined_log_result']}))
