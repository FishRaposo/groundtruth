# Development follow-up; keep v6 application source immutable during both grids

Observed exposed-development mechanisms, not a new blind set:

1. The sequence prior ignores an ordinary immediately preceding topic sentence
   when First begins a new sentence. Its local lead is empty, so proper names
   are unavailable. Allow that immediately preceding sentence only for an empty
   local lead; never borrow a name across an explicit unrelated sequence heading.
   Preserve raw-span containment, multiple-sequence controls and unmarked fallback.
2. Equivalent clause-initial Begin by / After that / Finish by instructions are
   unrecognized sequence structure. Recognize these bounded ordinary markers as
   a ranking signal only, not support or permission; no domain/case aliases.
3. An explicit session-window question is rejected as a non-temporal attribute
   when its real selected span is a clock interval. Preserve count/size/wrong-
   attribute rejections while recognizing the explicit temporal noun phrase.

Record independent fixtures RED before code, focused GREEN and bounded review.
Do not change v6 application/model/corpus/scorer until both grids complete and
exact raw reports/hashes are archived. No new inference retry, context cropping,
primary-document narrowing, answer fabrication or weakening all-part coverage.
The remaining reader false refusal may remain a model limitation. Run new fixed
source measurements after repairs. No blind authoring until a promising result
and candidate/source/model/scorer/settings freeze.
