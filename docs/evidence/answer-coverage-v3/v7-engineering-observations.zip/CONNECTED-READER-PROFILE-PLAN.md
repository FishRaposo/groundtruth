# Candidate connected-reader profile, before blind freeze

Wait for both v7 model grids and the predeclared selection rule. If the final
eligible result remains RoBERTa4 (currently observed47/48+32/32), freeze that
as the candidate connected profile before authoring new cases. It is development
selection only, not release approval.

The existing portfolio_local.py helper defaults to old MiniLM-8, so a caller
following the default setup would not exercise the improved candidate. Add a
reader-model option selecting pinned catalog metadata. Candidate default uses
RoBERTa with a separate reader-roberta cache directory and measured threshold4;
explicit MiniLM retains reader cache and legacy threshold-8. Reader-dir and
threshold overrides remain explicit; no asset download, fallback or provider use.
Set READER_MODEL_REVISION from the selected catalog, overriding stale inherited
model revision. Keep library Settings and reader_setup.download legacy defaults.

First preserve RED for default env/path/revision, explicit MiniLM compatibility
and overrides; mock only child-process dispatch. Verify real candidate launch
using this helper with dedicated8402/disposable data, then metadata/model path
readiness and normal/SSE/browser outcomes. Bounded independent review before
freezing candidate commit/config/scorer/model hashes. Do not refresh owner review
until fresh blind acceptance passes. Update setup/default instructions to agree;
preserve original MiniLM assets and old execution evidence.

No model/configuration choice is frozen by this plan file. Do not implement while
both measured application source grids are still active. This makes the default
connected path testable; it introduces no new answer/retrieval algorithm.
