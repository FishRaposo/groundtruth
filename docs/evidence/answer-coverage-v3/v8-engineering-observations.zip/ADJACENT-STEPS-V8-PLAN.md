# Adjacent imperative qualifier, before any new blind freeze

Actual connected browser V7 reaches the earlier rollback successfully, then
falsely refuses the unchanged uploaded-runbook question: what must be paused
before restoring the staging snapshot? The model selects the deployment queue
with null margin -6.13, but topic_introduced_later rejects it because the target
snapshot appears in the immediately following instruction. Preserve that failed
browser run and V7 measurements; no candidate freeze or new author yet.

Focused identical command records2RED/5controls in adjacent-steps-red.log. Add
only a rejection exemption for an explicit What must/should be <verb> before
<gerund> question, where the selected clause begins with that inflected verb and
the immediately following clause begins with the requested gerund's base verb.
Both must be adjacent plain instructions; intervening material, named labels,
negative commands and narrative subjects do not qualify. The following requested
topic must actually occur in that same following clause. This only suppresses a
heuristic false rejection; it never grants permission or establishes an answer
without the model's accepted exact span and all existing checks.

Use mechanical regular suffix comparison, no domain aliases, model requery,
context cropping or primary-document restriction. Label the selection contract
reader-parts-v6 after behavior changes. Record GREEN and independent adversarial
review before new source-bound model/profile checks. Any additional findings get
their own retained RED/GREEN. This is bounded grammar, not general entailment.

Wait for the existing non-reloading V7 browser process suite to finish before
editing application files so failed screenshots remain bound to V7. New V8
browser output and database must not overwrite V7. Full matched grids are not
blind validation; freeze the eventual final source/config/scorer/model hashes
before clean-context independent authoring of200newcases.
