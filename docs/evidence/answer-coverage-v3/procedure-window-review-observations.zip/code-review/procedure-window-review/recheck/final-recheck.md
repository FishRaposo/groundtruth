# Final procedure-window bounded recheck (2026-10-24)

No remaining material defect found within the inspected repair and exercised boundaries. Original normalization/selection findings and RED logs remain intact; this note records their verified resolution, not a model-quality or release verdict.

- Retained numbered-ingestion HTTP fixture now passes.
- Retained mixed-topic Office-closing HTTP fixture now passes.
- Existing bullet normalization assertion now passes after the one-line token-boundary bullet detector change.
- Selected raw spans inside unrelated Office steps remain unpreferred; explicit restarted First/Next and1/2multiple sequences bind to their local named headings.
- Unknown offsets do not invent selected sequence support; unmarked accepted evidence keeps ordinary margin compatibility.
- Time-interval count/When/elapsed/procedure controls and owned controls pass.

## Command/result and retained local-path failure

Original interpreter, isolated delivery-worktree/apps/api PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, offline HF/Transformers, blank provider key, legacy import defaults/lexical mode; mocked reader plus deterministic fixture generation, disposable SQLite only. No model/live service.

Same selection as the previous28-probe command:

`python -m pytest <parent>/test_independent_procedure_window_valid.py <this-dir>/test_selected_sequence_edges.py tests/test_reader_procedure_evidence.py tests/test_reader_procedure_review.py -c pyproject.toml -q --basetemp=<this-dir>/t1 -o cache_dir=<this-dir>/cache`

Exit0: **29 passed in3.33s** (`final-probes-2.log`). This is the identical retained28 plus the newly added owned bullet regression collected by the same module selection.

The preceding identical selection used longer `--basetemp=<this-dir>/final-probe-temp-1`: exit1,5failed/24passed in6.75s (`final-probes-1.log`). All five HTTP fixtures failed at upload file creation with FileNotFoundError, before answer assertions. Only the scratch basetemp was shortened for the successful rerun; no source/test/fixture changes between them. This failure is preserved and is not counted as a passed application/answer test. The sample failing upload path is264characters versus248for the equivalent shorter base, consistent with a Windows path boundary; actual successful generated node folder lengths vary by fixture reuse suffix. No broader filesystem repair or application change was performed.

`final-source-before.json`, `final-source-after.json`, and `final-source-after-shortpath.json` record identical SHA256s for all four reader modules across both runs. Earlier restarted formatting qualification remains in recheck/review.md. Reviewer writes scratch artifacts only, with no application/repository-test/evidence/asset/service mutation.

Limits: source-format/selection and fixture evidence only; no full suite, model/grid/browser, comparative quality/latency/performance, new blind or release verdict. Formatting/anchors/raw margins remain bounded priors and do not establish factual entailment, full subject identity, arbitrary source-format recognition, or completeness of every unmarked procedure. A parent's full suite begun before this bullet change remains stale for the final-source claim and must be qualified/rerun separately.

