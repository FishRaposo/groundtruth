# Focused selected-sequence re-review (2026-10-24)

The two prior valid real-API regressions are repaired. No new wrong-topic selection defect found within the requested proportional checks. One residual instance of the existing normalization defect remains: hyphen-bulleted lists are still recognized only before canonical whitespace collapse.

## Residual finding: existing bulleted-list feature is lost after normalization

`apps/api/app/services/reader_support.py` still constructs bullets with `(?m)^\s*([-*])\s+\S`, while the same normalizer collapses newline whitespace. Original source `Orion valve inspection:\n- Isolate the console.\n- Inspect the seal.\n- Photograph its edges.` reports explicit_sequence=True. Canonical source reports explicit_sequence=False and selected_sequence=False despite raw offsets inside the first step and anchors=('orion',). This prevents the intended structure preference for the already supported bulleted format. The numbered half of the normalization repair works; the bullet half does not. Original PROCEDURE-WINDOW-PLAN explicitly includes numbered/bulleted sequences, so this is a residual supported-boundary issue, not a proposed arbitrary new format.

Exact retained failing assertion: `test_selected_sequence_edges.py::test_existing_bulleted_sequence_survives_canonical_normalization`. It calls production normalize_content then production procedure_features with exact codepoint offsets. No model prediction or actual model-quality claim. Prior independent HTTP numbered fixture already demonstrates the downstream consequence of losing this same feature: ordinary margins select booking/return evidence instead of the intended structured source. This new bullet assertion directly localizes remaining feature loss without repeating the HTTP infrastructure.

## Passing checks and narrow review

- Both prior independent real-upload/query tests now pass: normalized numbered procedure is preferred, and unrelated Office-closing formatting cannot promote a selected booking-return span.
- Direct raw span inside the unrelated Office First/Next steps remains unpreferred when request anchor Orion appears only in an earlier booking sentence.
- Multiple explicitly restarted First/Next and1/2sequences bind selected spans to each local heading; requested sequence true, unrelated Office sequence false.
- Unknown raw offsets do not manufacture selected_sequence; unmarked accepted sources still choose by ordinary margins rather than being refused.
- Retained interval count/When/elapsed/full-procedure controls pass.
- Owned procedure evidence/review controls pass.

Inspected four current reader module changes and both procedure test files. New selected_sequence requires valid raw offsets inside the sequence and named anchors in its local lead, and witnessv3 ranks only already accepted candidates using that feature. LocalReader passes exact raw offsets and existing question anchors; no new model call, input cropping or primary-document restriction found. These remain surface ranking signals, not general factual entailment. No arbitrary marker/grammar expansion tested.

## Actual command and hashes

Original interpreter, isolated apps/api PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, offline HF/Transformers, legacy import defaults/lexical selection. Fixtures enable deterministic/extractive execution and mocked QA. Only scratch SQLite and no live server/model.

`python -m pytest <parent-dir>/test_independent_procedure_window_valid.py <this-dir>/test_selected_sequence_edges.py tests/test_reader_procedure_evidence.py tests/test_reader_procedure_review.py -c pyproject.toml -q --basetemp=<this-dir>/probe-temp-1 -o cache_dir=<this-dir>/cache`

Exit1: **1 failed,27 passed in4.18s**, exact `probes-1.log`. Eight retained independent cases, six proportional independent cases, fourteen owned cases.

Initial source-before snapshot preceded parent-declared formatting-only work. A fresh hash window was captured after that notice: `source-restarted-before.json` and `source-after.json` contain identical SHA256s for all four inspected reader modules. Initial snapshot retained and not claimed stable. Reviewer wrote only scratch tests/logs/report; no app/repository-test/evidence/asset/service changes.

Limits: bounded source/fixture review; no model/grid/browser/quality/latency/full-suite/release verdict. Marker/anchor checks do not establish correct procedure identity when different tasks share names, recognize all possible source formatting, or certify unmarked completeness. Existing fallback intentionally retains prior margin behavior when structure is unknown.
