"""Proportional selected-sequence binding boundaries; no model."""
import pytest
from app.models.query import AnswerSpan
from app.services.reader_support import procedure_features
from app.services.reader_witnesses import select_witness_cover
from app.services.document_intelligence import normalize_content

QUESTION='What are the steps for Orion valve inspection?'

@pytest.mark.parametrize('context',[
    'Orion valve inspection: First, isolate the console. Next, inspect the seal. Office closing: First, lock the desk. Next, turn off the lights.',
    'Orion valve inspection: 1. Isolate the console. 2. Inspect the seal. Office closing: 1. Lock the desk. 2. Turn off the lights.',
])
def test_multiple_sequences_bind_to_local_named_heading(context):
    for raw,expected in [('isolate the console',True),('lock the desk',False)]:
        start=context.casefold().index(raw)
        result=procedure_features(QUESTION,context,start=start,end=start+len(raw),anchors=('orion',))
        assert result['selected_sequence'] is expected

def test_unknown_offsets_do_not_promote_formatted_source():
    features=procedure_features(QUESTION,'Orion valve inspection: First, isolate. Next, inspect.')
    assert features['explicit_sequence'] is True and features['selected_sequence'] is False

def test_unmarked_accepted_sources_still_use_margins():
    text='Orion valve inspection: Isolate the console. Inspect the seal.'
    start=text.index('Isolate')
    feature=procedure_features(QUESTION,text,start=start,end=start+len('Isolate the console'),anchors=('orion',))
    def accepted(score):
        return __import__('app.services.answer_reader',fromlist=['ReaderSelection']).ReaderSelection(AnswerSpan(start=0,end=4,text='text'),{'part_count':1,'covered_parts':[0],'parts':[{'index':0,'null_margin':score,'procedure_evidence':feature}]})
    assert feature['selected_sequence'] is False
    assert select_witness_cover([accepted(-1),accepted(-10)]).indices==(1,)

def test_raw_inside_unrelated_office_steps_cannot_promote_source():
    text='Orion valve inspection is booked on Tuesday. Office closing: First, lock the desk. Next, turn off the lights.'
    start=text.index('lock the desk')
    result=procedure_features(QUESTION,text,start=start,end=start+len('lock the desk'),anchors=('orion',))
    assert result['explicit_sequence'] is True and result['selected_sequence'] is False

def test_existing_bulleted_sequence_survives_canonical_normalization():
    text='Orion valve inspection:\n- Isolate the console.\n- Inspect the seal.\n- Photograph its edges.'
    canonical=normalize_content(text)
    start=canonical.index('Isolate')
    assert procedure_features(QUESTION,text)['explicit_sequence'] is True
    result=procedure_features(QUESTION,canonical,start=start,end=start+len('Isolate the console'),anchors=('orion',))
    assert result['selected_sequence'] is True,result
