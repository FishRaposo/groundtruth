# Procedure-window independent review (2026-10-24)

Two concrete failures were reproduced in independent fixtures. The first prevents intended numbered/bulleted structure preference after real ingestion; the second shows the new ranking prior can promote an unrelated sequence in a mixed-topic chunk. Neither is a model-quality measurement or a claim about unseen outputs.

## Findings

### 1. Line-based list detection is incompatible with canonical ingestion

`apps/api/app/services/reader_support.py:64` counts numbered/bulleted items using multiline line-start matches. `apps/api/app/services/document_intelligence.py:46-48` collapses all whitespace into spaces. Real upload therefore removes the line boundaries before `LocalReader._parts` computes procedure_features at `answer_reader.py:274-276`.

The independent real upload/query fixture supplies an accepted source `Orion valve inspection:\n1. Isolate the console.\n2. Inspect the seal.\n3. Photograph its edges.` and an accepted booking/return-instruction source. The original text reports explicit_sequence=True. The actual canonical context delivered to the reader reports explicit_sequence=False, distinct markers0/listed items0. Both accepted QA predictions use production passage_span and exact canonical offsets; the booking has the stronger margin. HTTP200/completed emits only the booking/return instruction, discarding the numbered procedure. This is the same intended repair behavior as the owned First/Next fixture, but through numbered source structure after the real normalizer.

Reproducer: `test_independent_procedure_window_valid.py::test_ingested_numbered_procedure_keeps_sequence_preference`; failing output `probes-3.log`. This is an implementation/normalization mismatch, not a request for new list formats or a reason to rewrite historical immutable normalized text/hashes.

### 2. Formatting from a different procedure overrides stronger relevant evidence

`procedure_features` at `reader_support.py:42-71` scans the entire chunk for sequence markers without binding that formatting to the requested procedure. `reader_witnesses.py:62-69` excludes all unmarked accepted candidates whenever any accepted candidate has explicit_sequence=True, before comparing margins.

Independent HTTP200/completed fixture:

- Actual requested procedure: `Orion valve inspection: Isolate the console. Inspect the seal. Photograph its edges. Sign the inspection card.` Accepted margin-10.
- Booking source: `Orion valve inspection is booked on Tuesday at 09:20. Return the card to drawer Q8 after the session. Office closing: First, lock the desk. Next, turn off the lights.` Accepted booking-return raw span, margin-1.

The unrelated Office closing sequence turns the booking's feature on, so the new prior selects that weaker candidate and omits the actual procedure. With no structure preference, the existing margin rule selects the actual source. This is a bounded selection regression using the existing First/Next syntax and the original booking-return failure class, not a proposed general entailment algorithm or arbitrary grammar expansion. All copied spans remain exact; exactness does not fix requested-procedure completeness. The prior may be described as a formatting heuristic, but these observed structural markers belong to another procedure.

Reproducer: `test_independent_procedure_window_valid.py::test_unrelated_sequence_for_other_subject_cannot_promote_booking`; `probes-3.log` contains the exact emitted booking+Office answer. Any repair should retain multiple-document contexts and explicit unmarked/unknown legacy fallback; no primary-document narrowing, model retries, source aliases, or claims of entailment are justified by this review.

## Other inspected behavior

The exact interval change passes independent to/en-dash/hyphen/weekday-from count rejection and When acceptance, elapsed-request rejection for a scheduled range, and whole-procedure-with-time-range acceptance. It applies only to exact selected temporal spans, preserving longer procedural passages. Existing nullable legacy feature behavior and unmarked fallback controls pass. Normalized imperative question handling is reused; no subject cropping was introduced by the narrow diff.

Current integrated reader_setup imports MINILM/ROBERTA and reexports get_reader_spec; legacy MODEL/REVISION/FILES remain MiniLM, default CLI/setup stays MiniLM, explicit RoBERTa uses its exact catalog revision/files. Mocked setup tests validate selected pinned file lists and hashes, legacy/default CLI, unknown model failure, download failure, and mocked local runtime identity/unverified-file rejection. No actual download/model import/inference was performed. No setup merge incompatibility found in this bounded review.

## Actual commands and results

Original interpreter `portfolio/groundtruth/.venv/Scripts/python.exe`; workdir isolated delivery-worktree/apps/api; explicit isolated PYTHONPATH, PYTHONDONTWRITEBYTECODE=1, legacy import defaults/ANSWER_SELECTION_MODE=lexical, blank provider key, HF/Transformers offline. Real-client fixture uses only deterministic/extractive modes and dedicated scratch SQLite. Reader predictions are mocked at the QA seam, with production LocalReader._parts/passage_span and real in-process API/ingestion/storage/presentation.

1. `python -m pytest <this-dir>/test_independent_procedure_window.py tests/test_reader_procedure_evidence.py tests/test_reader_witness_cover.py tests/test_reader_catalog.py tests/test_reader_model_selection.py tests/test_reader_preparation_boundaries.py -c pyproject.toml -q --basetemp=<this-dir>/probe-temp-1 -o cache_dir=<this-dir>/cache`
   Exit1, **1 failed,39 passed in3.61s** (`probes-1.log`). This first independent HTTP fixture incorrectly assumed ingestion preserved paragraph breaks: its own assertion failed inside the mocked reader and API correctly returned503. It is retained but NOT evidence for either app finding. The39 focused controls, including interval/setup/runtime mocks, passed.
2. Corrected fixture invocation used PowerShell `--basetemp=(Join-Path...)`, which passed an empty value: exit4 before tests (`probes-2.log`). No app result.
3. `python -m pytest <this-dir>/test_independent_procedure_window_valid.py tests/test_reader_procedure_evidence.py -c pyproject.toml -q --basetemp=<this-dir>/probe-temp-3 -o cache_dir=<this-dir>/cache`
   Exit1, **2 failed,12 passed in2.61s** (`probes-3.log`). Both reported findings fail at answer-content assertions after HTTP200/completed, not due fixture exceptions. Six independent interval controls and six owned sequence/interval/legacy controls pass.

`source-before.json` and `source-after.json` contain matching SHA256s for six inspected source files: answer_reader, reader_questions, reader_support, reader_witnesses, reader_setup, reader_catalog. Narrow source diff inspected against b1e8dac. Reviewer writes only scratch tests/logs/report; application, repository tests, evidence, original checkout, assets, services and corpus untouched.

Limits: no new model inference, quality grid, live process, blind data, latency/performance or release claim. Known v5 comparison failure status is unchanged. These independent fixtures expose source-format and selection behavior, not their prevalence on real model predictions. Bounded rejection/ranking heuristics do not establish general factual entailment.
