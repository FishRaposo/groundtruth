"""Real selected-default launch and all-method development observation, no overwrites."""
from pathlib import Path
import hashlib,json,os,subprocess,time
import httpx
R=Path('C:/Projects/operation-fan-the-hammer')
S=R/'.tmp/groundtruth-coverage-20261024'
W=S/'delivery-worktree'; V=S/'coverage-v3'
P=R/'portfolio/groundtruth/.venv/Scripts/python.exe'
D=V/'default-profile-v8'; D.mkdir(exist_ok=True)
assert not (D/'report.json').exists(), 'Never overwrite observations'
corpus=W/'apps/api/app/portfolio/assets/coverage-development-v3'
paths=sorted(set(list((W/'apps/api/app').rglob('*.py'))+list(corpus.glob('*.json'))+[W/'scripts/portfolio_local.py',W/'scripts/evaluate_portfolio_retrieval.py']))
def hashes():return {str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes(); (D/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy(); env['PYTHONPATH']=str(W/'apps/api')
for k in list(env):
 if k.startswith(('OPENAI_','ANTHROPIC_','AZURE_OPENAI_','GOOGLE_API','GEMINI_')):del env[k]
command=[str(P),str(W/'scripts/portfolio_local.py'),'serve','--data-dir',str(V/'calibration'),'--model-dir',str(R/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41'),'--reader-dir',str(S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'),'--port','8410','--frontend-origin','http://127.0.0.1:3506']
(D/'launch.json').write_text(json.dumps({'command':command,'reader_model_and_threshold_overrides':False},indent=2)+'\n')
with (D/'api.log').open('wb') as log:
 proc=subprocess.Popen(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 try:
  for _ in range(180):
   if proc.poll() is not None:raise RuntimeError('Default launcher exited; inspect log')
   try:
    if httpx.get('http://127.0.0.1:8410/api/health/live',timeout=1).status_code==200:break
   except httpx.HTTPError:pass
   time.sleep(.25)
  else:raise RuntimeError('Default launcher startup timeout')
  h=httpx.get('http://127.0.0.1:8410/api/health/ready',timeout=300); h.raise_for_status()
  health=h.json();assert health['status']=='ready',health
  (D/'readiness.json').write_text(json.dumps(health,indent=2)+'\n')
  print('Actual default launcher ready; evaluating all four methods.',flush=True)
  ev=[str(P),str(W/'scripts/evaluate_portfolio_retrieval.py'),'--seed-manifest',str(V/'calibration/seed-manifest.json'),'--corpus-dir',str(corpus),'--output',str(D/'report.json'),'--method','all','--execution-arm','candidate','--expected-reader-model-revision','adc3b06f79f797d1c575d5479d6f5efe54a9e3b4','--expected-reader-null-threshold','4','--require-answer-spans']
  with (D/'evaluation.log').open('wb') as f: result=subprocess.run(ev,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert (D/'report.json').exists(),f'Evaluation did not produce report: {result.returncode}'
  report=json.loads((D/'report.json').read_text())
  summary={k:v['summary'] for k,v in report['results'].items()}
  print(json.dumps({'evaluation_exit':result.returncode,'summary':summary}),flush=True)
  (D/'result.json').write_text(json.dumps({'evaluation_exit':result.returncode,'summary':summary,'scope':'Exposed development only; no blind acceptance'},indent=2)+'\n')
 finally:
  subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
  proc.wait(timeout=20)
after=hashes();(D/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
print('Default-profile observation complete, source unchanged.',flush=True)
