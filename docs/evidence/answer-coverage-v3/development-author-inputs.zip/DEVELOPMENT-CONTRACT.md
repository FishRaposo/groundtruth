# GroundTruth source and case authoring contract, schema 2

This is a schema-only product contract. It contains no development cases,
implementation, thresholds, evaluation results or model configuration. A development
author must use a clean context and must not inspect those materials. This packet authors DEVELOPMENT material only and may begin now. No later blind validation is authorized in this packet.

GroundTruth answers questions using current authorized document snapshots and
immutable citations. It should refuse absent facts, review unresolved current
conflicts, deny explicit inaccessible-document requests, and preserve access
boundaries against adversarial prompts. Source content is ordinary operational
prose. No case-specific hints, answer labels, expected spans, scores or question
lists may appear in source content or operational metadata.

The product supports answers drawing from multiple relevant documents. Include
genuine questions requiring evidence from two documents and label all required
current sources/facts. Do not reduce the product to a primary-document workflow.
Unrelated documents must not supply a requested entity's missing attribute;
relevant opposing current instructions still require review/refusal.

## Files

A corpus directory contains exactly `manifest.json`, `documents.json`,
`cases.json` and `profile.json`. Use UTF-8, LF, deterministic JSON, and SHA-256 of
actual file bytes in the manifest. Source content hashes are SHA-256 of each
exact UTF-8 `content` string. Do not normalize or reformat content after hashing.
The manifest itself is identified by SHA-256 of its final bytes.

Manifest shape (angle-bracket values are placeholders):

```json
{
  "schema_version": 2,
  "revision": "<unique frozen revision>",
  "score_contract": "coverage-v2",
  "corpus_role": "development",
  "created_date": "<YYYY-MM-DD>",
  "frozen_before_measurement": true,
  "authorship": "<accurate authorship>",
  "validity": "<synthetic source-grounded labels; review limits>",
  "rights": {"owner": "GroundTruth project", "license": "MIT", "third_party_content": false},
  "document_count": 0,
  "case_count": 80,
  "expected_counts": {"development": {"answerable": 48, "unanswerable": 16, "conflicting_stale": 8, "adversarial": 8}},
  "principals": {
    "operator-a": {"workspace_id": "ops-a", "role": "owner"},
    "viewer-a": {"workspace_id": "ops-a", "role": "viewer"},
    "custodian-b": {"workspace_id": "ops-b", "role": "owner"}
  },
  "files": {"documents.json": "<sha256>", "cases.json": "<sha256>", "profile.json": "<sha256>"}
}
```

`document_count` is the actual number of logical documents. Sources must have at
least 20 new source families. A family may include multiple documents and
versions; it must not cross splits. All development documents/cases use `held_out`.

Each item of `documents.json` has this shape:

```json
{
  "id": "<unique logical ID>",
  "title": "<ordinary source title>",
  "family": "<independent source-family ID>",
  "split": "development",
  "visibility": "public",
  "workspace_id": "ops-a",
  "owner": "operator-a",
  "current_version_number": 1,
  "versions": [{"version_number": 1, "content": "<ordinary source prose>", "content_hash": "<sha256 of content UTF-8>"}],
  "metadata": {}
}
```

Versions start at 1, are contiguous, and preserve complete snapshots; the highest
version is current. Permission visibility is `public`, `organization` or
`private`. To test a different workspace's private document, use owner
`custodian-b`, workspace `ops-b`, visibility `private`, and query principal
`operator-a`. Source owner aliases must exist in manifest principals. Public
ordinary sources can use owner `operator-a`/workspace `ops-a` and be queried as
`operator-a`. The seed utility uploads each source/version through normal API
routes; it grants document access according to these ordinary fields.

An unresolved conflict may have two current authorized documents with ordinary
opposing instructions, no precedence, and matching
`metadata: {"conflict_group": "<unique shared group>"}`. This is curated source
relationship metadata. Do not encode individual case labels or answers there.
No custom per-case runtime metadata is supported.

Each item of `cases.json` has this shape:

```json
{
  "id": "<unique case ID>",
  "score_contract": "coverage-v2",
  "question": "<realistic user request>",
  "category": "answerable",
  "split": "development",
  "family": "<source family ID>",
  "principal": "operator-a",
  "document_ids": null,
  "expected_behavior": "answer",
  "expected_sources": [{
    "document_id": "<logical ID>",
    "version_number": 1,
    "content_hash": "<same source snapshot hash>",
    "quoted_text": "<exact contiguous current-source support passage>",
    "acceptable_answer_spans": ["<exact answer span within quoted_text>"]
  }],
  "required_facts": [["<literal fact>", "<another acceptable literal variant if present in source>"]],
  "ordered_steps": [],
  "forbidden_sources": [{"document_id": "<logical ID>", "version_number": 1}],
  "label_author": "<accurate author>",
  "label_status": "<review status>",
  "label_rationale": "<why source answers or does not answer this specific request>"
}
```

The `forbidden_sources` example is structural; do not forbid an expected source.
Expected sources must identify the current version. Use at most one expected
source record per logical-document/version identity and make its support quote
wide enough for the facts required from that version. Every acceptable span and
required literal fact or step must occur in the exact support quote. Required
fact groups are ANDed; alternatives within a group are ORed. Ordered-step groups
have the same alternatives semantics and must appear in the authored sequence.
Preserve negations, units, numbers, owner identities and entity attribution.
Simple topic mentions are insufficient labels. A baseline answer containing a
whole source chunk can satisfy the same facts as a shorter supported answer.

Ordinary positive questions search all authorized sources (`document_ids:null`)
so the requested source is not supplied as a retrieval shortcut. Only explicit
scoped requests should set a document filter. Negative categories are
`unanswerable`, `conflicting_stale`, `adversarial`; their expected behavior is
`refuse`, `review`, or `deny`, as appropriate. They have `expected_sources:[]`,
`required_facts:[]`, `ordered_steps:[]`. Explicit inaccessible document filters
should expect `deny`; unrestricted inaccessible-fact requests should expect
`refuse`. A missing fact must not silently borrow a number or owner from a nearby
entity. Mark inaccessible/retired sources forbidden where appropriate.

Provide paraphrases and natural grammar variation, multi-step procedures,
owners, durations, units, wrong-entity requests, absent attributes, nearby wrong
facts and negations. Keep the cases independently authored and source-grounded;
do not design source prose around a model or observed retrieval failure.

`profile.json` can contain `schema_version:2`, a unique revision, `top_k:5`, and
`methods:["keyword","vector","hybrid","reranked"]`. Do not invent selection
thresholds; the parent supplies the already frozen operational selection.

Before release, re-read labels against sources independently of the answerer.
Keep a review record with reviewer identity/status, source hashes, count/family
checks and any corrections. Freeze all source/case bytes before any baseline or
candidate measurement. Do not inspect first-measurement failures until both
complete first reports have been preserved.


MANDATORY INPUT FORMAT: normalize ALL source content, quote/span/fact/step strings
before hashing: all whitespace runs become one ASCII space, then strip. Source
hashes use normalized exact UTF-8 bytes; JSON files use UTF-8/LF. Every positive
must have nonempty required_facts AND expected_sources, including ordered cases.
Profiles contain no model or threshold settings. Author80 DEVELOPMENT cases48/16/8/8,
at least18 genuinely fresh families distinct from the supplied topic inventory.
Within48 positives include16 simple factual (at least8 ordered-procedure requests),
16 single-document requests asking multiple facts/constraints,16 requests genuinely
needing two documents. This is product coverage, not model-specific optimization.
Sources ordinary operational prose, no question/scorer hints. Multiple documents
remain supported. Freeze files after your own source-label reread. Do not access
implementation, runtime, model/configuration, previous cases/reports, other agents
or inventory. Use dev-v3-001..dev-v3-080 IDs. Labels are synthetic agent-authored,
without human validation. The profile operational settings will be supplied by the
parent after development; do not select any yourself. No application execution.
