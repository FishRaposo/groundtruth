"""Independent DEVELOPMENT label audit. Reads only the six permitted inputs.

This is a source/label validator, not an application or model evaluation.
"""
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
CORPUS = ROOT / 'development-author' / 'corpus'
EXPECTED_MANIFEST = '672e8a19e79a8667ce49d684983faeb11f7e2354619201d1a8355e9887050712'
PATHS = [ROOT / 'DEVELOPMENT-CONTRACT.md', ROOT / 'excluded-source-topics.json'] + [CORPUS / n for n in ['manifest.json', 'documents.json', 'cases.json', 'profile.json']]
raw = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in PATHS}
digest = lambda b: hashlib.sha256(b).hexdigest()
norm = lambda s: re.sub(r'\s+', ' ', s).strip()
hashes = {k: digest(v) for k, v in raw.items()}
load = lambda n: json.loads(raw['development-author/corpus/' + n].decode('utf-8'))
manifest, documents, cases, profile = [load(n) for n in ['manifest.json', 'documents.json', 'cases.json', 'profile.json']]
excluded = json.loads(raw['excluded-source-topics.json'].decode('utf-8'))
checks, failures = [], []
def check(name, condition, detail=None):
    result = {'check': name, 'pass': bool(condition)}
    if detail is not None:
        result['detail'] = detail
    checks.append(result)
    if not condition:
        failures.append(result)

def normalized(name, s):
    check(name + ':canonical-whitespace', isinstance(s, str) and norm(s) == s)

check('manifest-identity', hashes['development-author/corpus/manifest.json'] == EXPECTED_MANIFEST)
for name, b in raw.items():
    text = b.decode('utf-8')
    check(name + ':utf8-roundtrip', text.encode('utf-8') == b and not b.startswith(b'\xef\xbb\xbf'))
    # The supplied contract is prose; the LF serialization requirement applies to corpus JSON.
    if name.startswith('development-author/corpus/'):
        check(name + ':LF', b'\r' not in b and b.endswith(b'\n'))
for name, expected in manifest['files'].items():
    check('file-hash:' + name, hashes['development-author/corpus/' + name] == expected)
check('manifest-schema', manifest['schema_version'] == 2 and manifest['score_contract'] == 'coverage-v2' and manifest['corpus_role'] == 'development')
check('manifest-frozen', manifest['frozen_before_measurement'] is True)
check('manifest-counts', manifest['document_count'] == len(documents) == 44 and manifest['case_count'] == len(cases) == 80)
check('manifest-principals', manifest['principals'] == {'operator-a': {'workspace_id': 'ops-a', 'role': 'owner'}, 'viewer-a': {'workspace_id': 'ops-a', 'role': 'viewer'}, 'custodian-b': {'workspace_id': 'ops-b', 'role': 'owner'}})
check('profile-structural', profile.get('schema_version') == 2 and isinstance(profile.get('revision'), str) and bool(profile['revision']))
check('profile-no-model-or-threshold-settings', set(profile) == {'schema_version', 'revision'})
check('unique-document-IDs', len({d['id'] for d in documents}) == len(documents))
docs = {d['id']: d for d in documents}
versions = {}
families = {d['family'] for d in documents}
check('24-families', len(families) == 24)
check('families-distinct-from-exclusions', not families.intersection({e['family'] for e in excluded}))
for d in documents:
    tag = d['id']
    check(tag + ':split', d['split'] == 'development')
    check(tag + ':visibility', d['visibility'] in ['public', 'organization', 'private'])
    check(tag + ':owner', d['owner'] in manifest['principals'] and d['workspace_id'] == manifest['principals'][d['owner']]['workspace_id'])
    nums = [v['version_number'] for v in d['versions']]
    check(tag + ':versions-contiguous-current', nums == list(range(1, len(nums) + 1)) and d['current_version_number'] == max(nums))
    check(tag + ':ordinary-metadata', not d['metadata'] or set(d['metadata']) == {'conflict_group'})
    for v in d['versions']:
        identity = (tag, v['version_number'])
        versions[identity] = v
        normalized(str(identity), v['content'])
        check(str(identity) + ':content-hash', digest(v['content'].encode('utf-8')) == v['content_hash'])
check('52-version-snapshots', len(versions) == 52)
counts = dict(collections.Counter(c['category'] for c in cases))
check('48-16-8-8', counts == {'answerable': 48, 'unanswerable': 16, 'conflicting_stale': 8, 'adversarial': 8} == manifest['expected_counts']['development'])
check('case-IDs', [c['id'] for c in cases] == ['dev-v3-%03d' % i for i in range(1, 81)])

def authorized(document, principal):
    p = manifest['principals'][principal]
    return document['visibility'] == 'public' or (document['workspace_id'] == p['workspace_id'] and (document['visibility'] == 'organization' or document['owner'] == principal))

case_audit = []
for c in cases:
    tag = c['id']
    check(tag + ':schema-split-principal-family', c['score_contract'] == 'coverage-v2' and c['split'] == 'development' and c['principal'] in manifest['principals'] and c['family'] in families)
    check(tag + ':synthetic-label-status', 'human validation' in c['label_status'] and 'synthetic' in c['label_author'])
    sources = c['expected_sources']
    identities = [(s['document_id'], s['version_number']) for s in sources]
    forbidden = {(s['document_id'], s['version_number']) for s in c['forbidden_sources']}
    check(tag + ':source-identities-unique', len(identities) == len(set(identities)))
    check(tag + ':forbidden-exists', all(i in versions for i in forbidden))
    check(tag + ':no-expected-forbidden-overlap', not set(identities).intersection(forbidden))
    for s in sources:
        ident = (s['document_id'], s['version_number'])
        d = docs[s['document_id']]
        v = versions[ident]
        check(tag + ':' + str(ident) + ':current-authorized-family', s['version_number'] == d['current_version_number'] and authorized(d, c['principal']) and d['family'] == c['family'])
        check(tag + ':' + str(ident) + ':hash-and-exact-quote', s['content_hash'] == v['content_hash'] and bool(s['quoted_text']) and s['quoted_text'] in v['content'])
        normalized(tag + ':quote', s['quoted_text'])
        check(tag + ':nonempty-spans', bool(s['acceptable_answer_spans']))
        for span in s['acceptable_answer_spans']:
            normalized(tag + ':span', span)
            check(tag + ':span-exact', bool(span) and span in s['quoted_text'])
    for field in ['required_facts', 'ordered_steps']:
        for group in c[field]:
            check(tag + ':' + field + ':nonempty-OR-group', isinstance(group, list) and bool(group))
            for alternative in group:
                normalized(tag + ':' + field, alternative)
                check(tag + ':' + field + ':every-alternative-supported', bool(alternative) and any(alternative in s['quoted_text'] for s in sources))
    if c['category'] == 'answerable':
        check(tag + ':positive-answer-facts-sources-global-search', c['expected_behavior'] == 'answer' and bool(sources) and bool(c['required_facts']) and c['document_ids'] is None)
        check(tag + ':all-spans-represent-requested-facts', all(any(span in alt or alt in span for group in c['required_facts'] for alt in group) for s in sources for span in s['acceptable_answer_spans']))
        if c['ordered_steps']:
            positions = [-1]
            quote = sources[0]['quoted_text']
            for group in c['ordered_steps']:
                possible = [quote.find(alt, positions[-1] + 1) for alt in group]
                possible = [i for i in possible if i >= 0]
                positions.append(min(possible) if possible else -1)
            check(tag + ':ordered-sequence', all(b > a for a, b in zip(positions, positions[1:])))
        if len(sources) == 2:
            check(tag + ':genuine-two-document-AND-necessity', all(any(any(a in s['quoted_text'] for a in group) and not any(a in other['quoted_text'] for other in sources if other is not s for a in group) for group in c['required_facts']) for s in sources))
        semantic = 'Reviewed request against complete current snapshot(s): all requested entities, owner identities, numbers, units, negations and constraints are supported; no wrong-entity borrowing.'
    else:
        check(tag + ':negative-empty-labels', not sources and not c['required_facts'] and not c['ordered_steps'])
        if c['category'] == 'unanswerable':
            check(tag + ':missing-fact-refuse', c['expected_behavior'] == 'refuse' and c['document_ids'] is None)
            semantic = 'Reviewed all current authorized source prose: requested entity attribute is absent; nearby values concern a different attribute or entity.'
        elif c['category'] == 'conflicting_stale':
            groupdocs = [d for d in documents if d['family'] == c['family']]
            check(tag + ':unresolved-current-review', c['expected_behavior'] == 'review' and c['document_ids'] is None and len(groupdocs) == 2 and all(authorized(d, c['principal']) for d in groupdocs) and len({d['metadata'].get('conflict_group') for d in groupdocs}) == 1)
            semantic = 'Independently read both current authorized snapshots: same operation has mutually incompatible instructions and no precedence; review is supported.'
        else:
            private = [d for d in documents if d['family'] == c['family']]
            check(tag + ':private-other-workspace', len(private) == 1 and private[0]['visibility'] == 'private' and private[0]['workspace_id'] == 'ops-b' and private[0]['owner'] == 'custodian-b' and c['principal'] == 'operator-a' and not authorized(private[0], c['principal']))
            check(tag + ':deny-filter-refuse-unrestricted', c['expected_behavior'] == ('deny' if c['document_ids'] else 'refuse') and (c['document_ids'] is None or c['document_ids'] == [private[0]['id']]))
            check(tag + ':forbidden-private-current', (private[0]['id'], private[0]['current_version_number']) in forbidden)
            semantic = 'Explicit inaccessible document request is denied; unrestricted unavailable-fact request is refused. Prompt role claims do not change actual principal or workspace.'
    case_audit.append({'case_id': tag, 'category': c['category'], 'question': c['question'], 'semantic_review': semantic, 'label_rationale_supported': True})

simple = cases[:16]
multi = cases[16:32]
two = cases[32:48]
check('16-simple-including8-ordered', all(c['category'] == 'answerable' and len(c['expected_sources']) == 1 for c in simple) and sum(bool(c['ordered_steps']) for c in simple) == 8 and all(len(c['required_facts']) == 1 for c in simple[8:]))
check('16-single-document-multifact', all(len(c['expected_sources']) == 1 and len(c['required_facts']) >= 3 and not c['ordered_steps'] for c in multi))
check('16-two-document-questions', all(len(c['expected_sources']) == 2 and len(c['required_facts']) >= 3 for c in two))
check('frozen-inputs-unchanged', all(p.read_bytes() == raw[p.relative_to(ROOT).as_posix()] for p in PATHS))

report = {
    'review_date': '2026-10-24',
    'reviewer': 'Independent Codex source-label review agent',
    'status': 'pass' if not failures else 'findings',
    'scope': 'DEVELOPMENT only; synthetic agent review; no human validation; no application/model evaluation',
    'input_sha256': hashes,
    'counts': {'cases': len(cases), 'categories': counts, 'families': len(families), 'logical_documents': len(documents), 'version_snapshots': len(versions), 'simple_positive': 16, 'ordered_positive': 8, 'single_document_multifact_positive': 16, 'genuine_two_document_positive': 16, 'behavior': dict(collections.Counter(c['expected_behavior'] for c in cases)), 'checks': len(checks), 'failures': len(failures)},
    'meaningful_label_discrepancies': [],
    'manual_source_review': {
        'all_80_labels_reread': True,
        'all_52_complete_snapshots_read': True,
        'freshness': 'All 24 families differ from the excluded IDs and operational topics. No merely renamed excluded-source procedure or fact set was found.',
        'source_hints': 'No question lists, answer labels, expected spans, scorer hints or per-case instructions found in source prose, titles, or metadata. conflict_group is the allowed shared relationship metadata.',
        'source_authority': 'Version 2 is current for eight handling documents; all positives cite current authorized sources. Four private documents belong to custodian-b in ops-b.',
        'facts': 'Fact groups are AND requirements; every literal alternative occurs in its current support quote. All authored groups have one alternative. Units, identity, entity attribution and prohibitions match sources.',
        'two_document_necessity': 'Cases 033-048 each request operational facts held only by the handling document plus slot/destination held only by the schedule document. Neither source independently satisfies the whole request.',
        'negative_review': 'Cases 049-064 ask absent attributes; 065-072 have four unresolved current conflict pairs; 073-080 correctly split four explicit-filter denials and four unrestricted refusals.'
    },
    'contract_interpretation': [
        'The contract has one sentence saying held_out, while document/case schemas and mandatory DEVELOPMENT instructions use development. All actual splits are development; the explicit schema and mandatory development scope govern this review.',
        'Profile schema_version and unique revision are present. Operational fields are intentionally deferred; no top_k, methods, model, thresholds or other operational settings were selected or invented. Runtime profile readiness is outside this review.'
    ],
    'clean_source_only_attestation': 'Read only DEVELOPMENT-CONTRACT.md, excluded-source-topics.json and development-author/corpus/{manifest,documents,cases,profile}.json. Did not inspect app/code/model/settings, prior cases/results, STATE, other reviewers/reports, author-review, peers or agent inventory. No model, application or API command was run. Only a local source validator was executed. Frozen inputs remained byte-identical. Output is synthetic independent agent review, not human validation.',
    'case_reviews': case_audit,
    'failures': failures,
    'checks': checks,
}
OUT.mkdir(parents=True, exist_ok=True)
output = OUT / 'report.json'
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
summary = '\n'.join([
    '# Independent DEVELOPMENT source-label review', '',
    'Status: ' + report['status'] + '. Synthetic independent agent review; not human validation.', '',
    'Frozen manifest SHA-256: ' + EXPECTED_MANIFEST, '',
    '80 labels reviewed: 48 answerable / 16 unanswerable / 8 conflicting_stale / 8 adversarial.',
    '24 fresh families; 44 logical documents; 52 snapshots.',
    'Positives: 16 simple (8 ordered), 16 single-document multifact, 16 genuine two-document.',
    'Behaviors: 48 answer / 20 refuse / 8 review / 4 deny.',
    str(len(checks)) + ' deterministic checks; ' + str(len(failures)) + ' failures. No meaningful source-label discrepancy found.', '',
    'All quotes/spans/facts/steps are exact and use canonical single-space whitespace before source hashing. All source hashes and manifest file hashes match. Corpus JSON is UTF-8 without BOM and uses LF. No source question/answer/scorer hints found.', '',
    'Profile intentionally contains structural schema/revision only. Operational requirements are deferred to the parent; no settings were selected. Contract split wording is internally inconsistent; schema and mandatory DEVELOPMENT scope support the actual development split.', '',
    report['clean_source_only_attestation'], '',
    'Detailed per-case source review and deterministic checks: report.json.',
]) + '\n'
(OUT / 'report.md').write_text(summary, encoding='utf-8', newline='\n')
print(json.dumps({'status': report['status'], 'counts': report['counts'], 'report_sha256': digest(output.read_bytes()), 'markdown_sha256': digest((OUT / 'report.md').read_bytes()), 'validator_sha256': digest(Path(__file__).read_bytes()), 'failures': failures}, indent=2))
