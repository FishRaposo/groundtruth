# Independent revision-two label recheck

**Status: PASS. No residual material discrepancy found.** All eight source-backed label corrections are accepted. The corpus contains 200 cases with the required distribution, 37 genuinely necessary multi-document positives and 20 complete ordered-procedure positives. All 80 negatives still require refusal/review.

## Correction verification

The five procedure corrections retain every original ordered action and now additionally require the current parameter sentence that resolves the action's explicit textual reference. Each parameter is present verbatim in the authorized current source, the expected quotation, an acceptable answer span and a separate required fact. The complete contiguous four-action span remains acceptable.

| Corrected label | Parameter now required |
| --- | --- |
| f03-p3 | 11-minute Mica umbrella dwell |
| f11-p3 | 5-second Mallow pre-pass hold |
| f14-p3 | 6 separate Pith switch presses |
| f16-p3 | 3-second Oxbow side-rest condition |
| f19-p3 | 17-minute Cairn reading interval |

The three role-and-session corrections, **f04-p4, f13-p4 and f20-p4**, now require their sufficient arrangements sentence alone. That sentence names the role and states the complete requested schedule. The unnecessary guide source and its redundant required fact were removed; the authorized guide was not forbidden. These requests are correctly counted as single-document.

Exactly these eight labels changed, confined to `expected_sources`, `required_facts` and `label_rationale`. All other 192 case records are identical to the originals. All 200 case IDs, question content UTF-8 bytes and raw JSON question string lexemes are unchanged. The entire `documents.json` file is byte-identical to the original, preserving all 105 source records and 125 current/historical snapshots.

## Full audit results

| Check | Result |
| --- | --- |
| Category distribution | 120 answerable / 40 unanswerable / 20 conflicting_stale / 20 adversarial |
| Source families | 20 held_out families, semantically disjoint from the assigned exclusion packet |
| Sources | 105 logical documents, 125 immutable snapshots; contiguous version numbers and correct current pointers |
| Permissions | 25 public, 56 organization and 24 private sources; workspace isolation and owner-private access correctly enforced in labels |
| Positive grounding | All expected sources current and authorized; every source hash, quotation, answer span, required fact and ordered step verified |
| Composition | 37 necessary multi-document positives, 83 single-document positives, 20 complete ordered procedures |
| Negatives | All 80 refusal/review semantics accepted; no invalid partial-positive negative found |
| Curated conflicts | 10 authorized current pairs with matching conflict_group metadata and genuinely incompatible marker instructions |
| Stale cases | 10 unsupported current marking requests; five additional adversarial stale-promotion requests remain appropriate refusals |
| Scope | Five explicitly declared document filters; remaining cases use null |
| Schema/freeze | Manifest, profile, exact file sets, rights/provenance disclosures and all declared raw-file hashes verified |

An independently written standard-library checker performed **6,612 assertion evaluations in one execution; all passed**. `checks.json` records each assertion. `report.json` contains an empty discrepancies list, complete file/source hashes, per-case semantic notes, correction evidence and preservation inventories. No author or prior review script was imported or executed. The initial inventory attempt looked for an optional `AUTHOR_FREEZE.json` that revision 2 does not contain; the contract requires `FREEZE_SHA256.json`, which exists and verifies, so this is not a corpus defect.

## Preservation and scope

All files in the original author directory, original failed-review directory and corrected author directory remained byte-identical throughout this recheck, including both original and revised `FREEZE_SHA256.json` files. Prior failed-review files were hashed only as opaque bytes to establish preservation; their scripts and findings were not inspected as new inputs. This recheck writes only to `blind-v5-label-review-v2`.

| Revision-two file | SHA256 |
| --- | --- |
| documents.json | 614556917c30753edceb46891cdcf18d2335bf34d381b59a07b0f7809bea878e |
| cases.json | 5dd05b42a58b8d7111357150b25a0216c26d7a9f7c0714c5963f61b65dd2fc60 |
| profile.json | 1cc5fc233da2faa42a816e80632922b9e70f78239362be9fa86f0c619349e25c |
| manifest.json | 301e64f002387cf69eb47e213782ab93ddbb58e7ca631c06739e7c1435339301 |

The assigned product/exclusion packet and authored corpus were the substantive inputs. No implementation, application, API, model, evaluation, network, operational configuration, repository memory/onboarding, agent inventory or other chat was accessed. This is a source-bound independent agent review of synthetic authored expectations, **not human validation, empirical model-quality evidence or general-quality certification**.
