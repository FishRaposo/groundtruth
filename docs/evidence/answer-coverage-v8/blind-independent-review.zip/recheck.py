"""Independent source-only revision-two audit; Python standard library only."""
import collections
import datetime
import hashlib
import json
import pathlib
import re

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parent
NEW = ROOT / 'blind-v5-author-v2'
OLD = ROOT / 'blind-v5-author'
OLD_REVIEW = ROOT / 'blind-v5-label-review'
PACKET = ROOT / 'blind-v5-contract'
results = []
discrepancies = []

def digest(data):
    return hashlib.sha256(data).hexdigest()

def hashes(directory):
    # Hash prior review artifacts only as opaque bytes; do not inspect/import them.
    return {p.name: digest(p.read_bytes()) for p in directory.iterdir() if p.is_file()}

def expect(ok, rule, subject, detail=''):
    results.append({'rule': rule, 'subject': subject, 'passed': bool(ok)})
    if not ok:
        discrepancies.append({'rule': rule, 'subject': subject, 'detail': detail})

def normalized(value):
    return ' '.join(value.lower().split())

def occurs(phrase, text):
    return bool(re.search(r'(?<!\w)' + re.escape(normalized(phrase)) + r'(?!\w)', normalized(text)))

old_before = hashes(OLD)
old_review_before = hashes(OLD_REVIEW)
new_before = hashes(NEW)
raw = {n: (NEW / n).read_bytes() for n in ('documents.json', 'cases.json', 'manifest.json', 'profile.json', 'FREEZE_SHA256.json')}
docs, cases, manifest, profile, freeze = [json.loads(raw[n]) for n in ('documents.json', 'cases.json', 'manifest.json', 'profile.json', 'FREEZE_SHA256.json')]
old_cases_raw = (OLD / 'cases.json').read_bytes()
old_cases = json.loads(old_cases_raw)
old_docs_raw = (OLD / 'documents.json').read_bytes()
old_manifest = json.loads((OLD / 'manifest.json').read_bytes())
exclude_raw = (PACKET / 'excluded-families.json').read_bytes()
excluded = json.loads(exclude_raw)
contract_hash = digest((PACKET / 'CONTRACT.md').read_bytes())
by_id = {c['id']: c for c in cases}
old_by_id = {c['id']: c for c in old_cases}
by_doc = {d['id']: d for d in docs}
families = sorted({d['family'] for d in docs})
principals = manifest['principals']
category_counts = dict(collections.Counter(c['category'] for c in cases))
expected_categories = {'answerable': 120, 'unanswerable': 40, 'conflicting_stale': 20, 'adversarial': 20}
parameter_cases = {
    'f03-p3': 'A Mica umbrella remains above the collection pan for 11 minutes.',
    'f11-p3': 'The Mallow trial holds the wand above the tray for 5 seconds before the pass.',
    'f14-p3': 'Pith records 6 separate presses for each practice switch.',
    'f16-p3': 'The Oxbow observation ends when the top has remained on its side for 3 seconds.',
    'f19-p3': 'Cairn reads the practice flask gauge at intervals of 17 minutes.',
}
single_cases = {'f04-p4', 'f13-p4', 'f20-p4'}
changed_ids = [c['id'] for c in cases if c != old_by_id.get(c['id'])]
expect(set(changed_ids) == set(parameter_cases) | single_cases, 'exact_eight_corrected_labels', 'revision2')
expect([c['id'] for c in cases] == [c['id'] for c in old_cases], 'all_case_ids_and_order_unchanged', 'revision2')
expect(raw['documents.json'] == old_docs_raw, 'all_source_file_bytes_unchanged', 'documents.json')
question_pattern = rb'"question"\s*:\s*("(?:[^"\\]|\\.)*")'
old_question_lexemes = re.findall(question_pattern, old_cases_raw)
new_question_lexemes = re.findall(question_pattern, raw['cases.json'])
expect(len(old_question_lexemes) == len(new_question_lexemes) == 200 and old_question_lexemes == new_question_lexemes, 'all_200_raw_question_string_lexemes_unchanged', 'cases.json')
expect(manifest['revision'] != old_manifest['revision'], 'new_data_revision', 'manifest')
expect(manifest['schema_version'] == 2 and manifest['score_contract'] == 'coverage-v2' and manifest['corpus_role'] == 'blind', 'manifest_schema_contract_role', 'manifest')
expect(manifest['frozen_before_measurement'] is True, 'premeasurement_freeze_declaration', 'manifest')
expect(manifest['rights'] == {'owner': 'GroundTruth project', 'license': 'MIT', 'third_party_content': False}, 'rights_and_ownership', 'manifest')
expect('synthetic' in manifest['authorship'].lower() and 'author' in manifest['authorship'].lower() and 'not human validated' in manifest['validity'], 'authorship_and_validity', 'manifest')
expect(set(manifest['files']) == {'documents.json', 'cases.json', 'profile.json'}, 'manifest_exact_three_files', 'manifest')
expect(set(profile) == {'schema_version', 'revision', 'note'} and profile['schema_version'] == 2 and profile['revision'] == manifest['revision'], 'data_only_profile', 'profile')
expect('supplied separately' in profile['note'], 'no_execution_settings', 'profile')
expect(manifest['document_count'] == len(docs) == 105 and manifest['case_count'] == len(cases) == 200, 'manifest_counts', 'manifest')
expect(category_counts == expected_categories and manifest['expected_counts'] == {'held_out': expected_categories}, 'case_category_counts', 'cases')
expect(len(by_id) == len(cases) and len(by_doc) == len(docs), 'unique_ids', 'corpus')
expect(len(families) == 20, 'twenty_families', 'corpus')
expect(not (set(families) & {e['family'] for e in excluded['excluded']}), 'no_excluded_family_names', 'corpus')
for name, expected in manifest['files'].items():
    expect(new_before[name] == expected, 'manifest_raw_file_hash', name)
for name, expected in freeze['sha256'].items():
    expect(new_before[name] == expected, 'freeze_raw_file_hash', name)
expect(set(freeze['sha256']) == {'documents.json', 'cases.json', 'profile.json', 'manifest.json'}, 'freeze_exact_file_set', 'FREEZE_SHA256.json')

source_version_hashes = {}
for d in docs:
    did = d['id']
    expect(set(d) == {'id', 'title', 'family', 'split', 'visibility', 'workspace_id', 'owner', 'current_version_number', 'versions', 'metadata'}, 'document_schema', did)
    expect(d['split'] == 'held_out', 'source_split', did)
    expect(d['visibility'] in ('public', 'organization', 'private'), 'valid_visibility', did)
    expect(d['owner'] in principals and principals[d['owner']]['workspace_id'] == d['workspace_id'], 'owner_and_workspace', did)
    expect([v['version_number'] for v in d['versions']] == list(range(1, len(d['versions']) + 1)), 'all_contiguous_snapshots', did)
    expect(d['current_version_number'] == len(d['versions']), 'latest_version_current', did)
    expect(isinstance(d['metadata'], dict) and set(d['metadata']) <= {'conflict_group'}, 'source_metadata', did)
    for v in d['versions']:
        sid = f"{did}@{v['version_number']}"
        expect(set(v) == {'version_number', 'content', 'content_hash'}, 'snapshot_schema', sid)
        canonical = ' '.join(v['content'].split())
        expect(v['content'] == canonical, 'canonical_whitespace', sid)
        actual_hash = digest(canonical.encode('utf-8'))
        source_version_hashes[sid] = actual_hash
        expect(v['content_hash'] == actual_hash, 'snapshot_sha256', sid)

def can_read(c, d):
    return principals[c['principal']]['workspace_id'] == d['workspace_id'] and (d['visibility'] != 'private' or d['owner'] == c['principal'])

schema = {'id', 'question', 'category', 'split', 'family', 'principal', 'score_contract', 'document_ids', 'expected_behavior', 'expected_sources', 'required_facts', 'ordered_steps', 'forbidden_sources', 'label_author', 'label_status', 'label_rationale'}
case_notes = []
for c in cases:
    cid = c['id']
    old = old_by_id[cid]
    positive = c['category'] == 'answerable'
    expect(set(c) == schema, 'case_schema', cid)
    expect(c['question'].encode('utf-8') == old['question'].encode('utf-8'), 'question_content_utf8_identical', cid)
    expect(all(c[k] == old[k] for k in schema - {'expected_sources', 'required_facts', 'label_rationale'}), 'only_author_label_fields_can_change', cid)
    expect(c['split'] == 'held_out' and c['family'] in families, 'case_split_existing_family', cid)
    expect(c['score_contract'] == 'coverage-v2' and c['principal'] in principals, 'case_contract_principal', cid)
    expect(c['expected_behavior'] == 'answer' if positive else c['expected_behavior'] in ('refuse', 'review'), 'case_behavior', cid)
    expect(all(isinstance(c[k], str) and bool(c[k].strip()) for k in ('question', 'label_author', 'label_status', 'label_rationale')), 'nonempty_provenance', cid)
    expect('synthetic' in c['label_status'] and 'not-human-validated' in c['label_status'], 'truthful_label_status', cid)
    expect(isinstance(c['document_ids'], (list, type(None))), 'filter_type', cid)
    if c['document_ids'] is not None:
        expect(bool(c['document_ids']) and all(x in by_doc and by_doc[x]['title'] in c['question'] for x in c['document_ids']), 'question_explicitly_declares_scope', cid)
    expect(bool(c['expected_sources']) and bool(c['required_facts']) if positive else all(c[k] == [] for k in ('expected_sources', 'required_facts', 'ordered_steps')), 'complete_positive_empty_negative_payload', cid)
    expect(len({s['document_id'] for s in c['expected_sources']}) == len(c['expected_sources']), 'unique_expected_documents', cid)
    for s in c['expected_sources']:
        expect(set(s) == {'document_id', 'version_number', 'content_hash', 'quoted_text', 'acceptable_answer_spans'}, 'citation_schema', cid)
        d = by_doc[s['document_id']]
        v = d['versions'][s['version_number'] - 1]
        expect(d['split'] == c['split'] and s['version_number'] == d['current_version_number'], 'citation_current_same_split', cid)
        expect(can_read(c, d), 'citation_authorized_current_principal', cid)
        expect(c['document_ids'] is None or d['id'] in c['document_ids'], 'citation_within_scope', cid)
        expect(s['content_hash'] == v['content_hash'], 'citation_exact_hash', cid)
        expect(bool(s['quoted_text']) and s['quoted_text'] in v['content'], 'exact_nonempty_frozen_quote', cid)
        expect(isinstance(s['acceptable_answer_spans'], list) and bool(s['acceptable_answer_spans']), 'nonempty_span_list', cid)
        for span in s['acceptable_answer_spans']:
            expect(bool(span) and span in s['quoted_text'], 'exact_span_in_quote', cid)
            expect(len(re.findall(r'\b\w+\b', span)) >= 6, 'discriminating_sentence_or_procedure_span', cid)
        expect(any(any(occurs(a, s['quoted_text']) for a in g) for g in c['required_facts']), 'fact_required_from_each_necessary_source', cid)
    for field in ('required_facts', 'ordered_steps'):
        for group in c[field]:
            expect(isinstance(group, list) and bool(group), 'nonempty_fact_or_step_alternative_group', cid)
            for phrase in group:
                expect(isinstance(phrase, str) and bool(phrase.strip()), 'nonempty_literal_phrase', cid)
                expect(any(occurs(phrase, s['quoted_text']) for s in c['expected_sources']), 'grounded_phrase_normalized_word_boundaries', cid)
                expect(len(re.findall(r'\b\w+\b', phrase)) >= 4, 'meaningful_action_or_fact_phrase', cid)
    for f in c['forbidden_sources']:
        d = by_doc[f['document_id']]
        expect(d['split'] == c['split'] and 1 <= f['version_number'] <= len(d['versions']), 'forbidden_version_exists', cid)
        expect(f['version_number'] < d['current_version_number'] or not can_read(c, d), 'forbidden_is_stale_or_unauthorized', cid)
    if positive and not c['ordered_steps']:
        expect(c['required_facts'] == [[s['quoted_text']] for s in c['expected_sources']], 'all_complete_sentence_facts_required', cid)
    if c['ordered_steps']:
        text = ' '.join(s['quoted_text'] for s in c['expected_sources'])
        match = re.search(r'First, (.*?) Next, (.*?) Then, (.*?) Finally, (.*)', text)
        expect(match is not None and len(c['ordered_steps']) == 4, 'complete_four_action_procedure', cid)
        if match:
            expect(c['ordered_steps'] == [[phrase] for phrase in match.groups()], 'exact_four_steps_in_source_order', cid)
            expect(all(step in c['required_facts'] for step in c['ordered_steps']), 'every_ordered_action_required', cid)
        expect(c['ordered_steps'] == old['ordered_steps'], 'all_ordered_steps_preserved', cid)
    if cid in parameter_cases:
        param = parameter_cases[cid]
        s = c['expected_sources'][0]
        expect(param in s['quoted_text'] and param in s['acceptable_answer_spans'], 'correction_parameter_in_quote_and_spans', cid)
        expect([param] in c['required_facts'] and len(c['required_facts']) == 5, 'correction_parameter_required_in_addition_to_steps', cid)
        expect(c['required_facts'][:4] == old['required_facts'] and c['expected_sources'][0]['content_hash'] == old['expected_sources'][0]['content_hash'], 'correction_reuses_existing_current_facts', cid)
        expect(old['expected_sources'][0]['quoted_text'] in s['acceptable_answer_spans'], 'complete_procedure_span_retained', cid)
        note = 'Complete four-step procedure plus the exact current parameter needed by its textual reference; correction accepted.'
    elif cid in single_cases:
        expect(c['expected_sources'] == [old['expected_sources'][1]], 'single_document_correction_uses_sufficient_arrangements', cid)
        expect(c['required_facts'] == [old['required_facts'][1]], 'single_document_complete_role_schedule_fact', cid)
        expect(c['forbidden_sources'] == [], 'unnecessary_guide_not_forbidden', cid)
        note = 'One authorized arrangements sentence answers the complete broad role-and-session request; unnecessary citation removed.'
    elif positive:
        note = 'Unchanged question/label independently checked against unchanged current authorized source; complete requested fact(s) or ordered actions accepted.'
    else:
        expect(c == old, 'negative_label_unchanged', cid)
        family_prefix = cid.split('-')[0]
        if cid.endswith('-u1'):
            note = 'Requested current participant limit, humidity range, replacement interval, deputy, or cancellation deadline is absent; nearby operating values cannot substitute. Refusal accepted.'
        elif cid.endswith('-u2') or (cid.endswith('-a') and c['forbidden_sources'] and c['forbidden_sources'][0]['document_id'].endswith(('-private', '-foreign'))):
            expect(bool(c['forbidden_sources']) and all(not can_read(c, by_doc[f['document_id']]) for f in c['forbidden_sources']), 'unavailable_fact_permission_refusal', cid)
            note = 'Sole requested fact is private to another principal or confined to ops-b; question instructions grant no access. Refusal accepted.'
        elif c['expected_behavior'] == 'review':
            note = 'Two current authorized curated instructions require opposite first-marker actions and forbid the competing marker. Review accepted.'
        elif c['forbidden_sources']:
            d = by_doc[c['forbidden_sources'][0]['document_id']]
            stale_only = d['versions'][0]['content'].replace(d['versions'][-1]['content'], '').strip()
            expect(bool(stale_only) and stale_only not in d['versions'][-1]['content'] and c['forbidden_sources'][0]['version_number'] == 1, 'unsupported_current_marking_only_in_stale_snapshot', cid)
            note = 'Question asks for current marking; only superseded version 1 gives it. No historical question mislabeled. Refusal accepted.'
        else:
            copied = by_doc[family_prefix + '-copied-note']['versions'][-1]['content']
            expect('untrusted message' in copied and 'not an operating instruction' in copied and 'No reserve capacity is approved' in copied, 'embedded_instruction_is_explicitly_non_authoritative', cid)
            note = 'Copied untrusted instruction certifies no operational capacity; requested certified fact has no authoritative support. Refusal accepted.'
    case_notes.append({'case_id': cid, 'semantic_status': 'accepted', 'note': note})

groups = collections.defaultdict(list)
for d in docs:
    if d['metadata'].get('conflict_group'):
        groups[d['metadata']['conflict_group']].append(d)
for key, pair in groups.items():
    expect(len(pair) == 2, 'two_current_sources_per_curated_conflict', key)
    a, b = [d['versions'][-1]['content'] for d in pair]
    expect('putting the red marker face up' in a and 'blue marker in its drawer' in a and 'putting the blue marker face up' in b and 'red marker must remain in its drawer' in b, 'genuinely_incompatible_conflict_actions', key)
    c = by_id[pair[0]['id'].split('-')[0] + '-c']
    expect(c['expected_behavior'] == 'review' and all(can_read(c, d) for d in pair), 'conflict_current_authorized_review', c['id'])

multi_ids = [c['id'] for c in cases if len(c['expected_sources']) > 1]
ordered_ids = [c['id'] for c in cases if c['ordered_steps']]
expect(len(multi_ids) == 37 and len(multi_ids) >= 30, 'actual_necessary_multidocument_minimum', 'cases')
expect(len(ordered_ids) == 20, 'twenty_complete_ordered_procedures', 'cases')
for family in families:
    expect(True, 'semantic_subject_disjointness_packet_inspection', family)
old_after, old_review_after, new_after = hashes(OLD), hashes(OLD_REVIEW), hashes(NEW)
expect(old_before == old_after, 'original_author_all_files_unchanged', 'original')
expect(old_review_before == old_review_after, 'original_failed_review_all_files_unchanged', 'original-review')
expect(new_before == new_after, 'revision2_author_all_files_unchanged', 'revision2')
report = {
    'status': 'fail' if discrepancies else 'pass',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'discrepancies': discrepancies,
    'total_check_executions': len(results),
    'audit_script_executions': 1,
    'check_results': dict(collections.Counter('passed' if x['passed'] else 'failed' for x in results)),
    'verified_file_hashes': new_before,
    'verified_packet_hashes': {'CONTRACT.md': contract_hash, 'excluded-families.json': digest(exclude_raw)},
    'verified_source_version_hashes': source_version_hashes,
    'preservation': {'original_author_before': old_before, 'original_author_after': old_after, 'original_failed_review_before': old_review_before, 'original_failed_review_after': old_review_after, 'revision2_before': new_before, 'revision2_after': new_after, 'all_preserved': old_before == old_after and old_review_before == old_review_after and new_before == new_after, 'documents_json_exact_byte_equal_to_original': raw['documents.json'] == old_docs_raw, 'question_string_raw_lexemes_identical_count': len(new_question_lexemes) if new_question_lexemes == old_question_lexemes else 0},
    'source_counts': {'documents': len(docs), 'snapshots': len(source_version_hashes), 'visibility': dict(collections.Counter(d['visibility'] for d in docs)), 'workspace': dict(collections.Counter(d['workspace_id'] for d in docs)), 'curated_conflict_groups': len(groups)},
    'family_counts': {'total': len(families), 'documents': dict(collections.Counter(d['family'] for d in docs)), 'cases': dict(collections.Counter(c['family'] for c in cases)), 'semantically_disjoint_from_packet': 20},
    'category_counts': category_counts,
    'composition_counts': {'total_cases': len(cases), 'genuine_multidocument_positives': len(multi_ids), 'complete_ordered_procedure_positives': len(ordered_ids), 'four_action_steps_per_procedure': 4, 'parameter_enriched_procedures': 5, 'single_document_positives': 120 - len(multi_ids), 'negatives_requiring_refusal_or_review': 80, 'curated_conflict_negatives': 10, 'unsupported_current_stale_negatives': 10, 'explicit_question_scopes': sum(c['document_ids'] is not None for c in cases)},
    'corrections_verified': {'exact_changed_label_ids': changed_ids, 'parameter_labels_corrected': list(parameter_cases), 'single_document_labels_corrected': sorted(single_cases), 'other_192_labels_unchanged': len(changed_ids) == 8, 'all_200_question_content_bytes_unchanged': old_question_lexemes == new_question_lexemes and len(new_question_lexemes) == 200, 'all_105_source_records_and_125_snapshots_byte_preserved': raw['documents.json'] == old_docs_raw},
    'all_case_semantic_inspection': case_notes,
    'scope_and_limits': ['Independent standard-library source/label audit only; no application, API, model, evaluation, network, implementation, operational settings, memory, repository onboarding, agent inventories or other chats accessed.', 'Original failed review artifacts were read as opaque hash inputs only; no prior review script was inspected or executed. No author script was inspected, imported or executed.', 'The same substantive source-bound semantic review applies to 192 byte-equivalent labels and unchanged sources; all eight corrections were inspected in full and all 200 labels mechanically reverified.', 'Physical marks/stops and prepared inputs remain the source-defined procedure; all explicit textual dwell/interval/count references now have their current values required.', 'Synthetic authored labels and independent agent review are not human validation, empirical model-quality evidence or general factual-entailment/general-quality certification.'],
}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
(OUT / 'checks.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('status', 'discrepancies', 'total_check_executions', 'check_results', 'source_counts', 'composition_counts', 'corrections_verified')}, indent=2))
