"""Pre-seal metadata/hashes only. Never opens current measurement outputs/logs."""
import ast
from collections import Counter
from datetime import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

O=Path(__file__).resolve().parent
V=O.parents[1]
S=V.parent
W=S/'delivery-worktree'
E=W/'docs/evidence/answer-coverage-v8'
E7=W/'docs/evidence/answer-coverage-v7'
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
read=lambda p:json.loads(p.read_bytes())
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
def blobs(queries):
    stream=io.BytesIO(subprocess.run(['git','-C',str(W),'cat-file','--batch'],input=('\n'.join(queries)+'\n').encode(),stdout=subprocess.PIPE,check=True).stdout)
    result={}
    for q in queries:
        head=stream.readline().split()
        assert head[1]==b'blob'
        result[q]=stream.read(int(head[2]));assert stream.read(1)==b'\n'
    return result

# Explicit allowlist prevents a later seal/report archive from entering this audit.
archives=['author-contract-and-freeze-runner.zip','blind-author-inputs-v1.zip','blind-author-inputs-v2.zip','blind-independent-review.zip','preflight-label-review-v1-failed.zip','preflight-binding-reference-failure.zip']
metadata=['candidate-freeze.json','candidate-freeze.json.sha256','author-dispatch.json','baseline-source-binding.json','blind-corpus-freeze.json','validation-binding.json','binding-reference-correction.json','README.md','baseline-readiness.json','candidate-readiness.json','baseline-readiness-attempt2.json','candidate-readiness-attempt2.json']
before={n:file_sha(E/n) for n in metadata+archives+[n+'.sha256' for n in archives]}
result={'scope':'Pre-seal metadata/hashes only; no measurement reports/outcome logs opened','archives':{}}
data={}
for name in archives:
    p=E/name
    assert before[name]==(E/(name+'.sha256')).read_text().split()[0]
    with zipfile.ZipFile(p) as z:
        hashes=json.loads(z.read('archive-file-hashes.json'))
        assert len(z.namelist())==len(set(z.namelist()))
        assert set(z.namelist())==set(hashes)|{'archive-file-hashes.json'}
        payload={n:z.read(n) for n in hashes}
        assert all(sha(payload[n])==h for n,h in hashes.items())
    data[name]=payload
    result['archives'][name]={'sha256':before[name],'payloads':len(payload)}
freeze=read(E/'candidate-freeze.json')
freeze_sha=sha((E/'candidate-freeze.json').read_bytes())
assert freeze_sha==(E/'candidate-freeze.json.sha256').read_text().strip()
assert freeze['candidate_commit']=='bf7d28361f7f9445fe28d13c5d6ac3bd256c12ec'
assert freeze['baseline_commit']=='e19006c9e8f1a11ef4930e24ed88128e765b6bf5'
assert len(freeze['source_files_sha256'])==286
source_before={n:file_sha(W/n) for n in freeze['source_files_sha256']}
assert source_before==freeze['source_files_sha256']
queries=[freeze['candidate_commit']+':'+n for n in source_before]
candidate=blobs(queries)
assert all(sha(candidate[freeze['candidate_commit']+':'+n])==h for n,h in freeze['git_source_files_sha256'].items())
assert all((W/n).read_bytes().replace(b'\r\n',b'\n')==candidate[freeze['candidate_commit']+':'+n].replace(b'\r\n',b'\n') for n in source_before)
with zipfile.ZipFile(E7/'v14-current-development-engineering.zip') as z:
    prior_source=json.loads(z.read('source-before.json'))
    assert prior_source==json.loads(z.read('source-after.json'))==freeze['observed_source_sha256']
    assert all(prior_source[n]==source_before[n] for n in prior_source)
    development_bytes=z.read('prior-development-80-report.json')
# Only old development header fields are accessed; no scores or cases inspected.
development=json.loads(development_bytes)
assert development['settings']==freeze['settings'] and development['split']=='development'
assert development['corpus_manifest_sha256']==freeze['development_corpus_manifest_sha256']
assert (E/'frozen-development-full-report.json').read_bytes()==development_bytes
assert git('show',freeze['candidate_commit']+':docs/evidence/answer-coverage-v7/v14-current-development-engineering.zip')==(E7/'v14-current-development-engineering.zip').read_bytes()
assert freeze['development_report_sha256']==file_sha(E7/'current-observation.json')
assert freeze['engineering_archive_sha256']==file_sha(E7/'v14-current-development-engineering.zip')
assert freeze['packaging_lint_supplement_sha256']==file_sha(E7/'v14-packaging-lint-supplement.zip')
result['candidate']={'raw_source_paths':286,'git_canonical_paths':len(candidate),'prior_observed_source_paths':len(prior_source),'freeze_sha256':freeze_sha,'development_full_report_sha256':sha(development_bytes)}
baseline=read(E/'baseline-source-binding.json')
assert baseline['revision']==freeze['baseline_commit']
q=[baseline['revision']+':'+n for n in baseline['python_source']]
baseline_blobs=blobs(q)
for n,r in baseline['python_source'].items():
    raw=(S/'baseline-source'/n).read_bytes()
    assert sha(raw)==r['observed_windows_sha256']
    canonical=baseline_blobs[baseline['revision']+':'+n]
    assert sha(canonical)==r['git_canonical_sha256']
    assert raw.replace(b'\r\n',b'\n')==canonical.replace(b'\r\n',b'\n')
result['baseline_source_paths']=len(q)
asset_roots={'reader_assets':S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4','retained_minilm_assets':S/'models/minilm-uncased-squad2--934656cdda79824eabf503ed56e15c01ddbdbe3f','embedding_assets':W.parents[2]/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41'}
result['asset_files']={}
for label,root in asset_roots.items():
    spec=freeze[label]
    assert all(file_sha(root/n)==h for n,h in spec['files'].items())
    manifest='groundtruth-model.json' if label=='embedding_assets' else 'groundtruth-reader.json'
    assert file_sha(root/manifest)==spec['manifest_sha256']
    result['asset_files'][label]=len(spec['files'])
assert all(importlib.metadata.version(n)==v for n,v in freeze['runtime'].items() if n!='python')
assert sys.version.split()[0]==freeze['runtime']['python']
result['runtime_versions_match']=True

a=data['blind-author-inputs-v1.zip'];b=data['blind-author-inputs-v2.zip']
af=json.loads(a['FREEZE_SHA256.json']);bf=json.loads(b['FREEZE_SHA256.json'])
for version,packet in [(af,a),(bf,b)]:
    assert all(sha(packet[n])==h for n,h in version['sha256'].items())
assert a['documents.json']==b['documents.json']
ca=json.loads(a['cases.json']);cb=json.loads(b['cases.json'])
assert len(ca)==len(cb)==200
assert [c['id'] for c in ca]==[c['id'] for c in cb]
assert all(x['question']==y['question'] for x,y in zip(ca,cb))
raw_questions=lambda raw:re.findall(rb'"question"\s*:\s*("(?:[^"\\]|\\.)*")',raw)
assert len(raw_questions(a['cases.json']))==200
assert raw_questions(a['cases.json'])==raw_questions(b['cases.json'])
changed=[set(x)|set(y) for x,y in zip(ca,cb) if x!=y]
assert len(changed)==8
changed_fields=[{k for k in set(x)|set(y) if x.get(k)!=y.get(k)} for x,y in zip(ca,cb) if x!=y]
assert all(fields=={'expected_sources','required_facts','label_rationale'} for fields in changed_fields)
profile_a=json.loads(a['profile.json']);profile_b=json.loads(b['profile.json'])
assert {k for k in set(profile_a)|set(profile_b) if profile_a.get(k)!=profile_b.get(k)}=={'revision'}
review_packet=data['blind-independent-review.zip'];review=json.loads(review_packet['report.json'])
failed_packet=data['preflight-label-review-v1-failed.zip'];failed=json.loads(failed_packet['report.json'])
assert failed['status']=='fail' and review['status']=='pass' and not review['discrepancies']
assert review['total_check_executions']==6612
assert review['composition_counts']['genuine_multidocument_positives']==37
assert review['composition_counts']['complete_ordered_procedure_positives']==20
assert review['composition_counts']['negatives_requiring_refusal_or_review']==80
assert review['category_counts']==dict(Counter(c['category'] for c in cb))
preserved=review['preservation']
for prefix,packet in [('original_author',a),('original_failed_review',failed_packet),('revision2',b)]:
    assert preserved[prefix+'_before']==preserved[prefix+'_after']
    assert all(sha(packet[n])==h for n,h in preserved[prefix+'_before'].items())
assert preserved['all_preserved'] and preserved['question_string_raw_lexemes_identical_count']==200
result['input_preservation']={'documents_bytes_identical':True,'questions_raw_lexemes_identical':200,'label_cases_changed':8,'changed_fields':sorted(changed_fields[0]),'raw_profile_change':'revision metadata only','independent_recheck_executions':6612,'reviewed_multidocument':37,'reviewed_complete_procedures':20,'negative_categories':80}
corpus=read(E/'blind-corpus-freeze.json')
C=S/'blind-v5-derived-v1'
assert all(file_sha(C/n)==h for n,h in corpus['corpus_files'].items())
assert (C/'documents.json').read_bytes()==b['documents.json']
assert (C/'cases.json').read_bytes()==b['cases.json']
assert read(C/'profile.json')==freeze['settings']
assert corpus['independent_review_sha256']==sha(review_packet['report.json'])
assert corpus['candidate_commit']==freeze['candidate_commit']
assert corpus['author_manifest_sha256']==sha(b['manifest.json'])
assert corpus['corpus_manifest_sha256']==file_sha(C/'manifest.json')
dispatch=read(E/'author-dispatch.json')
assert dispatch['candidate_freeze_sha256']==freeze_sha and dispatch['case_queries_executed']==0
contract=data['author-contract-and-freeze-runner.zip']
assert sha(contract['CONTRACT.md'])==freeze['author_contract_sha256']
assert sha(contract['excluded-families.json'])==freeze['excluded_family_packet_sha256']
times=[freeze['frozen_at'],dispatch['dispatch_recorded_at'],af['frozen_utc'],failed['reviewed_utc'],bf['frozen_utc'],review['reviewed_utc'],corpus['bound_at']]
assert list(map(datetime.fromisoformat,times))==sorted(map(datetime.fromisoformat,times))
result['chronology']=dict(zip(['candidate_freeze','dispatch_recorded','author_v1_freeze','failed_label_review','author_v2_freeze','label_recheck','corpus_bound'],times))

failure=data['preflight-binding-reference-failure.zip']
old=json.loads(failure['original/validation-binding.json'])
binding=read(E/'validation-binding.json');erratum=read(E/'binding-reference-correction.json')
assert sha(failure['original/validation-binding.json'])==erratum['prior_binding_sha256']
assert file_sha(E/'validation-binding.json')==erratum['corrected_binding_sha256']
assert freeze_sha==erratum['candidate_freeze_unchanged_sha256']
assert binding['development_report_sha256']==sha(development_bytes)==erratum['full_report_sha256']
assert binding['development_report_path']=='frozen-development-full-report.json'
assert binding['candidate_freeze_sha256']==freeze_sha
assert binding['settings']==old['settings']==freeze['settings']==development['settings']
assert {k for k in set(old)|set(binding) if old.get(k)!=binding.get(k)}=={'development_report_path','development_report_sha256','binding_at'}
assert old['development_report_path']==freeze['development_report_path']
counts=json.loads(failure['preflight-only-counts.json'])
assert counts==erratum['database_counts_before_retry']
for arm in ['baseline','candidate']:
    assert counts[arm]=={'documents':105,'chunks':105,'queries':1,'seed_legacy_history_rows':1,'evaluated_case_rows':0}
    assert failure['first-'+arm+'-blind-v5.log'].decode().strip()=='Evaluation unavailable: ValueError: Selection must reference frozen development evidence'
    seed=read(S/(arm+'-blind-v5')/'seed-manifest.json')
    assert seed['seed_status']=='complete' and seed['corpus_manifest_sha256']==corpus['corpus_manifest_sha256']
# Compare original/retry controller source only, not runtime logs or outputs.
execute=(V/'execute_blind_v5_attempt2.py').read_text()
assert 'runtime,\'seed\'' not in execute and 'no duplicate ingestion' in execute
measure=(V/'measure_blind_v5_attempt2.py').read_text()
assert 'post_issues=state_checks()' in measure and 'case_level_failure_inspection_before_seal' in measure
tree=ast.parse((W/'scripts/evaluate_portfolio_retrieval.py').read_text(encoding='utf-8'))
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
calls={n.func.id:n.lineno for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in {'evaluation_settings','request_json'}}
assert calls['evaluation_settings']<calls['request_json']
result['binding_correction']={'changed_fields':['development_report_path','development_report_sha256','binding_at'],'freeze_unchanged':True,'full_report_exact_prefreeze_payload':True,'preflight_error_precedes_case_request':True,'recorded_counts':counts,'retry_reuses_seed':True}

# Exact key scan over allowlisted evidence, never current result files or logs.
keys=set()
for arm in ['baseline','candidate']:
    seed=read(S/(arm+'-blind-v5')/'seed-manifest.json')
    keys.update(p['api_key'].encode() for p in seed['principals'].values() if p.get('api_key'))
evidence=[(E/n).read_bytes() for n in metadata]+[x for packet in data.values() for x in packet.values()]+[development_bytes]
assert not any(key in body for key in keys for body in evidence)
result['private_key_check']={'known_keys':len(keys),'allowlisted_payloads':len(evidence),'matches':0}
source_after={n:file_sha(W/n) for n in source_before}
assert source_before==source_after
assert before=={n:file_sha(E/n) for n in before}
(O/'source-before.json').write_text(json.dumps(source_before,indent=2),encoding='utf-8')
(O/'source-after.json').write_text(json.dumps(source_after,indent=2),encoding='utf-8')
(O/'evidence-hashes.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
(O/'audit-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
