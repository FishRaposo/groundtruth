"""Frozen portable scorer plus read-only sealed evidence audit. No HTTP/models."""
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

O=Path(__file__).resolve().parent
V=O.parents[1]
S=V.parent
W=S/'delivery-worktree'
E=W/'docs/evidence/answer-coverage-v8'
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
freeze=read(E/'candidate-freeze.json')
commit=freeze['candidate_commit']
modules=['apps/api/app/__init__.py','apps/api/app/portfolio/__init__.py','apps/api/app/portfolio/coverage.py','apps/api/app/portfolio/evaluation.py','scripts/verify_answer_coverage_delivery.py']
for n in modules:
    b=git('show',commit+':'+n)
    assert sha(b)==freeze['git_source_files_sha256'][n]
    p=O/'frozen'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
sys.path[:0]=[str(O/'frozen/apps/api'),str(O/'frozen/scripts')]
from app.portfolio import load_corpus
from verify_answer_coverage_delivery import compare_reports

corpus=load_corpus(S/'blind-v5-derived-v1')
cases={c['id']:c for c in corpus['cases']}
documents={d['id']:d for d in corpus['documents']}
seal=read(E/'first-comparison-seal.json')
assert sha((E/'first-comparison-seal.json').read_bytes())==(E/'first-comparison-seal.json.sha256').read_text().strip()
assert seal['post_state_issues']==[] and seal['source_runtime_assets_corpus_unchanged'] is True
assert seal['candidate_commit']==commit
assert seal['candidate_freeze_sha256']==sha((E/'candidate-freeze.json').read_bytes())
assert seal['binding_sha256']==sha((E/'validation-binding.json').read_bytes())
assert seal['corpus_manifest_sha256']==corpus['manifest']['manifest_sha256']
assert seal['case_level_failure_inspection_before_seal'] is False
binding=read(E/'validation-binding.json')
correction=read(E/'binding-reference-correction.json')
times=[freeze['frozen_at'],read(E/'blind-corpus-freeze.json')['author_frozen_at'],binding['binding_at'],correction['recorded_at'],seal['started_at']]
assert list(map(datetime.fromisoformat,times))==sorted(map(datetime.fromisoformat,times))
reports={}
raw_reports={}
for record in seal['reports']:
    path=E/record['path'];b=path.read_bytes();raw_reports[record['arm']]=b
    assert sha(b)==record['sha256']==path.with_suffix('.json.sha256').read_text().strip()
    assert (S/record['path']).read_bytes()==b
    report=json.loads(b)
    assert report['settings']==freeze['settings']
    assert report['selection_sha256']==seal['binding_sha256']
    assert report['execution_arm']==record['arm']
    assert datetime.fromisoformat(seal['started_at'])<=datetime.fromisoformat(report['created_at'])<=datetime.fromisoformat(seal['sealed_at'])
    assert record['case_rows']==sum(len(v['cases']) for v in report['results'].values())==800
    assert record['exit_code']==1
    reports[record['arm']]=report

gate=compare_reports(reports['baseline'],reports['candidate'],corpus=corpus)
assert gate==read(E/'comparison-gate.json')
assert gate['gate']=='failed' and read(E/'comparison-command.json')['exit']==1
assert sha((E/'comparison-gate.json').read_bytes())==(E/'comparison-gate.json.sha256').read_text().strip()
result={'gate':gate,'seal_sha256':sha((E/'first-comparison-seal.json').read_bytes()),'frozen_function_modules':{n:sha((O/'frozen'/n).read_bytes()) for n in modules},'reports':{},'failure_distribution':{},'performance_scope':'functional timing only; parallel arms share CPU, no latency/capacity benchmark'}
for arm,report in reports.items():
    result['reports'][arm]={'sha256':sha(raw_reports[arm]),'created_at':report['created_at'],'case_rows':800,'span_integrity_required':report['span_integrity_required']}
    result['failure_distribution'][arm]={}
    for method,value in report['results'].items():
        rows=value['cases']
        result['failure_distribution'][arm][method]={
            'summary':value['summary'],
            'positive_false_refusals':sum(r['category']=='answerable' and r['refused'] for r in rows),
            'positive_nonrefused_failures':sum(r['category']=='answerable' and not r['refused'] and not r['answer_quality_passed'] for r in rows),
            'negative_failures_by_category':dict(Counter(r['category'] for r in rows if r['category']!='answerable' and not r['answer_quality_passed'])),
        }

# Bounded deterministic sample: first two failures in each of five strata.
rows=reports['candidate']['results']['reranked']['cases']
predicates={
 'positive_refusal':lambda r:r['category']=='answerable' and r['refused'],
 'positive_nonrefused':lambda r:r['category']=='answerable' and not r['refused'] and not r['answer_quality_passed'],
 'negative_unanswerable':lambda r:r['category']=='unanswerable' and not r['answer_quality_passed'],
 'negative_conflicting_stale':lambda r:r['category']=='conflicting_stale' and not r['answer_quality_passed'],
 'negative_adversarial':lambda r:r['category']=='adversarial' and not r['answer_quality_passed'],
}
samples=[]
for stratum,predicate in predicates.items():
    for row in [r for r in rows if predicate(r)][:2]:
        c=cases[row['case_id']];response=row['observed_response']
        source_rows=[]
        reverse={v:k for k,v in reports['candidate']['source_document_ids'].items()}
        for source in response.get('sources',[]):
            logical=reverse.get(source['document_id'])
            source_rows.append({'logical_id':logical,'title':source.get('title'),'version':source.get('document_version'),'quote':source.get('quoted_text'),'answer_spans':source.get('answer_spans')})
        sample={'stratum':stratum,'case_id':c['id'],'question':c['question'],'expected_behavior':c['expected_behavior'],'explicit_document_filter':c['document_ids'],'label_rationale':c['label_rationale'],'required_facts':c['required_facts'],'ordered_steps':c['ordered_steps'],'expected_sources':c['expected_sources'],'answer':response.get('answer'),'refusal_reason':response.get('refusal_reason'),'score_fields':{k:row.get(k) for k in ['refused','behavior_correct','source_version_correct','answer_contract_correct','required_facts_correct','ordered_steps_correct','citation_integrity_correct','span_integrity_correct','unauthorized_source_exposures']},'sources':source_rows}
        samples.append(sample)
(O/'representative-samples.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2),encoding='utf-8')
result['representative_sample_ids']=[s['case_id'] for s in samples]
original=read(S/'original-evidence-hashes.json')
assert len(original)==16 and all(sha((W/n).read_bytes())==h for n,h in original.items())
historical=git('ls-tree','-r','--name-only','57e4128','docs/evidence/answer-coverage-v4').decode().splitlines()
assert len(historical)==21 and all(git('show','57e4128:'+n)==(W/n).read_bytes() for n in historical)
result['historical_unchanged']={'original':16,'sealed_v4_including_readme':21}

# Public evidence exact-key check only; no private values emitted.
keys=set()
for arm in ['baseline','candidate']:
    seed=read(S/(arm+'-blind-v5')/'seed-manifest.json')
    keys.update(p['api_key'].encode() for p in seed['principals'].values() if p.get('api_key'))
payloads=[p.read_bytes() for p in E.iterdir() if p.is_file()]
for p in E.glob('*.zip'):
    with zipfile.ZipFile(p) as z:payloads.extend(z.read(n) for n in z.namelist())
assert not any(k in b for k in keys for b in payloads)
result['private_key_check']={'known_keys':len(keys),'payloads_checked':len(payloads),'matches':0}
source_before=read(O/'source-before.json')
assert source_before==freeze['source_files_sha256']
assert source_before=={n:sha((W/n).read_bytes()) for n in source_before}
result['source_files_unchanged']=len(source_before)
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'final-audit-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='failure_distribution'},indent=2))
print('FAILURE_DISTRIBUTION',json.dumps({a:{m:{k:v for k,v in d.items() if k!='summary'} for m,d in methods.items()} for a,methods in result['failure_distribution'].items()},indent=2))
