"""Reproduce saved explicit-scope rejection with frozen pure request helpers."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
O=Path(__file__).resolve().parent
V=O.parents[1];S=V.parent;W=S/'delivery-worktree';E=W/'docs/evidence/answer-coverage-v8'
freeze=json.loads((E/'candidate-freeze.json').read_bytes())
for name in ['reader_questions.py','reader_support.py']:
    path='apps/api/app/services/'+name
    raw=subprocess.check_output(['git','-C',str(W),'show',freeze['candidate_commit']+':'+path])
    assert hashlib.sha256(raw).hexdigest()==freeze['git_source_files_sha256'][path]
    dest=O/'frozen'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
sys.path.insert(0,str(O/'frozen/apps/api'))
from app.services.reader_questions import question_parts,scope_matches
cases=json.loads((S/'blind-v5-derived-v1/cases.json').read_bytes())
docs={d['id']:d for d in json.loads((S/'blind-v5-derived-v1/documents.json').read_bytes())}
report=json.loads((E/'first-candidate-blind-v5.json').read_bytes())
rows={r['case_id']:r for r in report['results']['reranked']['cases']}
results=[]
for case in cases:
    if case['document_ids'] is None:continue
    parts=question_parts(case['question'])
    context=docs[case['document_ids'][0]]['versions'][-1]['content']
    record={'case_id':case['id'],'question':case['question'],'anchors':[p.anchors for p in parts],'context_scope_matches':[scope_matches(p,context) for p in parts],'saved_refused':rows[case['id']]['refused'],'saved_part_decisions':[[p.get('decision') for p in c.get('parts',[])] for c in rows[case['id']]['provenance']['answer_selection']['candidates']]}
    results.append(record)
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
(O/'explicit-filter-probe.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
