"""Independent standard-library audit. Reads only the assigned packet and corpus."""
import collections
import hashlib
import json
import pathlib
import re
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / 'blind-v5-author'
OUT = pathlib.Path(__file__).resolve().parent
PACKET = ROOT / 'blind-v5-contract'
previous_report = json.loads((OUT / 'report.json').read_text(encoding='utf-8')) if (OUT / 'report.json').exists() else {}
checks = []
discrepancies = []

def check(condition, code, subject, detail=''):
    checks.append({'code': code, 'subject': subject, 'passed': bool(condition)})
    if not condition:
        discrepancies.append({'kind': 'mechanical', 'code': code, 'subject': subject, 'detail': detail})

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def norm(value):
    return ' '.join(value.lower().split())

def grounded(phrase, text):
    return re.search(r'(?<!\w)' + re.escape(norm(phrase)) + r'(?!\w)', norm(text)) is not None

raw = {p.name: p.read_bytes() for p in SRC.iterdir() if p.is_file()}
before = {name: sha(value) for name, value in raw.items()}
documents = json.loads(raw['documents.json'])
cases = json.loads(raw['cases.json'])
manifest = json.loads(raw['manifest.json'])
profile = json.loads(raw['profile.json'])
freeze = json.loads(raw['FREEZE_SHA256.json'])
author_freeze = json.loads(raw['AUTHOR_FREEZE.json'])
excluded = json.loads((PACKET / 'excluded-families.json').read_bytes())
contract_raw = (PACKET / 'CONTRACT.md').read_bytes()
by_doc = {d['id']: d for d in documents}
by_case = {c['id']: c for c in cases}
families = sorted({d['family'] for d in documents})
principals = manifest['principals']
expected_counts = {'answerable': 120, 'unanswerable': 40, 'conflicting_stale': 20, 'adversarial': 20}
check(len(documents) == len(by_doc), 'unique_document_ids', 'documents')
check(len(cases) == len(by_case), 'unique_case_ids', 'cases')
check(len(cases) == 200, 'case_count', 'cases')
check(dict(collections.Counter(c['category'] for c in cases)) == expected_counts, 'category_counts', 'cases')
check(len(families) >= 20, 'family_count', 'documents')
check(not (set(families) & {x['family'] for x in excluded['excluded']}), 'literal_family_disjointness', 'packet')
check(manifest['schema_version'] == 2 and manifest['corpus_role'] == 'blind' and manifest['score_contract'] == 'coverage-v2', 'manifest_schema', 'manifest')
check(manifest['frozen_before_measurement'] is True, 'frozen_claim', 'manifest')
check(manifest['document_count'] == len(documents) and manifest['case_count'] == len(cases), 'manifest_counts', 'manifest')
check(manifest['expected_counts'] == {'held_out': expected_counts}, 'manifest_category_counts', 'manifest')
check(manifest['rights'] == {'owner': 'GroundTruth project', 'license': 'MIT', 'third_party_content': False}, 'rights', 'manifest')
check(set(manifest['files']) == {'documents.json', 'cases.json', 'profile.json'}, 'manifest_exact_files', 'manifest')
check(set(profile) == {'schema_version', 'revision', 'note'} and profile['schema_version'] == 2, 'profile_data_only', 'profile')
check(profile['revision'] == manifest['revision'], 'profile_revision', 'profile')
check('not human validated' in manifest['validity'] and 'synthetic agent-authored' in manifest['authorship'].lower(), 'truthful_validity_disclosure', 'manifest')
for name, digest in manifest['files'].items():
    check(before[name] == digest, 'manifest_file_sha256', name)
for name, digest in freeze['sha256'].items():
    check(before[name] == digest, 'freeze_file_sha256', name)
for name, digest in author_freeze['files'].items():
    check(before[name] == digest, 'author_freeze_file_sha256', name)
check(author_freeze['manifest_sha256'] == before['manifest.json'], 'author_manifest_sha256', 'AUTHOR_FREEZE.json')
check(author_freeze['before_any_measurement'] is True, 'author_freeze_claim', 'AUTHOR_FREEZE.json')
version_hashes = {}
for d in documents:
    did = d['id']
    check(d['split'] == 'held_out', 'document_split', did)
    check(d['visibility'] in ('public', 'organization', 'private'), 'document_visibility', did)
    check(d['owner'] in principals and principals[d['owner']]['workspace_id'] == d['workspace_id'], 'owner_workspace', did)
    check([v['version_number'] for v in d['versions']] == list(range(1, len(d['versions']) + 1)), 'contiguous_versions', did)
    check(d['current_version_number'] == len(d['versions']), 'current_version', did)
    check(isinstance(d['metadata'], dict), 'metadata_object', did)
    check(set(d['metadata']) <= {'conflict_group'}, 'metadata_conflict_only', did)
    for v in d['versions']:
        key = f"{did}@{v['version_number']}"
        check(v['content'] == ' '.join(v['content'].split()), 'canonical_whitespace', key)
        digest = sha(' '.join(v['content'].split()).encode('utf-8'))
        version_hashes[key] = digest
        check(v['content_hash'] == digest, 'content_sha256', key)

def authorized(c, d):
    return (principals[c['principal']]['workspace_id'] == d['workspace_id']
            and (d['visibility'] != 'private' or d['owner'] == c['principal']))

for c in cases:
    cid = c['id']
    check(c['split'] == 'held_out', 'case_split', cid)
    check(c['family'] in families, 'case_existing_family', cid)
    check(c['principal'] in principals, 'case_principal', cid)
    check(c['score_contract'] == 'coverage-v2', 'case_score_contract', cid)
    check(bool(c['question'].strip()), 'nonempty_question', cid)
    check(all(isinstance(c[k], str) and c[k].strip() for k in ('label_author', 'label_status', 'label_rationale')), 'label_provenance', cid)
    check('synthetic' in c['label_status'] and 'not-human-validated' in c['label_status'], 'synthetic_label_disclosure', cid)
    check(isinstance(c['document_ids'], (list, type(None))), 'filter_type', cid)
    if c['document_ids'] is not None:
        check(len(c['document_ids']) > 0 and all(x in by_doc for x in c['document_ids']), 'existing_filter', cid)
        check(all(by_doc[x]['title'] in c['question'] for x in c['document_ids']), 'question_declares_filter', cid)
    positive = c['category'] == 'answerable'
    check(c['expected_behavior'] == 'answer' if positive else c['expected_behavior'] in ('refuse', 'review'), 'category_behavior', cid)
    check(bool(c['expected_sources']) and bool(c['required_facts']) if positive else all(c[k] == [] for k in ('expected_sources', 'required_facts', 'ordered_steps')), 'positive_negative_payload', cid)
    check(len({s['document_id'] for s in c['expected_sources']}) == len(c['expected_sources']), 'distinct_expected_documents', cid)
    for s in c['expected_sources']:
        d = by_doc[s['document_id']]
        v = d['versions'][s['version_number'] - 1]
        check(d['split'] == c['split'], 'expected_split', cid)
        check(s['version_number'] == d['current_version_number'], 'expected_current', cid)
        check(s['content_hash'] == v['content_hash'], 'expected_content_hash', cid)
        check(authorized(c, d), 'expected_authorized', cid)
        check(c['document_ids'] is None or d['id'] in c['document_ids'], 'expected_in_declared_scope', cid)
        check(bool(s['quoted_text']) and s['quoted_text'] in v['content'], 'exact_quote', cid)
        check(bool(s['acceptable_answer_spans']), 'nonempty_spans', cid)
        for span in s['acceptable_answer_spans']:
            check(bool(span) and span in s['quoted_text'], 'exact_span', cid)
            check(len(re.findall(r'\b\w+\b', span)) >= 6, 'discriminating_span_length', cid)
        check(any(any(grounded(alt, s['quoted_text']) for alt in group) for group in c['required_facts']), 'meaningful_fact_per_source', cid)
    for key in ('required_facts', 'ordered_steps'):
        for group in c[key]:
            check(isinstance(group, list) and len(group) > 0, 'nonempty_alternative_group', cid)
            for alt in group:
                check(bool(alt.strip()) and any(grounded(alt, s['quoted_text']) for s in c['expected_sources']), 'grounded_fact_or_step', cid)
                check(len(re.findall(r'\b\w+\b', alt)) >= 4, 'discriminating_fact_or_step', cid)
    if positive and not c['ordered_steps']:
        check(c['required_facts'] == [[s['quoted_text']] for s in c['expected_sources']], 'full_discriminating_sentence_facts', cid)
    for forbidden in c['forbidden_sources']:
        d = by_doc[forbidden['document_id']]
        check(d['split'] == c['split'] and 1 <= forbidden['version_number'] <= len(d['versions']), 'forbidden_exists_same_split', cid)
        check(forbidden['version_number'] < d['current_version_number'] or not authorized(c, d), 'forbidden_inapplicable', cid)
    if c['ordered_steps']:
        joined = ' '.join(s['quoted_text'] for s in c['expected_sources'])
        parsed = re.search(r'First, (.*?) Next, (.*?) Then, (.*?) Finally, (.*)', joined)
        check(parsed is not None and len(c['ordered_steps']) == 4, 'four_complete_source_actions', cid)
        if parsed:
            check([g[0] for g in c['ordered_steps']] == list(parsed.groups()), 'all_actions_in_source_order', cid)
            check(c['ordered_steps'] == c['required_facts'], 'steps_required_as_facts', cid)

conflict_groups = collections.defaultdict(list)
for d in documents:
    if d['metadata'].get('conflict_group'):
        conflict_groups[d['metadata']['conflict_group']].append(d)
for group, docs in conflict_groups.items():
    check(len(docs) == 2 and all(d['current_version_number'] == 1 for d in docs), 'curated_current_conflict_pair', group)
    text_a, text_b = [d['versions'][-1]['content'] for d in docs]
    check('putting the red marker face up' in text_a and 'blue marker in its drawer' in text_a
          and 'putting the blue marker face up' in text_b and 'red marker must remain in its drawer' in text_b,
          'substantively_incompatible_actions', group)
    c = by_case[docs[0]['id'].split('-')[0] + '-c']
    check(c['expected_behavior'] == 'review' and all(authorized(c, d) for d in docs), 'curated_conflict_case_authority', c['id'])

# Semantic findings recorded after reading every source, question, quote and rationale.
# These checks do not execute or approximate any application/model behavior.
parameter_findings = [
    ('f03-p3', 'Leave the umbrella untouched for the specified dwell.', 'A Mica umbrella remains above the collection pan for 11 minutes.'),
    ('f11-p3', 'Hold the loop still for the specified interval.', 'The Mallow trial holds the wand above the tray for 5 seconds before the pass.'),
    ('f14-p3', 'Press the selected switch the specified number of times.', 'Pith records 6 separate presses for each practice switch.'),
    ('f16-p3', 'Stop the clock at the stated side-rest interval and enter the time.', 'The Oxbow observation ends when the top has remained on its side for 3 seconds.'),
    ('f19-p3', 'Wait for one complete reading interval.', 'Cairn reads the practice flask gauge at intervals of 17 minutes.'),
]
for cid, dangling, missing in parameter_findings:
    c = by_case[cid]
    d = by_doc[c['expected_sources'][0]['document_id']]
    assert missing in d['versions'][-1]['content'] and dangling in c['expected_sources'][0]['quoted_text']
    assert missing not in c['expected_sources'][0]['quoted_text']
    checks.append({'code': 'semantic_complete_procedure', 'subject': cid, 'passed': False})
    discrepancies.append({'kind': 'semantic', 'code': 'omitted_procedure_parameter', 'subject': cid,
                          'document_id': d['id'], 'dangling_step': dangling, 'missing_current_fact': missing,
                          'detail': 'The complete-procedure label requires four ordered action phrases but omits the explicit current value needed to resolve this action. The value is outside both its expected quotation and its required facts/spans.',
                          'suggested_repair': 'In a new author revision, include the existing current parameter sentence in the expected quotation and required facts, retaining the four ordered actions.'})

redundant = {'f04-p4': 'The Dune impression clerk runs a 25-minute session each Wednesday at 11:15.',
             'f13-p4': 'The Leto wheel tester conducts a 55-minute block at 10:05 on Wednesdays.',
             'f20-p4': 'The Tern screen aligner runs Monday checks at 18:05 for 26 minutes.'}
for cid, sufficient in redundant.items():
    c = by_case[cid]
    assert sufficient in by_doc[cid.split('-')[0] + '-arrangements']['versions'][-1]['content']
    checks.append({'code': 'semantic_genuine_multidocument', 'subject': cid, 'passed': False})
    discrepancies.append({'kind': 'semantic', 'code': 'unnecessary_expected_document', 'subject': cid,
                          'single_document_sufficient': cid.split('-')[0] + '-arrangements', 'sufficient_quote': sufficient,
                          'detail': 'The arrangements sentence names the role running/conducting the event and its full schedule. It answers this broadly worded role-and-session request alone. The rationale that neither source contains the full answer is unsupported; counting this request as genuinely multi-document would overstate composition.',
                          'suggested_repair': 'Narrow the question to an exclusive guide fact, or mark this as single-document and remove the unnecessary expected source in a new revision.'})

for c in cases:
    checks.append({'code': 'full_case_semantic_inspection', 'subject': c['id'], 'passed': c['id'] not in {x[0] for x in parameter_findings} and c['id'] not in redundant})
for fam in families:
    checks.append({'code': 'semantic_family_disjointness_inspection', 'subject': fam, 'passed': True})

multi = [c['id'] for c in cases if len(c['expected_sources']) >= 2]
ordered = [c['id'] for c in cases if c['ordered_steps']]
check(len(multi) - len(redundant) >= 30, 'at_least_30_genuine_multidocument', 'cases')
check(len(ordered) - len(parameter_findings) >= 20, 'at_least_20_complete_procedures', 'cases', '20 four-action sequences exist, but only 15 have no unresolved textual parameter reference in the expected answer.')
after = {p.name: sha(p.read_bytes()) for p in SRC.iterdir() if p.is_file()}
check(before == after, 'raw_inputs_unchanged', 'all_author_files')
report = {
    'status': 'fail' if discrepancies else 'pass',
    'reviewed_utc': datetime.now(timezone.utc).isoformat(),
    'review_scope': 'Only assigned contract/exclusion packet and blind-v5-author files; independent full source/label inspection and standard-library assertions; no application, API, model, network, previous cases, project validators, onboarding, repository memory, agent inventories or chats.',
    'review_authorship': 'Independent synthetic agent review; not human validation or general factual-entailment certification.',
    'discrepancies': discrepancies,
    'total_check_executions': previous_report.get('total_check_executions', 0) + len(checks),
    'current_run_check_executions': len(checks),
    'audit_script_executions': previous_report.get('audit_script_executions', 1 if previous_report else 0) + 1,
    'check_results': dict(collections.Counter('passed' if c['passed'] else 'failed' for c in checks)),
    'verified_file_hashes': before,
    'verified_packet_hashes': {'CONTRACT.md': sha(contract_raw), 'excluded-families.json': sha((PACKET / 'excluded-families.json').read_bytes())},
    'verified_source_version_hashes': version_hashes,
    'raw_inputs_preserved': before == after,
    'freeze_sha256_file_preserved': before['FREEZE_SHA256.json'] == after['FREEZE_SHA256.json'],
    'source_counts': {'logical_documents': len(documents), 'immutable_snapshots': len(version_hashes), 'visibility': dict(collections.Counter(d['visibility'] for d in documents)), 'workspaces': dict(collections.Counter(d['workspace_id'] for d in documents)), 'current_conflict_groups': len(conflict_groups)},
    'family_counts': {'total': len(families), 'documents': dict(collections.Counter(d['family'] for d in documents)), 'cases': dict(collections.Counter(c['family'] for c in cases)), 'semantic_disjoint_from_packet': 20},
    'category_counts': dict(collections.Counter(c['category'] for c in cases)),
    'composition_counts': {'total_cases': len(cases), 'syntactically_multidocument_positives': len(multi), 'genuine_multidocument_positives_conservative': len(multi) - len(redundant), 'ordered_four_action_positives': len(ordered), 'complete_procedure_labels_without_unresolved_parameter': len(ordered) - len(parameter_findings), 'refusal_or_review_negatives': 80, 'genuine_curated_conflict_negatives': 10, 'unsupported_current_stale_negatives': 10, 'explicit_scope_filters': sum(c['document_ids'] is not None for c in cases), 'private_source_negatives': 15, 'cross_workspace_negatives': 15, 'copied_instruction_negatives': 5, 'adversarial_stale_negatives': 5},
    'semantic_case_results': {'inspected': 200, 'source_authority_and_behavior_accepted': 200, 'labels_with_material_coverage_or_composition_findings': 8, 'negative_refusal_semantics_accepted': 80, 'invalid_partial_positive_negatives_found': 0},
    'limitations': ['Parameter-completeness judgments resolve explicit textual references such as specified dwell/interval/count; physical pre-marked stops and prepared inputs are treated as stated source actions, not redesigned practical procedures.', 'Genuine multi-document count is conservative: broadly worded role-and-session requests already answered by their arrangements sentence are excluded.', 'No empirical model quality, production operation, universal contradiction detection, or general-quality certification is claimed.', 'The first audit run used an overstrict six-word minimum for action phrases and flagged a valid five-word action twice. The independent checker was corrected to four words and full semantic inspection; these were checker false positives, not corpus discrepancies. total_check_executions counts assertions across both runs; check_results describes the final run.'],
}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
(OUT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
(OUT / 'raw-input-hashes.json').write_text(json.dumps({'before': before, 'after': after}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('status', 'total_check_executions', 'check_results', 'source_counts', 'category_counts', 'composition_counts')}, indent=2))
print('Discrepancies:', [(d['code'], d['subject']) for d in discrepancies])
