# Independent frozen-source label review

**Status: FAIL.** The frozen corpus has the correct 200-case distribution and intact source authority, hashes, permissions, quotations and literal step grounding. Five complete-procedure labels omit the explicit current values needed by their own steps. Three broadly worded role-and-session requests are answerable from their arrangements document alone, contrary to their multi-document rationale. These are eight affected labels; the procedure minimum consequently fails under a complete-answer reading of the contract.

This review read only the assigned `CONTRACT.md`, `excluded-families.json` and the `blind-v5-author` directory. It used an independently written Python standard-library audit plus inspection of every question, label, current source, historical-only addition, quotation and rationale. No application, API, model, network, prior corpus, prior review script, repository validator, onboarding, memory, agent inventory or chat was inspected or executed. The author's generation/check scripts and review notes were hashed as raw artifacts, not imported or executed.

## Coverage and integrity

| Item | Verified result |
| --- | --- |
| Cases | 200: 120 answerable, 40 unanswerable, 20 conflicting_stale, 20 adversarial |
| Sources | 105 logical documents, 125 immutable snapshots; contiguous versions and current pointers |
| Families | 20 held_out families; subject matter manually compared with the exclusion packet and accepted as disjoint |
| Visibility | 25 public, 56 organization, 24 private documents |
| Workspaces | 85 sources in ops-a; 20 sources in ops-b |
| Positive authority | All expected sources current, correctly hashed, in scope and readable by the declared principal |
| Grounding | Every quotation and span exact; every fact/step alternative grounded with normalized word boundaries; every nonprocedure required fact is its complete quoted sentence |
| Multi-document requests | 40 with two expected document IDs; conservatively 37 genuinely require two documents, exceeding the minimum of 30 |
| Ordered procedures | 20 complete four-action source sequences, but five leave an explicit textual parameter unresolved; 15 accepted as complete answer labels |
| Negatives | All 80 require refusal/review; no invalid partial-positive negative found |
| Curated conflicts | 10 current, authorized pairs with matching conflict_group values and mutually exclusive marker actions |
| Other conflicting_stale negatives | 10 current marking requests supported only by superseded version 1; refusal appropriate |
| Scope filters | 5; each question explicitly names the filtered document title; other cases use null |
| Rights/provenance | GroundTruth project / MIT / no third-party text; synthetic agent authorship and no human validation disclosed |

The 40 unanswerable cases comprise 20 absent current attributes, 10 private expansion allocations unavailable to viewer-a and 10 cross-workspace mirror references. The adversarial cases comprise five principal-impersonation requests, five cross-workspace overrides, five copied-message instruction attempts and five stale-version promotion attempts. Each requests an unavailable or unsupported fact, rather than a legitimate supported fact accompanied by unrelated malicious text. All 80 negative payloads have empty expected sources, facts and steps. Forbidden source references exist and are genuinely unauthorized or superseded; no authorized current source is forbidden merely for irrelevance.

## Material discrepancies

The five following labels copy all four displayed actions but omit the current fact that gives meaning to an explicitly referenced dwell, interval or count. Their expected quotations, acceptable answer spans and required facts can therefore be satisfied while leaving the requested complete procedure underspecified.

| Case | Unresolved action reference | Omitted fact available in the same current guide |
| --- | --- | --- |
| f03-p3 | specified dwell | Mica umbrella remains above its collection pan for **11 minutes** |
| f11-p3 | specified interval | Mallow wand is held above its tray for **5 seconds** before the pass |
| f14-p3 | specified number of times | Pith records **6 separate presses** per practice switch |
| f16-p3 | stated side-rest interval | Oxbow ends after the top remains on its side for **3 seconds** |
| f19-p3 | one complete reading interval | Cairn gauge readings occur at **17-minute** intervals |

Repair in a new authored revision by including the existing current parameter sentence in the expected quotation and required facts while retaining every ordered action. No source change is needed. This review treats physically marked gauges/stops and prepared inputs as the stated actions; it does not invent extra practical operating steps. The finding concerns explicit unresolved textual references to values already present in the same guide.

The following requests are not genuinely multi-document as worded. In each, one arrangements sentence names the role running/conducting the event and states its full schedule. The rationale that neither document contains the complete answer is therefore unsupported, and requiring an additional guide citation would reject a sufficient source-backed answer.

| Case | Single sufficient source | Source evidence |
| --- | --- | --- |
| f04-p4 | f04-arrangements, version 1 | Dune impression clerk runs a 25-minute session each Wednesday at 11:15 |
| f13-p4 | f13-arrangements, version 1 | Leto wheel tester conducts a 55-minute block at 10:05 on Wednesdays |
| f20-p4 | f20-arrangements, version 1 | Tern screen aligner runs Monday checks at 18:05 for 26 minutes |

Repair by asking for a fact exclusive to the guide, or use the sufficient arrangements document alone and stop counting the request as multi-document. The remaining conservative count of 37 still passes the corpus minimum.

## Checks and byte preservation

`report.json` contains the nine discrepancy records: eight label findings plus the resulting failure of the minimum of 20 complete-procedure labels. `checks.json` records every assertion in the final audit. Two independent-checker executions performed **12,374 assertion evaluations** in total; the final run performed **6,237**, with **6,220 passed** and **17 failed**. The 17 failures repeat the eight material label findings in both specific and full-label checks, plus the aggregate procedure-minimum failure; they are not 17 distinct defects. The first run's six-word minimum incorrectly flagged a meaningful five-word action twice; the checker was corrected and those false positives are excluded from the findings.

All ten author files remained byte-identical before and after the audit, including `FREEZE_SHA256.json`. Every hash listed in the manifest, author freeze and source snapshots verified. `raw-input-hashes.json` preserves the before/after inventory without rewriting any input. Key SHA256 values:

| File | SHA256 |
| --- | --- |
| documents.json | 614556917c30753edceb46891cdcf18d2335bf34d381b59a07b0f7809bea878e |
| cases.json | ff0b3eac1466897ca03713f08b328f90c80a0e59c22e6b5c8dc416ab3e597c7f |
| profile.json | 3d490c5be1e876f74fdd666c3d89868030322f068ae7a359b5e63f8d8a45273e |
| manifest.json | d02efd5494c32dcc9443dbcf8317867f941c33fa690e9189c41ac01108ed010f |

All writes are confined to `blind-v5-label-review`: this review, `report.json`, `checks.json`, `raw-input-hashes.json` and the independent `review_checks.py`. The frozen corpus must remain unchanged; any accepted repairs belong in a separately identified author revision followed by another independent review.

This is an agent's source-bound review of synthetic authored expectations. It is **not human validation, empirical model measurement or general-quality certification**. No statement about production behavior or universal contradiction detection follows from it.
