"""Inspect first comparison only after both immutable complete reports are sealed."""
from pathlib import Path
import hashlib, json, os, subprocess, sys

V=Path(__file__).resolve().parent;S=V.parent;W=S/'delivery-worktree';E=W/'docs/evidence/answer-coverage-v8'
P=W.parents[2]/'portfolio/groundtruth/.venv/Scripts/python.exe'
seal=json.loads((E/'first-comparison-seal.json').read_text())
assert seal['source_runtime_assets_corpus_unchanged'] and not seal['case_level_failure_inspection_before_seal']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for record in seal['reports']:
    assert sha(E/record['path'])==record['sha256']
    assert sha(S/record['path'])==record['sha256']
assert not (E/'comparison-gate.json').exists(),'Never overwrite complete results'
env=os.environ.copy();env['PYTHONPATH']=str(W/'apps/api');env['DATABASE_URL']='sqlite+aiosqlite:///:memory:'
command=[str(P),str(W/'scripts/verify_answer_coverage_delivery.py'),'--baseline',str(E/'first-baseline-blind-v5.json'),'--candidate',str(E/'first-candidate-blind-v5.json'),'--corpus-dir',str(S/'blind-v5-derived-v1')]
result=subprocess.run(command,cwd=W,env=env,capture_output=True)
(E/'comparison-gate.json').write_bytes(result.stdout)
(E/'comparison-gate.stderr.txt').write_bytes(result.stderr)
(E/'comparison-gate.json.sha256').write_bytes((sha(E/'comparison-gate.json')+'\n').encode())
record={'exit':result.returncode,'command':command,'scope':'First complete freshly authored synthetic comparison; both reports sealed before inspection.'}
(E/'comparison-command.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert result.returncode in [0,1], 'Comparison invalid; preserve all evidence and execution errors'
gate=json.loads(result.stdout)
print(json.dumps({'gate':gate['gate'],'exit':result.returncode,'methods':{m:{a:{k:values[a][k] for k in ['answerable_correct','answerable_total','negative_correct','negative_total','execution_errors','unauthorized_source_exposures','citation_integrity_failures','span_integrity_failures']} for a in ['baseline','candidate']} for m,values in gate['methods'].items()}},indent=2))
