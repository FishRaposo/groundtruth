"""First frozen HTTP comparison; seal BOTH complete reports before failure inspection."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,importlib.metadata,json,os,shutil,subprocess
V=Path(__file__).resolve().parent;S=V.parent;W=S/'delivery-worktree';P=W.parents[2]/'portfolio/groundtruth/.venv/Scripts/python.exe';E=W/'docs/evidence/answer-coverage-v8';C=S/'blind-v5-derived-v1'
def sha(path):
 d=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
 return d.hexdigest()
freeze=json.loads((E/'candidate-freeze.json').read_text());corpusfreeze=json.loads((E/'blind-corpus-freeze.json').read_text());baseline=json.loads((E/'baseline-source-binding.json').read_text())
def state_checks():
 issues=[]
 for n,h in freeze['source_files_sha256'].items():
  if sha(W/n)!=h:issues.append('candidate_source:'+n)
 for n,r in baseline['python_source'].items():
  if sha(S/'baseline-source'/n)!=r['observed_windows_sha256']:issues.append('baseline_source:'+n)
 for n,h in corpusfreeze['corpus_files'].items():
  if sha(C/n)!=h:issues.append('corpus:'+n)
 for n,v in freeze['runtime'].items():
  if n!='python' and importlib.metadata.version(n)!=v:issues.append('runtime:'+n)
 for label,root in [('reader_assets',S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'),('embedding_assets',W.parents[2]/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41')]:
  for n,h in freeze[label]['files'].items():
   if sha(root/n)!=h:issues.append(label+':'+n)
 return issues
assert not state_checks(),'Frozen premeasurement source/assets/runtime/corpus changed'
assert not (E/'first-comparison-seal.json').exists(),'Never overwrite first results'
documents=json.loads((C/'documents.json').read_text());cases=json.loads((C/'cases.json').read_text());ids={c['id'] for c in cases};assert len(ids)==200
for arm in ['baseline','candidate']:
 seed=json.loads((S/(arm+'-blind-v5')/'seed-manifest.json').read_text());assert seed['seed_status']=='complete'
 assert seed['corpus_manifest_sha256']==corpusfreeze['corpus_manifest_sha256']
 for d in documents:
  for v in d['versions']:assert seed['documents'][d['id']]['versions'][str(v['version_number'])]['content_hash']==v['content_hash']
env=os.environ.copy();env.update(PYTHONPATH=str(W/'apps/api'),DATABASE_URL='sqlite+aiosqlite:///:memory:',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKENIZERS_PARALLELISM='false')
for k in list(env):
 if k.startswith(('OPENAI_','ANTHROPIC_','AZURE_OPENAI_','GOOGLE_API','GEMINI_')):del env[k]
started=datetime.now(timezone.utc).isoformat()
def measure(arm):
 output=S/('first-'+arm+'-blind-v5.json');assert not output.exists()
 cmd=[str(P),str(W/'scripts/evaluate_portfolio_retrieval.py'),'--seed-manifest',str(S/(arm+'-blind-v5')/'seed-manifest.json'),'--corpus-dir',str(C),'--output',str(output),'--split','held_out','--method','all','--selection',str(E/'validation-binding.json'),'--execution-arm',arm]
 with (V/('first-'+arm+'-blind-v5.log')).open('wb') as f:r=subprocess.run(cmd,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert output.exists(),arm+' did not create a first complete report; preserve log/database'
 report=json.loads(output.read_text());assert set(report['results'])=={'keyword','vector','hybrid','reranked'}
 # Structural completeness only: no scores, outcomes, reasons or failure details
 # are inspected or emitted until both report byte streams have been sealed.
 for method in report['results'].values():assert len(method['cases'])==200 and {x['case_id'] for x in method['cases']}==ids
 assert report['execution_arm']==arm and report['corpus_manifest_sha256']==corpusfreeze['corpus_manifest_sha256']
 return {'arm':arm,'exit_code':r.returncode,'path':output.name,'sha256':sha(output),'command':cmd,'case_rows':800}
with ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(measure,['baseline','candidate']))
post_issues=state_checks()
for r in records:
 for suffix in ['', '.sha256']:
  destination=E/(r['path']+suffix);assert not destination.exists();shutil.copyfile(S/(r['path']+suffix),destination)
seal={'schema_version':1,'started_at':started,'sealed_at':datetime.now(timezone.utc).isoformat(),'candidate_commit':freeze['candidate_commit'],'candidate_freeze_sha256':sha(E/'candidate-freeze.json'),'binding_sha256':sha(E/'validation-binding.json'),'corpus_manifest_sha256':corpusfreeze['corpus_manifest_sha256'],'reports':records,'source_runtime_assets_corpus_unchanged':not post_issues,'post_state_issues':post_issues,'case_level_failure_inspection_before_seal':False,'scope':'First complete new blind measurements, synthetic authored labels; never replace failure or reuse exposed set as unseen.'}
body=(json.dumps(seal,indent=2)+'\n').encode();(E/'first-comparison-seal.json').write_bytes(body)
(E/'first-comparison-seal.json.sha256').write_bytes((hashlib.sha256(body).hexdigest()+'\n').encode())
print(json.dumps({'both_first_reports_sealed':True,'exit_codes':{r['arm']:r['exit_code'] for r in records},'post_state_issues':post_issues,'seal_sha256':hashlib.sha256(body).hexdigest()}),flush=True)
assert not post_issues,'First reports preserved/sealed with integrity qualification; inspect that separately'
