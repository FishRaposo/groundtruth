"""Preserve a rejected administrative preflight; never change frozen execution."""
from pathlib import Path
from datetime import datetime, timezone
from uuid import UUID
import hashlib, json, sqlite3, zipfile

S=Path(__file__).resolve().parent.parent;V=S/'coverage-v3';W=S/'delivery-worktree';E=W/'docs/evidence/answer-coverage-v8'
sha=lambda b:hashlib.sha256(b).hexdigest()
counts={}
for arm in ['baseline','candidate']:
    d=S/(arm+'-blind-v5');seed=json.loads((d/'seed-manifest.json').read_text())
    with sqlite3.connect('file:'+(d/'groundtruth.sqlite').as_posix()+'?mode=ro',uri=True) as db:
        counts[arm]={t:db.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in ['documents','chunks','queries']}
        rows=db.execute('SELECT id,outcome FROM queries').fetchall()
    assert len(rows)==1 and UUID(rows[0][0])==UUID(seed['legacy_query_id']) and rows[0][1] is None
    counts[arm].update(seed_legacy_history_rows=1, evaluated_case_rows=0)
    log=(V/('first-'+arm+'-blind-v5.log')).read_text(encoding='utf-8')
    assert log.strip()=='Evaluation unavailable: ValueError: Selection must reference frozen development evidence'
payload={}
for n in ['v5-first-comparison-controller.log','v5-execution-controller.log','first-baseline-blind-v5.log','first-candidate-blind-v5.log','execute_blind_v5.py','measure_blind_v5.py','runtime_blind_v5.py','v5-baseline-seed.log','v5-candidate-seed.log','v5-input-binding.log','bind_blind_v5_inputs.py']:
    payload[n]=(V/n).read_bytes()
for n in ['validation-binding.json','baseline-readiness.json','candidate-readiness.json']:payload['original/'+n]=(E/n).read_bytes()
payload['preflight-only-counts.json']=(json.dumps(counts,indent=2)+'\n').encode()
dest=E/'preflight-binding-reference-failure.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in payload.items():z.writestr(n,b)
    z.writestr('archive-file-hashes.json',json.dumps({n:sha(b) for n,b in payload.items()},indent=2)+'\n')
dest.with_suffix('.zip.sha256').write_bytes((sha(dest.read_bytes())+'\n').encode())
with zipfile.ZipFile(W/'docs/evidence/answer-coverage-v7/v14-current-development-engineering.zip') as z:
    body=z.read('prior-development-80-report.json')
    assert sha(body)==json.loads(z.read('archive-file-hashes.json'))['prior-development-80-report.json']
p=E/'frozen-development-full-report.json';assert not p.exists();p.write_bytes(body)
full=json.loads(body);freeze=json.loads((E/'candidate-freeze.json').read_text())
assert full['settings']==freeze['settings'] and full['split']=='development'
assert full['corpus_manifest_sha256']==freeze['development_corpus_manifest_sha256']
binding=json.loads((E/'validation-binding.json').read_text());old_sha=sha((E/'validation-binding.json').read_bytes())
binding.update(development_report_path=p.name,development_report_sha256=sha(body),binding_at=datetime.now(timezone.utc).isoformat())
(E/'validation-binding.json').write_bytes((json.dumps(binding,indent=2)+'\n').encode())
erratum={'recorded_at':datetime.now(timezone.utc).isoformat(),'failure':'Development summary supplied where the existing validator requires full development report. Both CLI preflights exited2 before QA requests.','prior_binding_sha256':old_sha,'corrected_binding_sha256':sha((E/'validation-binding.json').read_bytes()),'full_report_sha256':sha(body),'full_report_origin':'Exact pre-freeze E7 archive payload, not regenerated or remeasured','candidate_freeze_unchanged_sha256':sha((E/'candidate-freeze.json').read_bytes()),'database_counts_before_retry':counts,'source_settings_scorer_model_changes':False,'scope':'Administrative artifact reference repair only; all286 source/config paths and settings remain frozen before authoring.'}
(E/'binding-reference-correction.json').write_text(json.dumps(erratum,indent=2)+'\n',encoding='utf-8')
assert all(sha((W/n).read_bytes())==h for n,h in freeze['source_files_sha256'].items())
print(json.dumps({'preflight_only':True,'database_counts':counts,'original_freeze_unchanged':True,'corrected_report_ref':p.name}))
