"""Own only dedicated frozen processes; wait for independent corpus binding."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import json, os, socket, subprocess, time
import httpx

V=Path(__file__).resolve().parent; S=V.parent; W=S/'delivery-worktree'
P=W.parents[2]/'portfolio/groundtruth/.venv/Scripts/python.exe'
E=W/'docs/evidence/answer-coverage-v8'; runtime=V/'runtime_blind_v5.py'
marker=S/'blind-v5-approved-inputs.ready'
assert not (E/'first-comparison-seal.json').exists()
for port in [8401,8402]:
    with socket.socket() as sock:sock.bind(('127.0.0.1',port))
env=os.environ.copy()
for k in list(env):
    if k.startswith(('OPENAI_','ANTHROPIC_','AZURE_OPENAI_','GOOGLE_API','GEMINI_')):del env[k]
owned=[]
try:
    for arm,port in [('baseline',8401),('candidate',8402)]:
        log=(V/('v5-'+arm+'-api-attempt2.log')).open('wb')
        process=subprocess.Popen([str(P),str(runtime),'serve','--arm',arm],cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        owned.append((process,log))
        for _ in range(200):
            assert process.poll() is None,arm+' API exited'
            try:
                if httpx.get(f'http://127.0.0.1:{port}/api/health/live',timeout=1).status_code==200:break
            except httpx.HTTPError:pass
            time.sleep(.25)
        else:raise RuntimeError('API startup timeout')
        ready=httpx.get(f'http://127.0.0.1:{port}/api/health/ready',timeout=300);ready.raise_for_status()
        health=ready.json();assert health['status']=='ready'
        (E/(arm+'-readiness-attempt2.json')).write_text(json.dumps(health,indent=2)+'\n',encoding='utf-8')
        print(arm+' frozen API ready; no case queries sent.',flush=True)
    deadline=time.monotonic()+1800
    while not marker.exists():
        assert time.monotonic()<deadline,'Independent author/review/binding still pending; no evaluation executed'
        assert all(p.poll() is None for p,_ in owned)
        time.sleep(1)
    assert json.loads((E/'blind-corpus-freeze.json').read_text())['corpus_manifest_sha256']==marker.read_text().strip()
    for arm in ['baseline','candidate']:
        saved=json.loads((S/(arm+'-blind-v5')/'seed-manifest.json').read_text())
        assert saved['seed_status']=='complete' and saved['corpus_manifest_sha256']==marker.read_text().strip()
        print(arm+' reuses unchanged API-seeded data; no duplicate ingestion.',flush=True)
    with (V/'v5-first-comparison-controller-attempt2.log').open('wb') as log:
        result=subprocess.run([str(P),str(V/'measure_blind_v5_attempt2.py')],cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode==0,'Measurement controller failed; preserve partial reports and logs.'
    assert (E/'first-comparison-seal.json').exists()
    print('BOTH first complete reports sealed; scores may now be inspected.',flush=True)
finally:
    for p,log in owned:
        subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
        p.wait(timeout=30);log.close()
    print('Dedicated frozen API process trees stopped; owner services unchanged.',flush=True)
