"""Loopback-only frozen comparison runtime; no owner data, downloads or providers."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,json,os,subprocess
V=Path(__file__).resolve().parent;S=V.parent;W=S/'delivery-worktree';R=W.parents[2];P=R/'portfolio/groundtruth/.venv/Scripts/python.exe'
p=argparse.ArgumentParser();p.add_argument('action',choices=['migrate','serve','seed']);p.add_argument('--arm',choices=['baseline','candidate'],required=True);a=p.parse_args()
freeze=json.loads((W/'docs/evidence/answer-coverage-v8/candidate-freeze.json').read_text())
for n,h in freeze['source_files_sha256'].items():assert hashlib.sha256((W/n).read_bytes()).hexdigest()==h,'Frozen source changed '+n
for n,v in freeze['runtime'].items():
 if n!='python':assert importlib.metadata.version(n)==v,'Frozen runtime changed '+n
base=json.loads((V/'baseline-before-v4-preparation.json').read_text())
for n,v in base['python_source'].items():assert hashlib.sha256((S/'baseline-source'/n).read_bytes()).hexdigest()==v['observed_windows_sha256'],n
source=S/'baseline-source' if a.arm=='baseline' else W;port=8401 if a.arm=='baseline' else 8402;data=S/(a.arm+'-blind-v5');data.mkdir(exist_ok=True)
env=os.environ.copy()
for k in list(env):
 if k.startswith(('OPENAI_','ANTHROPIC_','AZURE_OPENAI_','GOOGLE_API','GEMINI_')):del env[k]
env.update(PYTHONPATH=str(source/'apps/api'),DATABASE_URL='sqlite+aiosqlite:///'+(data/'groundtruth.sqlite').as_posix(),STORAGE_ROOT=str(data/'uploads'),EMBEDDING_MODE='local',EMBEDDING_DIMENSIONS='384',LOCAL_MODEL_PATH=str(R/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41'),GENERATION_MODE='extractive',INGESTION_MODE='inline',AUTH_ENABLED='true',RATE_LIMIT_ENABLED='false',CONNECTED_REFUSAL_THRESHOLD=str(freeze['settings']['refusal_threshold']),ANSWER_SELECTION_MODE='lexical' if a.arm=='baseline' else 'reader',READER_MODEL_PATH=str(S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'),READER_MODEL_REVISION=freeze['settings']['reader_model_revision'],READER_NULL_THRESHOLD=str(freeze['settings']['reader_null_threshold']),APP_ENV='development',OPENAI_API_KEY='',CORS_ORIGINS='http://127.0.0.1:3506',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',TOKENIZERS_PARALLELISM='false')
if a.action=='migrate':command=[str(P),'-m','app.db.migrate']
elif a.action=='serve':command=[str(P),'-m','uvicorn','app.main:app','--host','127.0.0.1','--port',str(port),'--no-access-log']
else:
 # Trusted identity bootstrap uses matching frozen application models; documents
 # and every version are parsed/published by the actual arm's HTTP API.
 env['PYTHONPATH']=str(W/'apps/api')
 command=[str(P),str(W/'scripts/seed_portfolio.py'),'--api-url',f'http://127.0.0.1:{port}','--manifest',str(data/'seed-manifest.json'),'--corpus-dir',str(S/'blind-v5-derived-v1'),'--confirm-disposable-database']
raise SystemExit(subprocess.run(command,cwd=source,env=env,check=False).returncode)
