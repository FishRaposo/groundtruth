"""Freeze current candidate before clean independent authoring; never overwrite."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.metadata, json, subprocess, sys

V=Path(__file__).resolve().parent; S=V.parent; W=S/'delivery-worktree'
E=W/'docs/evidence/answer-coverage-v8'; D=W/'docs/evidence/answer-coverage-v7'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W).strip()
assert not (S/'blind-v5-author').exists(), 'New author must start after freeze'
assert not E.exists(), 'Never overwrite freeze'
observation=json.loads((D/'current-observation.json').read_text(encoding='utf-8'))
assert observation['reports']['exposed-v4-200']['reranked']['answerable_correct']==116
assert observation['reports']['exposed-v4-200']['reranked']['negative_correct']==80
before=json.loads((V/'v14-observations/source-after.json').read_text(encoding='utf-8'))
assert all(sha(W/n)==h for n,h in before.items())
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')
roots=('apps/api/app/','apps/api/tests/','apps/api/alembic/','apps/api/migrations/','scripts/','apps/web/src/','apps/web/e2e/')
fixed={'.gitattributes','.gitignore','Makefile','ruff.toml','apps/api/pyproject.toml','apps/web/package.json','apps/web/package-lock.json','apps/web/next.config.js','apps/web/eslint.config.mjs','apps/web/playwright.config.ts','apps/web/playwright.live.config.ts','apps/web/playwright.diagnostic.config.ts'}
names=sorted(n for n in tracked if n and (n in fixed or (n.startswith(roots) and Path(n).suffix in {'.py','.ts','.tsx','.css','.js','.mjs'})))
raw={}; canonical={}
for n in names:
    b=(W/n).read_bytes(); g=subprocess.check_output(['git','show','HEAD:'+n],cwd=W)
    assert b==g or b.replace(b'\r\n',b'\n')==g,n
    raw[n]=hashlib.sha256(b).hexdigest(); canonical[n]=hashlib.sha256(g).hexdigest()
def assets(root, manifest_name):
    m=json.loads((root/manifest_name).read_text(encoding='utf-8'))
    for n,h in m['files'].items():assert sha(root/n)==h,n
    return {**{k:m.get(k) for k in ['model','revision','license']},'files':m['files'],'manifest_sha256':sha(root/manifest_name),'remote_code':False,'request_downloads':False}
prior=json.loads((W/'docs/evidence/answer-coverage-v4/candidate-freeze.json').read_text())
profile=json.loads((V/'v14-observations/prior-development-80-report.json').read_text(encoding='utf-8'))
settings=profile['settings']
assert settings['reader_null_threshold']==4
frozen={
 'schema_version':2,'frozen_at':datetime.now(timezone.utc).isoformat(),
 'candidate_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),
 'baseline_commit':'e19006c9e8f1a11ef4930e24ed88128e765b6bf5',
 'selection_basis':'development_only','settings':settings,
 'development_corpus_manifest_sha256':profile['corpus_manifest_sha256'],
 'development_report_path':'../answer-coverage-v7/current-observation.json',
 'development_report_sha256':sha(D/'current-observation.json'),
 'observed_source_sha256':before,'source_files_sha256':raw,'git_source_files_sha256':canonical,
 'reader_assets':assets(S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4','groundtruth-reader.json'),
 'retained_minilm_assets':assets(S/'models/minilm-uncased-squad2--934656cdda79824eabf503ed56e15c01ddbdbe3f','groundtruth-reader.json'),
 'embedding_assets':assets(W.parents[2]/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41','groundtruth-model.json'),
 'fixed_reader_settings':{**prior['fixed_reader_settings'],'selection_contract':'reader-parts-v13','attribute_contract':'explicit-selected-clause-attribute-v2','witness_contract':'strongest-accepted-part-witness-v5'},
 'runtime':{'python':sys.version.split()[0],**{n:importlib.metadata.version(n) for n in ['torch','transformers','sentence-transformers','fastapi','sqlalchemy']}},
 'model_threshold_selection':{'basis':'Retained RoBERTa/threshold4 from predeclared previous development grids; no subsequent retuning. New source repairs used original80 and the now-exposed failed-v4 set.','matched_grid_sha256':sha(W/'docs/evidence/answer-coverage-v3/matched-readers-v7.json'),'exposed_regression':'116/120+80/80, not acceptance','development':'47/48+32/32 all four methods'},
 'engineering':observation['engineering'],
 'engineering_archive_sha256':sha(D/'v14-current-development-engineering.zip'),
 'packaging_lint_supplement_sha256':sha(D/'v14-packaging-lint-supplement.zip'),
 'author_contract_sha256':sha(S/'blind-v5-contract/CONTRACT.md'),
 'excluded_family_packet_sha256':sha(S/'blind-v5-contract/excluded-families.json'),
 'blind_state_at_freeze':'Not authored, no new cases inspected/executed. All earlier cases are exposed.',
 'allowed_after_freeze':'New independent source/case/profile artifacts and docs/evidence only; no app, test, scoring or configuration changes until both first reports sealed.',
 'quality_acceptance':'Pending first fresh200 comparison, default>=114/120 and improvement over baseline, all80 negatives, zero evidence/access errors. Synthetic authored labels, not human/model-general quality validation.',
 'owner_review':'8400/3505 not promoted; original checkout and database preserved.',
 'limitations':'No WSL/Docker, paid provider, generative model, hosting or publication; PostgreSQL/Redis/indexed performance deferred.'
}
E.mkdir()
body=(json.dumps(frozen,indent=2)+'\n').encode(); (E/'candidate-freeze.json').write_bytes(body)
(E/'candidate-freeze.json.sha256').write_bytes((hashlib.sha256(body).hexdigest()+'\n').encode())
print(json.dumps({'candidate_commit':frozen['candidate_commit'],'frozen_at':frozen['frozen_at'],'freeze_sha256':hashlib.sha256(body).hexdigest(),'source_files':len(raw),'author':'not started'}))
