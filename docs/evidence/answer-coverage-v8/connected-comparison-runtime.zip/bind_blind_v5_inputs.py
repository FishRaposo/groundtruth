"""Bind independently reviewed source-backed inputs without changing author bytes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, sys, zipfile

V=Path(__file__).resolve().parent; S=V.parent; W=S/'delivery-worktree'
A=S/'blind-v5-author-v2'; L=S/'blind-v5-label-review-v2'; E=W/'docs/evidence/answer-coverage-v8'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((E/'candidate-freeze.json').read_text())
af=json.loads((A/'FREEZE_SHA256.json').read_text())
review=json.loads((L/'report.json').read_text())
assert review['status']=='pass' and not review['discrepancies']
assert all(sha(W/n)==h for n,h in freeze['source_files_sha256'].items())
names=['documents.json','cases.json','profile.json','manifest.json']
for n in names:assert sha(A/n)==af['sha256'][n],n
assert datetime.fromisoformat(af['frozen_utc'])>datetime.fromisoformat(freeze['frozen_at'])
derived=S/'blind-v5-derived-v1'; derived.mkdir(exist_ok=False)
for n in names:shutil.copyfile(A/n,derived/n)
(derived/'profile.json').write_bytes((json.dumps(freeze['settings'],indent=2)+'\n').encode())
manifest=json.loads((derived/'manifest.json').read_text()); assert manifest['corpus_role']=='blind'
manifest['revision']+='-operational-bind-01'; manifest['files']['profile.json']=sha(derived/'profile.json')
(derived/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
assert all(sha(derived/n)==sha(A/n) for n in ['documents.json','cases.json'])
sys.path.insert(0,str(W/'apps/api'))
from app.portfolio import load_corpus
corpus=load_corpus(derived);assert len(corpus['cases'])==200
payload={p.relative_to(L).as_posix():p.read_bytes() for p in L.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
archive=E/'blind-independent-review.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in payload.items():z.writestr(n,b)
    z.writestr('archive-file-hashes.json',json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in payload.items()},indent=2)+'\n')
archive.with_suffix('.zip.sha256').write_bytes((sha(archive)+'\n').encode())
binding={'schema_version':2,'selection_basis':'development_only','development_corpus_manifest_sha256':freeze['development_corpus_manifest_sha256'],'validation_corpus_manifest_sha256':corpus['manifest']['manifest_sha256'],'development_report_path':freeze['development_report_path'],'development_report_sha256':freeze['development_report_sha256'],'candidate_freeze_path':'candidate-freeze.json','candidate_freeze_sha256':sha(E/'candidate-freeze.json'),'settings':freeze['settings'],'frozen_at':freeze['frozen_at'],'binding_at':datetime.now(timezone.utc).isoformat()}
p=E/'validation-binding.json';assert not p.exists();p.write_bytes((json.dumps(binding,indent=2)+'\n').encode())
record={'schema_version':1,'candidate_commit':freeze['candidate_commit'],'candidate_frozen_at':freeze['frozen_at'],'author_frozen_at':af['frozen_utc'],'bound_at':binding['binding_at'],'corpus_manifest_sha256':corpus['manifest']['manifest_sha256'],'author_manifest_sha256':sha(A/'manifest.json'),'corpus_files':{n:sha(derived/n) for n in names},'author_case_source_bytes_unchanged':True,'only_derived_changes':'Exactly frozen execution profile supplied; derived manifest profile hash/revision updated. Raw author source/question/label bytes unchanged and separately archived.','independent_review_sha256':sha(L/'report.json'),'independent_checks':review['total_check_executions'],'counts':{'cases':len(corpus['cases']),'documents':len(corpus['documents']),'snapshots':sum(len(d['versions']) for d in corpus['documents'])},'first_evaluation_state':'Not started; empty disposable migrated databases, no blind case queries sent','validity':'Synthetic agent-authored labels, independent agent review only; no human/general model-quality validation.'}
p=E/'blind-corpus-freeze.json';assert not p.exists();p.write_bytes((json.dumps(record,indent=2)+'\n').encode())
assert all(sha(W/n)==h for n,h in freeze['source_files_sha256'].items())
marker=S/'blind-v5-approved-inputs.ready'; assert not marker.exists()
marker.write_bytes((record['corpus_manifest_sha256']+'\n').encode())
print(json.dumps({'binding':'pass','counts':record['counts'],'independent_checks':record['independent_checks'],'case_source_bytes_unchanged':True,'source_unchanged':True,'manifest_sha256':record['corpus_manifest_sha256']}))
