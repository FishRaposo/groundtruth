"""Source-faithful label-only revision; no application or model execution."""
import collections
import copy
import datetime
import hashlib
import json
import pathlib
import re

ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT.parent/'blind-v5-author'
REVIEW=ROOT.parent/'blind-v5-label-review'
PACKET=ROOT.parent/'blind-v5-contract'
REV='independent-operational-blind-v5-20261024-author2-label-correction'

def sha(b): return hashlib.sha256(b).hexdigest()
def norm(s): return re.sub(r'\s+',' ',s).strip()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(name,obj):
    (ROOT/name).write_bytes((json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    return sha((ROOT/name).read_bytes())
def phrase(p,t): return bool(re.search(r'(?<!\w)'+re.escape(norm(p).lower())+r'(?!\w)',norm(t).lower()))

old_inventory={p.name:sha(p.read_bytes()) for p in OLD.iterdir() if p.is_file()}
review_inventory={name:sha((REVIEW/name).read_bytes()) for name in ['REVIEW.md','report.json']}
report=read(REVIEW/'report.json')
old_manifest=read(OLD/'manifest.json')
assert report['status']=='fail'
for name,digest in report['verified_file_hashes'].items(): assert old_inventory[name]==digest
docs=read(OLD/'documents.json')
old_cases=read(OLD/'cases.json')
cases=copy.deepcopy(old_cases)
bycase={c['id']:c for c in cases}
bydoc={d['id']:d for d in docs}
changes=[]

for finding in report['discrepancies']:
    code=finding['code']
    if code=='omitted_procedure_parameter':
        c=bycase[finding['subject']]
        parameter=finding['missing_current_fact']
        d=bydoc[finding['document_id']]
        es=c['expected_sources'][0]
        original_procedure=es['quoted_text']
        content=d['versions'][-1]['content']
        start=content.index(parameter)
        end=content.index(original_procedure)+len(original_procedure)
        assert start<end and parameter in content and original_procedure in content
        es['quoted_text']=content[start:end]
        es['acceptable_answer_spans']=[parameter,original_procedure]
        c['required_facts'].append([parameter])
        c['label_rationale']='Current published immutable guide version 2 is authorized for this principal. The complete answer must copy all four ordered actions without omission or reordering and also copy the current parameter sentence that resolves the procedure\'s explicit dwell, interval or count reference. The parameter is part of the requested complete procedure; no new action or source fact is invented.'
        changes.append({'case_id':c['id'],'kind':code,'changed_fields':['expected_sources.quoted_text','expected_sources.acceptable_answer_spans','required_facts','label_rationale'],'source_evidence':{'document_id':d['id'],'version_number':2,'content_hash':d['versions'][-1]['content_hash'],'added_parameter_sentence':parameter,'resolved_step':finding['dangling_step']},'reason':'Include the existing current value referenced by the ordered procedure; retain all four original ordered actions and every source/question byte.'})
    elif code=='unnecessary_expected_document':
        c=bycase[finding['subject']]
        sufficient=finding['single_document_sufficient']
        removed=[es['document_id'] for es in c['expected_sources'] if es['document_id']!=sufficient]
        c['expected_sources']=[es for es in c['expected_sources'] if es['document_id']==sufficient]
        assert len(c['expected_sources'])==1
        quote=finding['sufficient_quote']
        assert c['expected_sources'][0]['quoted_text']==quote
        c['required_facts']=[[quote]]
        c['label_rationale']='The current authorized arrangements sentence names the role performing the event and gives its complete schedule, answering the broadly worded role-and-session request by itself. Require only this sufficient arrangements source and its complete role-and-schedule fact. The guide is authorized but unnecessary, is not forbidden, and this case is counted as single-document.'
        changes.append({'case_id':c['id'],'kind':code,'changed_fields':['expected_sources','required_facts','label_rationale'],'source_evidence':{'document_id':sufficient,'version_number':1,'content_hash':bydoc[sufficient]['versions'][-1]['content_hash'],'sufficient_sentence':quote},'removed_unnecessary_expected_sources':removed,'reason':'One existing arrangements sentence fully answers the unchanged question. Remove the unnecessary guide requirement and count this as single-document.'})

assert len(changes)==8
changed_ids={x['case_id'] for x in changes}
assert changed_ids=={'f03-p3','f11-p3','f14-p3','f16-p3','f19-p3','f04-p4','f13-p4','f20-p4'}
assert len(cases)==200 and len(bycase)==200 and len(bydoc)==105
assert len({c['question'] for c in cases})==200
assert collections.Counter(c['category'] for c in cases)=={'answerable':120,'unanswerable':40,'conflicting_stale':20,'adversarial':20}
assert len({d['family'] for d in docs})==20
excluded=read(PACKET/'excluded-families.json')
assert not {d['family'] for d in docs}&{x['family'] for x in excluded['excluded']}
principals=old_manifest['principals']
def readable(d,p): return d['workspace_id']==principals[p]['workspace_id'] and (d['visibility']!='private' or d['owner']==p)

for before,after in zip(old_cases,cases):
    assert before['id']==after['id'] and before['question'].encode('utf-8')==after['question'].encode('utf-8')
    if before['id'] not in changed_ids: assert before==after
    else:
        assert before['ordered_steps']==after['ordered_steps']
        assert {k:v for k,v in before.items() if k not in ('expected_sources','required_facts','label_rationale')}=={k:v for k,v in after.items() if k not in ('expected_sources','required_facts','label_rationale')}

for d in docs:
    assert d['split']=='held_out' and d['owner'] in principals
    assert d['workspace_id']==principals[d['owner']]['workspace_id']
    assert [v['version_number'] for v in d['versions']]==list(range(1,d['current_version_number']+1))
    for v in d['versions']:
        assert norm(v['content'])==v['content']
        assert sha(v['content'].encode('utf-8'))==v['content_hash']

multi=procedures=0
for c in cases:
    assert c['split']=='held_out' and c['family'] in {d['family'] for d in docs}
    assert c['principal'] in principals and c['score_contract']=='coverage-v2'
    assert c['label_author'] and c['label_status'] and c['label_rationale']
    if c['document_ids'] is not None:
        assert 'Limit the answer to the document titled' in c['question']
        assert all(x in bydoc for x in c['document_ids'])
    for f in c['forbidden_sources']:
        d=bydoc[f['document_id']]
        assert d['split']==c['split'] and 1<=f['version_number']<=d['current_version_number']
        assert f['version_number']<d['current_version_number'] or not readable(d,c['principal'])
    if c['category']!='answerable':
        assert c['expected_behavior'] in ('refuse','review')
        assert c['expected_sources']==c['required_facts']==c['ordered_steps']==[]
        continue
    assert c['expected_behavior']=='answer' and c['required_facts']
    quotes=[]
    ids=[]
    for es in c['expected_sources']:
        d=bydoc[es['document_id']];v=d['versions'][-1]
        assert d['family']==c['family'] and d['split']==c['split'] and readable(d,c['principal'])
        assert es['version_number']==v['version_number'] and es['content_hash']==v['content_hash']
        assert es['quoted_text'] and es['quoted_text'] in v['content']
        assert es['acceptable_answer_spans'] and all(s and s in es['quoted_text'] for s in es['acceptable_answer_spans'])
        assert any(any(phrase(a,es['quoted_text']) for a in g) for g in c['required_facts'])
        if c['document_ids'] is not None: assert d['id'] in c['document_ids']
        assert not any(f['document_id']==d['id'] and f['version_number']==v['version_number'] for f in c['forbidden_sources'])
        quotes.append(es['quoted_text']);ids.append(d['id'])
    assert len(ids)==len(set(ids))
    for groups in (c['required_facts'],c['ordered_steps']):
        for g in groups:
            assert g and all(a and any(phrase(a,q) for q in quotes) for a in g)
    if len(ids)>1:
        multi+=1
        for j,q in enumerate(quotes):
            assert any(any(phrase(a,q) and not any(phrase(a,other) for n,other in enumerate(quotes) if j!=n) for a in g) for g in c['required_facts'])
    if c['ordered_steps']:
        procedures+=1
        assert len(c['ordered_steps'])==4
        q=' '.join(quotes)
        positions=[q.index(g[0]) for g in c['ordered_steps']]
        assert positions==sorted(positions)
        # Explicit textual parameter references must resolve in a required fact.
        if any(any(term in a.lower() for term in ['specified dwell','specified interval','specified number','stated side-rest interval','one complete reading interval']) for g in c['ordered_steps'] for a in g):
            finding=next(f for f in report['discrepancies'] if f['subject']==c['id'] and f['code']=='omitted_procedure_parameter')
            parameter=finding['missing_current_fact']
            assert [parameter] in c['required_facts']
            assert any(parameter in span for es in c['expected_sources'] for span in es['acceptable_answer_spans'])
assert multi==37 and procedures==20
assert sum(c['expected_behavior']=='review' for c in cases)==10
assert sum(c['document_ids'] is not None for c in cases)==5
conflicts=collections.defaultdict(list)
for d in docs:
    if 'conflict_group' in d['metadata']: conflicts[d['metadata']['conflict_group']].append(d)
assert len(conflicts)==10 and all(len(ds)==2 for ds in conflicts.values())

# Preserve source file bytes, including formatting and every snapshot, exactly.
(ROOT/'documents.json').write_bytes((OLD/'documents.json').read_bytes())
assert (ROOT/'documents.json').read_bytes()==(OLD/'documents.json').read_bytes()
files={'documents.json':sha((ROOT/'documents.json').read_bytes()),'cases.json':write('cases.json',cases),'profile.json':write('profile.json',{'schema_version':2,'revision':REV,'note':'Execution configuration is supplied separately by the integration owner.'})}
now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
manifest=copy.deepcopy(old_manifest)
manifest.update(revision=REV,created_date=now[:10],authorship='Independent synthetic author-agent revision 2: source-faithful corrections to eight labels following a premeasurement independent source-only review. All source bytes and all 200 question identities and bytes are unchanged. No human validation or app/model execution.',validity='Unmeasured source-backed authored expectations. Eight author-label defects corrected using existing current snapshots and the independent source-only review; not human validated, not a human gold standard or a general factual-entailment certification.',files=files)
manifest_sha=write('manifest.json',manifest)
write('CHANGE_MANIFEST.json',{'revision':REV,'prior_revision':old_manifest['revision'],'prior_manifest_sha256':old_inventory['manifest.json'],'review_sha256':review_inventory,'premeasurement_only':True,'changes':changes,'preservation':{'documents_json_byte_identical':True,'all_200_source_and_question_identities_preserved':True,'all_200_question_utf8_values_byte_identical':True,'original_ordered_steps_preserved':True,'unchanged_case_records':192,'changed_label_records':8,'original_author_directory_unmodified':True,'old_failed_review_unmodified':True},'composition':{'genuine_necessary_multidocument_positives':37,'complete_ordered_procedures':20},'authorship':'Synthetic independent author-agent source/label corrections; no human validation, no measurement or algorithm-specific changes.'})
check_report={'status':'passed','cases':200,'counts':dict(collections.Counter(c['category'] for c in cases)),'logical_documents':105,'immutable_snapshots':125,'families':20,'genuine_necessary_multidocument_positives':multi,'complete_four_action_procedures_with_explicit_textual_parameters_resolved':procedures,'corrected_parameter_labels':5,'corrected_unnecessary_source_labels':3,'all_200_label_authority_and_grounding_rechecked':True,'unchanged_case_records':192,'unchanged_question_bytes':200,'unchanged_source_file_bytes':True,'checks':['Category counts and unique case, document and question identities','Source-family split and exact exclusion-id disjointness; prior semantic review retained','Current source hash, contiguous versions, canonical whitespace and exact quotations/spans','Principal workspace and private-source authority, explicit scope, forbidden-source relevance','Every required fact and ordered step alternative grounded with normalized word boundaries','Complete preserved four-action sequences plus all five explicitly referenced parameter sentences','Three sufficient single-source answers no longer require guide citation; 37 necessary multi-document labels remain','All 80 negative labels and behaviors unchanged; no supported-partial negative introduced','Only eight labels changed in their expected sources, required facts and rationale','Original complete author inventory and original failed review bytes preserved'],'limitations':['Synthetic author consistency checks and source-bound review are not human validation or a general entailment certification.','Physical marked gauges/stops and prepared inputs are preserved as source actions, without inventing extra practical steps.','No application, evaluation harness, model, API, network or execution settings were accessed or run.']}
write('author-checks.json',check_report)
write('FREEZE_SHA256.json',{'frozen_utc':now,'sha256':{**files,'manifest.json':manifest_sha}})
assert all(sha((ROOT/name).read_bytes())==digest for name,digest in read(ROOT/'FREEZE_SHA256.json')['sha256'].items())
assert read(ROOT/'documents.json')==docs and read(ROOT/'cases.json')==cases
assert {p.name:sha(p.read_bytes()) for p in OLD.iterdir() if p.is_file()}==old_inventory
assert {name:sha((REVIEW/name).read_bytes()) for name in review_inventory}==review_inventory
write('PRESERVATION_HASHES.json',{'original_author_directory':old_inventory,'old_failed_review':review_inventory,'verified_unchanged_after_revision':True})
(ROOT/'AUTHOR_HANDOFF.md').write_bytes(f'''# AUTHOR_HANDOFF - corrected author revision 2

Frozen at {now}, before any application, model, API or evaluation execution. Raw manifest SHA256: `{manifest_sha}`.

Exactly 200 cases: 120 answerable, 40 unanswerable, 20 conflicting_stale and 20 adversarial; 20 fresh semantic families; 105 logical documents and 125 snapshots. Corrected composition: 37 genuinely necessary multi-document positives and 20 complete four-action procedures with all explicitly referenced textual parameters included.

Eight source-faithful label corrections are recorded individually with current source evidence in CHANGE_MANIFEST.json. Five procedure labels now include the already published parameter sentence in their quotation, acceptable spans and required facts. Three role-and-session labels now require only their sufficient arrangements source. No questions, sources, identities, permissions, step order or negative labels changed; 192 complete case records remain identical.

The original author directory and old failed review remain byte-for-byte unchanged, checked against their original inventory; see PRESERVATION_HASHES.json. The original defects are accepted, not defended. This revision supersedes their labels without rewriting their evidence.

All 200 label authority, grounded facts/steps, current version/hash, permissions, scope, counts, identity and quotation checks passed. Documents are copied byte-for-byte; all question UTF-8 values are byte-identical. FREEZE_SHA256.json freezes the four input files. author-checks.json records checks and limits. Ownership: GroundTruth project, MIT, no third-party content. Synthetic agent-authored expectations, not human validated or a general factual-entailment certification. Execution configuration is supplied separately by the integration owner.
'''.encode('utf-8'))
print(json.dumps({'status':'passed','corrected_labels':8,'multidocument':multi,'complete_procedures':procedures,'original_bytes_preserved':True,'frozen_utc':now,'manifest_sha256':manifest_sha},indent=2))
