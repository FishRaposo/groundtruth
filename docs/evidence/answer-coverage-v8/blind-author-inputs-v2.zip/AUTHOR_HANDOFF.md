# AUTHOR_HANDOFF - corrected author revision 2

Frozen at 2026-10-24T13:21:20+00:00, before any application, model, API or evaluation execution. Raw manifest SHA256: `301e64f002387cf69eb47e213782ab93ddbb58e7ca631c06739e7c1435339301`.

Exactly 200 cases: 120 answerable, 40 unanswerable, 20 conflicting_stale and 20 adversarial; 20 fresh semantic families; 105 logical documents and 125 snapshots. Corrected composition: 37 genuinely necessary multi-document positives and 20 complete four-action procedures with all explicitly referenced textual parameters included.

Eight source-faithful label corrections are recorded individually with current source evidence in CHANGE_MANIFEST.json. Five procedure labels now include the already published parameter sentence in their quotation, acceptable spans and required facts. Three role-and-session labels now require only their sufficient arrangements source. No questions, sources, identities, permissions, step order or negative labels changed; 192 complete case records remain identical.

The original author directory and old failed review remain byte-for-byte unchanged, checked against their original inventory; see PRESERVATION_HASHES.json. The original defects are accepted, not defended. This revision supersedes their labels without rewriting their evidence.

All 200 label authority, grounded facts/steps, current version/hash, permissions, scope, counts, identity and quotation checks passed. Documents are copied byte-for-byte; all question UTF-8 values are byte-identical. FREEZE_SHA256.json freezes the four input files. author-checks.json records checks and limits. Ownership: GroundTruth project, MIT, no third-party content. Synthetic agent-authored expectations, not human validated or a general factual-entailment certification. Execution configuration is supplied separately by the integration owner.
