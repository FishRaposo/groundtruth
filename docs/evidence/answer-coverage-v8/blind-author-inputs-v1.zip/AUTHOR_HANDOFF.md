# AUTHOR_HANDOFF

Frozen at 2026-10-24T13:14:08+00:00, before any measurement. Candidate freeze was stated as recorded before author dispatch; the author did not inspect implementation, settings, earlier cases, results, repository context, memory, agents or chats.

200 held_out / blind cases: 120 answerable, 40 unanswerable, 20 conflicting_stale (10 curated conflicts and 10 unsupported-current stale claims), 20 adversarial. 20 fresh semantic families; 105 logical documents; 40 genuine two-document positives; 20 full four-step ordered procedures. Public, organization and private snapshots span ops-a and ops-b. Four families have owner-only positive guide facts. Five positive questions explicitly declare document scope; all other searches use null document_ids.

Raw author manifest SHA256: `d02efd5494c32dcc9443dbcf8317867f941c33fa690e9189c41ac01108ed010f`.

The four delivery files are documents.json, cases.json, profile.json and manifest.json. AUTHOR_FREEZE.json freezes their exact UTF-8 LF byte hashes and the author script, checks and notes. The manifest contains exactly the three contracted data-file hashes. The integration owner may supply execution configuration separately, preserving these source/question/label bytes and this raw author manifest.

Standard-library checks passed: exact counts; unique ids and questions; held_out family references; source ownership and workspace visibility; contiguous complete snapshots; canonical whitespace and SHA256; exact current quotations and acceptable spans; all required-fact and step alternatives with normalized word boundaries; a discriminating necessary fact in every cited document; two-source necessity for every multi-document case; all four ordered actions in each procedure; forbidden sources actually stale or unauthorized; ten incompatible same-group current conflict pairs; negative labels contain no supported partial request; explicit scope only when requested; family-id exclusion and authored subject-matter review. See author-checks.json and label-review-notes.json. All 200 labels were reviewed through the authored evidence plan plus these source checks.

Limitations: synthetic agent-authored, not human validated or a factual-entailment certification. No app, model, API, network or evaluation was executed. Semantic disjointness includes an author subject review, not a formal universal semantic proof. No real credentials, personal information, third-party content or professional advice. Ownership: GroundTruth project; MIT.
