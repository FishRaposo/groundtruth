"""Dependency-free evidence policy; safe to import during Settings creation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, get_args

if TYPE_CHECKING:
    from app.config import Settings

ProposalProfile = Literal["qa_only_v1", "qa_plus_source_patterns_v1"]
RoleScopePolicy = Literal["literal_v1", "ordinary_session_activity_v1"]
CURRENT_CONTRACT = "requirement-evidence-v2"
KNOWN_CONTRACTS = frozenset({"requirement-evidence-v1", CURRENT_CONTRACT})
PROFILE_CONTRACT = "evidence-profile-v1"
ORIGIN_CONTRACT = "proposal-origin-v1"
ROLE_POLICY_CONTRACT = "ordinary-session-activity-role-v1"
PATTERN_REGISTRY_CONTRACT = "typed-source-patterns-v1"
MAX_PATTERN_PROPOSALS_PER_SOURCE = 3
MAX_PATTERN_PROPOSALS_PER_REQUIREMENT = 16


def source_free_pattern_budget(row: Any) -> bool:
    """An exact typed request count contains neither source identity nor content."""
    return (
        isinstance(row, dict)
        and set(row)
        == {
            "requirement_id",
            "origin",
            "decision",
            "observed_count",
            "complete",
            "truncated",
        }
        and isinstance(row.get("requirement_id"), str)
        and bool(row["requirement_id"])
        and row.get("origin") == "source_pattern"
        and row.get("decision") == "pattern_requirement_budget_exceeded"
        and type(row.get("observed_count")) is int
        and row["observed_count"] > MAX_PATTERN_PROPOSALS_PER_REQUIREMENT
        and row.get("complete") is False
        and row.get("truncated") is True
    )


def validate_evidence_engines(
    proposal: ProposalProfile, role: RoleScopePolicy, reader: str, support: str
) -> None:
    if proposal not in get_args(ProposalProfile) or role not in get_args(
        RoleScopePolicy
    ):
        raise ValueError("Unknown evidence proposal profile or role scope policy")
    expanded = proposal != "qa_only_v1" or role != "literal_v1"
    if expanded and (reader != "reader" or support != "local_nli"):
        raise ValueError(
            "Expanded evidence profiles require the local QA reader and local_nli; "
            "source patterns and scope policy cannot bypass either engine"
        )


@dataclass(frozen=True)
class EvidencePolicy:
    proposal_profile: ProposalProfile
    role_scope_policy: RoleScopePolicy

    @property
    def source_patterns(self) -> bool:
        return self.proposal_profile == "qa_plus_source_patterns_v1"

    @property
    def activity_roles(self) -> bool:
        return self.role_scope_policy == "ordinary_session_activity_v1"

    def record(self) -> dict[str, object]:
        return {
            "contract": PROFILE_CONTRACT,
            "proposal_profile": self.proposal_profile,
            "role_scope_policy": self.role_scope_policy,
            "origin_contract": ORIGIN_CONTRACT,
            "role_policy_contract": ROLE_POLICY_CONTRACT,
            "pattern_registry_contract": PATTERN_REGISTRY_CONTRACT
            if self.source_patterns
            else "disabled",
            "pattern_limits": {
                "per_source_requirement": MAX_PATTERN_PROPOSALS_PER_SOURCE,
                "per_requirement": MAX_PATTERN_PROPOSALS_PER_REQUIREMENT,
            },
        }


def resolve_evidence_policy(config: Settings) -> EvidencePolicy:
    """Capture controls once per request, including mutable library Settings."""
    validate_evidence_engines(
        config.ANSWER_PROPOSAL_PROFILE,
        config.ROLE_SCOPE_POLICY,
        config.ANSWER_SELECTION_MODE,
        config.ANSWER_SUPPORT_MODE,
    )
    return EvidencePolicy(config.ANSWER_PROPOSAL_PROFILE, config.ROLE_SCOPE_POLICY)
