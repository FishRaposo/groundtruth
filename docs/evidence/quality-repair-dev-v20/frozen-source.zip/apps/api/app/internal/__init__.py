"""GroundTruth internal implementation details."""
