"""Body-only conflict relevance for two temporal attributes, never support.

Unknown scope is not permission, entailment, an actor alias or group inheritance.
The controller separately owns applicability, model decisions and authorization.
"""

from __future__ import annotations

import re
from dataclasses import replace

from app.services import requirement_binding as binding
from app.services.answer_requirements import Requirement, _requirement_anchors

_PREFIX = re.compile(r"^\s*for\s+([^,;:.!?]+)[,:]\s*", re.I)
_BREAK = re.compile(
    r"[.!?;\n]|\s+(?:and|but|whereas|while)\s+"
    r"(?!(?:may|is|are)\b)",
    re.I,
)
_COVER = r"may(?:\s+not)?\s+(?:substitute|cover)"
_PRESENCE = r"(?:is|are)\s+(?:not\s+)?(?:available|present)"
_AVAILABILITY = re.compile(
    rf"(?P<actor>.+?)\s+(?P<predicate>{_COVER}|{_PRESENCE})\b(?P<tail>.*)",
    re.I,
)
_COORDINATED_COVER = re.compile(
    rf"(?P<actor>.+?)\s+is\s+(?:the\s+)?deputy\s+for\s+"
    rf"(?P<activity>.+?)\s+and\s+(?P<predicate>{_COVER})\b(?P<tail>.*)",
    re.I,
)
_TARGET = re.compile(r"\s+(?:for|during|in)\s+(.+?)(?=\s+(?:only|on|from)\b|$)", re.I)
_START = re.compile(r"(?P<activity>.+?)\s+(?:starts?|begins?)\b(?P<tail>.*)", re.I)
_ARRIVAL = re.compile(
    r"^(?:(?:the|its)\s+)?(?:arrival|check[ -]in)\s+(?:time|window)\b", re.I
)
_UNRESOLVED_ACTOR = frozenset(
    {"it", "they", "this", "that", "the role", "role", "deputy", "owner", "person"}
)
_DAY = r"(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)s?"
_CLOCK = r"\d{1,2}:\d{2}(?:\s*[ap]m)?"
_TEMPORAL_VALUE = re.compile(
    rf"\b(?:{_DAY}|{_CLOCK}|noon|midnight|morning|afternoon|evening|dawn|dusk)\b",
    re.I,
)
_TEMPORAL_TAIL = re.compile(
    rf"(?:\s|,|{_CLOCK}\b|{_DAY}\b|\d+\b|"
    r"\b(?:only|on|from|to|until|through|between|at|not|every|each|any|time|"
    r"noon|midnight|morning|afternoon|evening|dawn|dusk|am|pm|utc|"
    r"hours?|minutes?|seconds?)\b)*",
    re.I,
)
_FIELD_LABEL = re.compile(
    r"(?:these|those|this|that)\s+(?:is|are)\s+(?P<actor>.+?)['’]s\s+"
    r"(?P<field>cover\s+hours|duty\s+hours|availability|start\s+time|opening\s+time)",
    re.I,
)


def _canonical(text: str) -> str:
    return binding._canonical_argument(" ".join(text.split()))


def _nominal_subject(text: str) -> bool:
    # A typed subject cannot swallow an earlier unparsed statement or clock.
    return bool(re.fullmatch(r"[\w'’-]+(?:\s+[\w'’-]+)*", text.strip())) and not bool(
        re.search(
            r"\b(?:is|are|was|were|has|have|may|can|scheduled|assigned|"
            r"if|when|unless|except|not|no|only)\b",
            text,
            re.I,
        )
    )


def _complete_temporal_tail(tail: str) -> bool:
    target = _TARGET.search(tail)
    if target is not None:
        if not _nominal_subject(target.group(1)):
            return False
        tail = tail[: target.start()] + " " + tail[target.end() :]
    return _TEMPORAL_TAIL.fullmatch(tail) is not None


def _unparsed_statement_scope(req: Requirement, body: str) -> str | None:
    label = _FIELD_LABEL.fullmatch(body)
    if label is not None and _nominal_subject(label.group("actor")):
        cover = label.group("field").casefold() in {
            "cover hours",
            "duty hours",
            "availability",
        }
        if cover == (req.kind == "availability"):
            actor = (
                _actor_scope(label.group("actor"), req.topic)
                if req.kind == "availability"
                else _activity_scope(req, label.group("actor"), req.topic)
            )
            return "irrelevant" if actor == "irrelevant" else "unknown"
    fields = (
        r"\b(?:availability|available|present|hours?|cover|substitut\w*|duty|"
        r"schedule\w*|reliev\w*)\b"
        if req.kind == "availability"
        else r"\b(?:starts?|begins?|scheduled|opening|commences?|kickoff)\b"
    )
    incidental = re.fullmatch(
        r"(?P<subject>.+?)\s+(?:archives?|stores?)\s+(?P<object>.+)", body, re.I
    )
    # Discard only a completely parsed non-temporal incidental statement. Every
    # other unparsed statement remains possible field evidence, including novel
    # paraphrases without familiar keywords, clocks or an explicit actor.
    if (
        incidental is not None
        and _nominal_subject(incidental.group("subject"))
        and _nominal_subject(incidental.group("object"))
        and not _TEMPORAL_VALUE.search(body)
        and not re.search(fields, body, re.I)
    ):
        return None
    return "unknown"


def _scope_and_body(clause: str) -> tuple[str | None, str]:
    prefix = _PREFIX.match(clause)
    return (
        (prefix.group(1), clause[prefix.end() :].strip())
        if prefix
        else (None, clause.strip())
    )


def _activity_scope(req: Requirement, actual: str, expected: str) -> str:
    # Reuse the existing canonical activity/namespace authority. In particular,
    # an abbreviated session or missing condition remains unknown, not an alias.
    scoped = replace(req, topic=expected, anchors=_requirement_anchors(expected))
    return binding._scope_target(scoped, actual)


def _actor_scope(actor: str, expected: str) -> str:
    actual = _canonical(actor)
    if actual in _UNRESOLVED_ACTOR or _canonical(expected) in _UNRESOLVED_ACTOR:
        return "unknown"
    if actual == _canonical(expected):
        return "applies"
    if re.search(r"[,;:]|\b(?:and|but|if|when)\b", actor, re.I):
        return "unknown"
    return "irrelevant"


def _availability_scope(req: Requirement, scope: str | None, body: str) -> str | None:
    event = _COORDINATED_COVER.fullmatch(body)
    linked = event.group("activity") if event else None
    event = event or _AVAILABILITY.fullmatch(body)
    if event is None:
        return None
    if not _nominal_subject(event.group("actor")) or not _complete_temporal_tail(
        event.group("tail")
    ):
        return "unknown"
    actor = _actor_scope(event.group("actor"), req.topic)
    if actor != "applies":
        return actor
    cover = event.group("predicate").casefold().startswith("may")
    if cover != (req.relation == "cover_window"):
        return "irrelevant"  # Presence and cover permission are different fields.
    expected, _ = _scope_and_body(req.question)
    if expected is None:
        return "applies"
    target = _TARGET.search(event.group("tail"))
    scopes = [
        value for value in (scope, linked, target.group(1) if target else None) if value
    ]
    if not scopes:
        return "unknown"
    decisions = [_activity_scope(req, value, expected) for value in scopes]
    if "irrelevant" in decisions:
        return "irrelevant"
    return "applies" if all(value == "applies" for value in decisions) else "unknown"


def _start_scope(req: Requirement, scope: str | None, body: str) -> str | None:
    event = _START.fullmatch(body)
    if event is None:
        arrival = _ARRIVAL.match(body)
        tail = body[arrival.end() :] if arrival else ""
        tail = re.sub(r"^\s*(?:is|are)\b", "", tail, flags=re.I)
        return "irrelevant" if arrival and _complete_temporal_tail(tail) else None
    target = event.group("activity")
    if not _nominal_subject(target) or not _complete_temporal_tail(event.group("tail")):
        return "unknown"
    if scope and _activity_scope(req, scope, req.topic) == "irrelevant":
        return "irrelevant"
    if _canonical(target) == _canonical(req.topic):
        return "applies"
    if _ARRIVAL.match(target):
        return "irrelevant"
    if _canonical(target) in {"session", "it", "its session"}:
        return _activity_scope(req, scope, req.topic) if scope else "unknown"
    result = _activity_scope(req, target, req.topic)
    return result


def source_relation_scope(req: Requirement, content: str) -> str:
    """Classify body relation scope without proving facts or inheriting a role.

    Only availability and session start are added here. Existing typed kinds
    retain their binding authority; every other grammar remains unknown.
    """
    if req.kind in {"owner", "deputy", "procedure"}:
        return binding.source_relation_scope(req, content)
    if req.kind not in {"availability", "start_time"}:
        return "unknown"
    decisions = []
    for clause in _BREAK.split(content):
        scope, body = _scope_and_body(clause.strip())
        if not body:
            continue
        decision = (
            _availability_scope(req, scope, body)
            if req.kind == "availability"
            else _start_scope(req, scope, body)
        )
        if decision is None:
            decision = _unparsed_statement_scope(req, body)
        if decision is not None:
            decisions.append(decision)
    if "applies" in decisions:
        return "applies"
    return "unknown" if not decisions or "unknown" in decisions else "irrelevant"
