"""Approval workflow engine for document processing.

Manages multi-stage approval workflows with notifications and audit trails.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import timedelta
from enum import Enum
from typing import Any

from app.models.document.workflow import (
    ApprovalAction,
    WorkflowDefinition,
    WorkflowInstance,
    WorkflowStep,
    WorkflowStepStatus,
)
from app.services.notifications import NotificationOutbox, notification_outbox
from app.services.workflow_events import WorkflowEventBroker, workflow_event_broker
from app.utils.time import utc_now
from sqlalchemy import or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession


class WorkflowTrigger(Enum):
    """Triggers that can start a workflow."""

    DOCUMENT_UPLOAD = "document_upload"
    FORM_SUBMISSION = "form_submission"
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    WEBHOOK = "webhook"


class WorkflowStatus(Enum):
    """Status of a workflow instance."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    ESCALATED = "escalated"
    EXPIRED = "expired"


@dataclass
class ApprovalResult:
    """Result of an approval action."""

    success: bool
    workflow_id: str
    step_id: str
    action: str
    new_status: str
    next_step: str | None = None
    notifications_sent: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class ApprovalWorkflowEngine:
    """Engine for managing document approval workflows.

    Features:
    - Multi-stage approval chains
    - Conditional routing (if approved, route to X; if rejected, route to Y)
    - SLA tracking and escalation
    - Parallel approvals (multiple approvers at same stage)
    - Notifications (email, webhook, in-app)
    - Audit trail
    """

    def __init__(
        self,
        db: AsyncSession,
        *,
        outbox: NotificationOutbox | None = None,
        event_broker: WorkflowEventBroker | None = None,
    ) -> None:
        """Initialize workflow engine.

        Args:
            db: Database session.
        """
        self.db = db
        self.outbox = outbox or notification_outbox
        self.event_broker = event_broker or workflow_event_broker

    @staticmethod
    def _uuid(value: str) -> uuid.UUID:
        """Normalize API string identifiers for UUID-backed columns."""
        return uuid.UUID(value)

    async def create_workflow_definition(
        self,
        name: str,
        description: str | None,
        steps: list[dict[str, Any]],
        owner_id: str,
        is_active: bool = True,
        workspace_id: str = "default",
        organization_id: str | None = None,
    ) -> WorkflowDefinition:
        """Create a new workflow definition (template).

        Args:
            name: Workflow name.
            description: Workflow description.
            steps: List of step definitions with approvers and conditions.
            owner_id: Creator user ID.
            is_active: Whether workflow is active.

        Returns:
            Created workflow definition.
        """
        workflow_def = WorkflowDefinition(
            id=uuid.uuid4(),
            name=name,
            description=description,
            steps_config=steps,
            owner_id=owner_id,
            workspace_id=workspace_id,
            organization_id=organization_id,
            is_active=is_active,
            created_at=utc_now(),
        )

        self.db.add(workflow_def)
        await self.db.commit()
        await self.db.refresh(workflow_def)

        return workflow_def

    async def start_workflow(
        self,
        workflow_definition_id: str,
        document_id: str,
        triggered_by: str,
        trigger_type: WorkflowTrigger = WorkflowTrigger.MANUAL,
        metadata: dict[str, Any] | None = None,
        workspace_id: str = "default",
    ) -> WorkflowInstance:
        """Start a new workflow instance.

        Args:
            workflow_definition_id: ID of workflow definition.
            document_id: Document being processed.
            triggered_by: User ID who triggered workflow.
            trigger_type: Type of trigger.
            metadata: Additional metadata.

        Returns:
            Created workflow instance.
        """
        # Get workflow definition
        result = await self.db.execute(
            select(WorkflowDefinition).where(
                WorkflowDefinition.id == self._uuid(workflow_definition_id),
                WorkflowDefinition.workspace_id == workspace_id,
            )
        )
        workflow_def = result.scalar_one_or_none()

        if not workflow_def:
            raise ValueError(f"Workflow definition not found: {workflow_definition_id}")

        # Create workflow instance
        workflow = WorkflowInstance(
            id=uuid.uuid4(),
            workflow_definition_id=self._uuid(workflow_definition_id),
            document_id=self._uuid(document_id),
            workspace_id=workspace_id,
            status=WorkflowStatus.PENDING.value,
            triggered_by=triggered_by,
            trigger_type=trigger_type.value,
            current_step_index=0,
            metadata_=metadata or {},
            created_at=utc_now(),
            expires_at=utc_now() + timedelta(days=7),
        )

        self.db.add(workflow)
        await self.db.flush()

        # Create steps
        steps = workflow_def.steps_config
        created_steps: list[WorkflowStep] = []
        for i, step_config in enumerate(steps):
            step = WorkflowStep(
                id=uuid.uuid4(),
                workflow_id=workflow.id,
                step_index=i,
                name=step_config["name"],
                description=step_config.get("description", ""),
                approver_ids=step_config.get("approvers", []),
                approver_role=step_config.get("approver_role"),
                is_parallel=step_config.get("is_parallel", False),
                min_approvals=step_config.get("min_approvals", 1),
                approval_route=step_config.get("approval_route"),
                rejection_route=step_config.get("rejection_route"),
                sla_hours=step_config.get("sla_hours", 24),
                status=WorkflowStepStatus.PENDING.value
                if i == 0
                else WorkflowStepStatus.WAITING.value,
                due_at=utc_now() + timedelta(hours=step_config.get("sla_hours", 24)),
            )
            self.db.add(step)
            created_steps.append(step)

        await self.db.commit()
        await self.db.refresh(workflow)

        # Notify first approvers
        if created_steps:
            await self._notify_approvers(workflow, created_steps[0])
        await self.event_broker.publish(
            str(workflow.id), "status", {"status": workflow.status}
        )

        return workflow

    async def process_approval(  # noqa: C901
        self,
        workflow_id: str,
        step_id: str,
        approver_id: str,
        action: ApprovalAction,
        comment: str | None = None,
        workspace_id: str | None = None,
    ) -> ApprovalResult:
        """Process an approval/rejection action.

        Args:
            workflow_id: Workflow instance ID.
            step_id: Current step ID.
            approver_id: User making the decision.
            action: APPROVE or REJECT.
            comment: Optional comment.

        Returns:
            ApprovalResult with next steps.
        """
        result = ApprovalResult(
            success=False,
            workflow_id=workflow_id,
            step_id=step_id,
            action=action.value,
            new_status="",
        )

        # Get workflow and step
        workflow_result = await self.db.execute(
            select(WorkflowInstance).where(
                WorkflowInstance.id == self._uuid(workflow_id),
                *(
                    [WorkflowInstance.workspace_id == workspace_id]
                    if workspace_id is not None
                    else []
                ),
            )
        )
        workflow = workflow_result.scalar_one_or_none()

        if not workflow:
            result.errors.append("Workflow not found")
            return result

        step_result = await self.db.execute(
            select(WorkflowStep).where(WorkflowStep.id == self._uuid(step_id))
        )
        step = step_result.scalar_one_or_none()

        if not step:
            result.errors.append("Step not found")
            return result

        from app.config import get_settings

        if get_settings().connected:
            if (
                step.workflow_id != workflow.id
                or step.status != WorkflowStepStatus.PENDING.value
                or workflow.status
                not in {WorkflowStatus.PENDING.value, WorkflowStatus.IN_PROGRESS.value}
            ):
                result.errors.append(
                    "Workflow/step is not pending or does not belong to this workflow"
                )
                return result
            if approver_id in (step.decisions or {}):
                result.errors.append("This approver already recorded a decision")
                return result

        # Validate approver
        if approver_id not in step.approver_ids:
            result.errors.append("User is not an approver for this step")
            return result

        if get_settings().connected:
            claimed = await self.db.execute(
                update(WorkflowInstance)
                .where(
                    WorkflowInstance.id == workflow.id,
                    WorkflowInstance.transition_version == workflow.transition_version,
                    WorkflowInstance.status.in_(
                        [WorkflowStatus.PENDING.value, WorkflowStatus.IN_PROGRESS.value]
                    ),
                )
                .values(transition_version=WorkflowInstance.transition_version + 1)
            )
            if int(getattr(claimed, "rowcount", 0)) != 1:
                await self.db.rollback()
                result.errors.append(
                    "A concurrent transition already changed the workflow; reload"
                )
                return result

        # Record decision
        step.decisions = {
            **(step.decisions or {}),
            approver_id: {
                "action": action.value,
                "comment": comment,
                "timestamp": utc_now().isoformat(),
            },
        }

        # Check if step is complete
        approvals = sum(
            1
            for d in step.decisions.values()
            if d["action"] == ApprovalAction.APPROVE.value
        )
        _rejections = sum(
            1
            for d in step.decisions.values()
            if d["action"] == ApprovalAction.REJECT.value
        )

        if action == ApprovalAction.REJECT:
            # Handle rejection
            step.status = WorkflowStepStatus.REJECTED.value
            workflow.status = WorkflowStatus.REJECTED.value
            workflow.completed_at = utc_now()

            # Check for conditional routing on rejection
            if step.rejection_route:
                next_step_id = step.rejection_route
                # Route to specified step or end
                if next_step_id == "end":
                    workflow.status = WorkflowStatus.REJECTED.value
                else:
                    routed = await self._route_to_step(workflow, next_step_id)
                    result.next_step = str(routed.id)

            result.success = True
            result.new_status = workflow.status

        elif approvals >= step.min_approvals:
            # Step approved
            step.status = WorkflowStepStatus.APPROVED.value
            step.completed_at = utc_now()

            # Check if there are more steps
            if step.approval_route and step.approval_route != "end":
                next_step = await self._route_to_step(workflow, step.approval_route)
            elif step.approval_route == "end":
                next_step = None
            else:
                next_step = await self._get_next_step(workflow, step)

            if next_step:
                workflow.current_step_index = next_step.step_index
                next_step.status = WorkflowStepStatus.PENDING.value
                result.next_step = str(next_step.id)
                result.new_status = WorkflowStatus.IN_PROGRESS.value
                workflow.status = WorkflowStatus.IN_PROGRESS.value

                # Notify next approvers
                await self._notify_approvers(workflow, next_step)
            else:
                # Workflow complete
                workflow.status = WorkflowStatus.APPROVED.value
                workflow.completed_at = utc_now()
                result.new_status = WorkflowStatus.APPROVED.value

            result.success = True

        await self.db.commit()

        # Send notifications
        notifications = await self._send_notifications(
            workflow, step, action, approver_id
        )
        result.notifications_sent = notifications
        await self.event_broker.publish(
            str(workflow.id),
            "status",
            {
                "status": workflow.status,
                "step_id": str(step.id),
                "action": action.value,
            },
        )

        return result

    async def _get_next_step(
        self,
        workflow: WorkflowInstance,
        current_step: WorkflowStep,
    ) -> WorkflowStep | None:
        """Get the next step in the workflow."""
        result = await self.db.execute(
            select(WorkflowStep)
            .where(
                WorkflowStep.workflow_id == workflow.id,
                WorkflowStep.step_index > current_step.step_index,
                WorkflowStep.status == WorkflowStepStatus.WAITING.value,
            )
            .order_by(WorkflowStep.step_index)
        )
        return result.scalar_one_or_none()

    async def _route_to_step(
        self,
        workflow: WorkflowInstance,
        step_id: str,
    ) -> WorkflowStep:
        """Route workflow to a specific step."""
        predicates = [WorkflowStep.workflow_id == workflow.id]
        try:
            predicates.append(WorkflowStep.id == uuid.UUID(step_id))
        except ValueError:
            predicates.append(WorkflowStep.name == step_id)
        result = await self.db.execute(
            select(WorkflowStep).where(or_(*predicates[1:]), predicates[0])
        )
        target = result.scalar_one_or_none()
        if target is None:
            raise ValueError(f"Workflow route target not found: {step_id}")
        target.status = WorkflowStepStatus.PENDING.value
        workflow.current_step_index = target.step_index
        workflow.status = WorkflowStatus.IN_PROGRESS.value
        await self._notify_approvers(workflow, target)
        return target

    async def _notify_approvers(
        self,
        workflow: WorkflowInstance,
        step: WorkflowStep,
    ) -> list[str]:
        """Notify approvers that action is required."""
        notifications: list[str] = []

        for approver_id in step.approver_ids:
            await self.outbox.enqueue(
                workspace_id=workflow.workspace_id,
                event_type="workflow.approval_required",
                recipient=approver_id,
                payload={"workflow_id": str(workflow.id), "step_id": str(step.id)},
                deduplication_key=f"{workflow.id}:{step.id}:{approver_id}:required",
                db=self.db,
            )
            notifications.append(f"notified:{approver_id}")

        step.notifications_sent = notifications
        return notifications

    async def _send_notifications(
        self,
        workflow: WorkflowInstance,
        step: WorkflowStep,
        action: ApprovalAction,
        approver_id: str,
    ) -> list[str]:
        """Send notifications about approval action."""
        notifications: list[str] = []

        # Notify workflow owner
        await self.outbox.enqueue(
            workspace_id=workflow.workspace_id,
            event_type=f"workflow.{action.value}",
            recipient=workflow.triggered_by,
            payload={"workflow_id": str(workflow.id), "step_id": str(step.id)},
            deduplication_key=f"{workflow.id}:{step.id}:{approver_id}:{action.value}",
            db=self.db,
        )
        notifications.append(f"owner:{workflow.triggered_by}")

        # If rejected, notify previous approvers
        if action == ApprovalAction.REJECT:
            prev_steps = await self.db.execute(
                select(WorkflowStep).where(
                    WorkflowStep.workflow_id == workflow.id,
                    WorkflowStep.step_index < step.step_index,
                )
            )
            for prev_step in prev_steps.scalars():
                for pid in prev_step.approver_ids:
                    notifications.append(f"prev_approver:{pid}")

        return notifications

    async def check_slas(self) -> list[WorkflowInstance]:
        """Check for workflows that have exceeded SLA.

        Returns:
            List of workflows that need escalation.
        """
        result = await self.db.execute(
            select(WorkflowInstance).where(
                WorkflowInstance.status.in_(
                    [
                        WorkflowStatus.PENDING.value,
                        WorkflowStatus.IN_PROGRESS.value,
                    ]
                ),
                WorkflowInstance.expires_at < utc_now(),
            )
        )

        escalated: list[WorkflowInstance] = []
        for workflow in result.scalars():
            workflow.status = WorkflowStatus.ESCALATED.value
            escalated.append(workflow)
            await self.outbox.enqueue(
                workspace_id=workflow.workspace_id,
                event_type="workflow.escalated",
                recipient=workflow.triggered_by,
                payload={"workflow_id": str(workflow.id)},
                deduplication_key=f"{workflow.id}:escalated",
                db=self.db,
            )
            await self.event_broker.publish(
                str(workflow.id), "status", {"status": workflow.status}
            )

        await self.db.commit()
        return escalated

    async def cancel_workflow(
        self,
        workflow_id: str,
        cancelled_by: str,
        reason: str | None = None,
        workspace_id: str | None = None,
    ) -> bool:
        """Cancel a workflow.

        Args:
            workflow_id: Workflow to cancel.
            cancelled_by: User cancelling.
            reason: Optional reason.

        Returns:
            True if cancelled successfully.
        """
        result = await self.db.execute(
            update(WorkflowInstance)
            .where(
                WorkflowInstance.id == self._uuid(workflow_id),
                WorkflowInstance.triggered_by == cancelled_by,
                WorkflowInstance.status.in_(
                    [WorkflowStatus.PENDING.value, WorkflowStatus.IN_PROGRESS.value]
                ),
                *(
                    [WorkflowInstance.workspace_id == workspace_id]
                    if workspace_id is not None
                    else []
                ),
            )
            .values(
                status=WorkflowStatus.CANCELLED.value,
                completed_at=utc_now(),
                metadata_={
                    "cancelled_by": cancelled_by,
                    "cancel_reason": reason,
                },
            )
        )

        await self.db.commit()
        success = int(getattr(result, "rowcount", 0)) > 0
        if success:
            await self.event_broker.publish(
                workflow_id, "status", {"status": WorkflowStatus.CANCELLED.value}
            )
        return success

    async def get_workflow_history(
        self,
        document_id: str,
        workspace_id: str | None = None,
        owner_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get workflow history for a document.

        Args:
            document_id: Document ID.

        Returns:
            List of workflow history entries.
        """
        result = await self.db.execute(
            select(WorkflowInstance)
            .where(
                WorkflowInstance.document_id == self._uuid(document_id),
                *(
                    [WorkflowInstance.workspace_id == workspace_id]
                    if workspace_id is not None
                    else []
                ),
                *(
                    [WorkflowInstance.triggered_by == owner_id]
                    if owner_id is not None
                    else []
                ),
            )
            .order_by(WorkflowInstance.created_at.desc())
        )

        history: list[dict[str, Any]] = []
        for workflow in result.scalars():
            steps_result = await self.db.execute(
                select(WorkflowStep)
                .where(WorkflowStep.workflow_id == workflow.id)
                .order_by(WorkflowStep.step_index)
            )
            steps = steps_result.scalars().all()

            history.append(
                {
                    "workflow_id": str(workflow.id),
                    "status": workflow.status,
                    "created_at": workflow.created_at.isoformat(),
                    "completed_at": workflow.completed_at.isoformat()
                    if workflow.completed_at
                    else None,
                    "steps": [
                        {
                            "name": step.name,
                            "status": step.status,
                            "approvers": step.approver_ids,
                            "decisions": step.decisions,
                        }
                        for step in steps
                    ],
                }
            )

        return history
