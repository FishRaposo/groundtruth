# V10 focused finding accumulator — recheck01

2026-10-24. All three retained material findings are resolved in this exact quiet-source snapshot. No unresolved finding remains within this focused recheck. Original REVIEW.md, source copies, failed probe outputs and baseline characterization remain unchanged. This is a pure-helper review result, not model/API quality or completion evidence.

| Retained finding | Independent final observation | Status |
| --- | --- | --- |
| Embedded give/identify corrupt interrogatives | Both original questions remain unchanged; genuine prefaced Willow/dry-room directive still decomposes correctly | Resolved |
| One-letter X new subject inherits unrelated exclusion | Exact X duration remains eligible; immediate same-scope instruction is still excluded; Borealis new topic and blank paragraph controls pass; instruction-B suffix reference keeps exclusion | Resolved |
| Modal follow-sequence request loses procedural intent | Exact `What sequence should I follow...` predicate returns true; sequence-number attribute remains false; sequence entity schedule/compound controls pass | Resolved |

Inspection confirms the narrow intended changes: nominal matching is anchored to a genuine directive head with bounded allowed preface/politeness; procedure intent explicitly recognizes the modal follow head; explicit one-letter topic relations supplement the existing multi-character proper-name guard without treating the instruction-B cross-reference as a new topic. No broader grammar expansion or new counterexample search was performed here.

Using `C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe -B`, with PYTHONDONTWRITEBYTECODE=1:

- `<v10-intent-review>/probes.py recheck-01/current`: exit0,11/11 retained assertions; probes.log/current-result.json.
- `<v10-intent-review>/boundary_controls.py recheck-01/current`: exit0,5/5 retained assertions; boundary-controls.log/current-boundary-result.json.

The script prefix above denotes the absolute original v10-intent-review directory; actual commands passed absolute script paths. Scripts are unchanged from the original review and their SHA256 values are recorded in result-summary.json. The snapshot argument selects this recheck source. Pure helper imports and the exact AST-only reader_question extraction avoid model/API convenience imports. No model, network, API, service, corpus execution or seed-manifest access occurred.

All16 assertions pass. Source-before/source-after equality and retained-copy hashes were independently checked for all five reviewed files. Raw hashes: reader_questions `f4f8b52756d2b7fcc5aa9495f38bb290b3bc8589191af7d8380b3cbdc1f828fe`; reader_support `2c11d26415e0f011a1084803871beb1ecd55f0c4b1f09f88744c0df9ca425fdc`; answer_reader `459b03ca3ffb323ed12f40d518b272daa9cc22cc9abb365a662d3942109392b9`. Test hashes and full observations are retained in source-before.json/source-after.json and result-summary.json.

No repository/application/test/corpus/evidence changes were made by the reviewer. Multiple-document and curated-conflict invariants retain the scope of the prior diff review, not a new integration certification. These finite preparation/rejection controls do not establish entailment or real-model completeness. Any later exposed-development measurement must bind its own source; the original failed blind comparison remains failed and exposed. Parent owns further development/measurement decisions.
