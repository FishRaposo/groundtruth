# V10 bounded request-intent/scope review

2026-10-24, a4c5b21 to the retained current uncommitted snapshot. Three material findings remain in the reviewed snapshot; four failing assertions reproduce them. This is read-only development review, not a quality/completion verdict. No application/tests/corpus/evidence edits, private seed reads, real model/API/service calls or comparison executions occurred.

## Findings

1. **P2 — Single nominal rewriting corrupts verbs inside an interrogative.** reader_questions.py:55-74 searches anywhere in a question for give/tell/identify/combine using a free-form leading capture. The new `if items` branch rewrites even a single noun item, and :129/:161 now pass that rewritten question to QA. Thus `What is the time required to give the Willow talk?` becomes `What is the time required to What is the Willow talk?`; `Who should identify the Willow panel owner?` becomes `Who should What is the Willow panel owner?`. These are ordinary interrogatives, not imperative request heads. Both remain unchanged on a4c5b21. The regression changes requested actions/predicates and produces invalid QA questions while retaining the named anchor, so a scope-word check cannot catch it. Exact independent probes are the first two rows of current-result.json.

2. **P2 — Immediate exclusion inheritance crosses an explicit one-letter named subject.** reader_support.py:296-311 uses `[A-Z][\w-]+`, which recognizes multi-character names but misses a valid single-letter name. Following `For the Willow exception, attach the marker to the inner edge. This exception is outside the standard review procedure.`, the new sentence `This instruction for X review takes 18 minutes.` is incorrectly treated as an unnamed continuation. Question `How long is the X review?`, selected exact `18 minutes`, is rejected as selected_clause_explicitly_outside_requested_scope. The equivalent Borealis sentence is correctly eligible. A4c5b21 does not reject the X answer. This violates the explicit new-subject control for inherited exclusions; it is a deterministic false rejection, not evidence of an access leak or actual QA behavior.

3. **P2 — Modal procedural request loses explicit-sequence preference.** reader_support.py:26-40 requests_procedure returns false for `What sequence should I follow to handle the Willow panel?`, whereas the prior procedure_features predicate returns true. Its post-sequence lookahead accepts punctuation and selected prepositions but excludes should, despite the explicit follow action. This disables the already-accepted ordered-source ranking prior in procedure_features and fails the stated distinction between a requested procedure and an entity/attribute containing sequence. Parent supplied this bounded generic grammar after observing a development regression; reviewer independently reproduced only the pure predicate, without reading that report or invoking its model. Control `What is the sequence number for the Willow panel?` correctly remains nonprocedural under the new implementation. Restoring the older broad sequence-keyword match would lose this control.

Line references correspond to exact retained copies under current/app/services and the matching worktree at review time. No claim is made that a real model necessarily chooses any particular span in these independent fixtures.

## Controls and narrow repair boundaries

The16 independent assertions consist of11 in probes.py and5 in boundary_controls.py. Current source has4 failures/12 passing controls. Controls verify:

- A frame-sequence entity does not prevent a three-part duration/reservation request or turn a schedule into a procedure.
- Start-clock evidence cannot establish time required; actual session clock remains eligible.
- Explicit full-procedure QA normalization preserves the qualified subject after shutdown.
- Role inheritance carries the restoring-after-shutdown subject, without carrying the responsible-role predicate into day/time continuations.
- Immediate same-scope anaphoric instruction is excluded; new Borealis subject and raw blank-paragraph break prevent inheritance.
- A real prefaced directive retains the entire Willow/dry-room qualifier, and mid-name Copy remains an entity constraint.
- `This instruction applies to the same current practice run as instruction B.` retains the known exclusion. A blanket change to include every one-letter capital in the named set would break this cross-reference control.

Parent's proposed narrow direction is consistent with these findings: recognize nominal directives at a genuine head (with bounded recognized topic/politeness prefixes), distinguish an explicit `for X` new subject from a suffix instruction-B cross-reference, and recognize the explicit modal-follow procedure head while preserving sequence-number attributes. These are proposed boundaries, not reviewed implementations. Unsupported grammar should retain its original question rather than manufacture a partial request. No broader grammar expansion was attempted.

Scoped diff preserves multiple authorized contexts, curated conflicts before citation-cover selection, current immutable extraction and existing thresholds. No source narrowing, model-input cropping, candidate retries, provider/download change or case-specific label rule was found in the scoped changes. This is inspection of the bounded diff, not a broader privacy/integration audit. Surface request and exclusion rules still do not establish entailment. The raw blank-paragraph control is a helper-input check, not proof that all original document paragraph structure survives canonical ingestion.

## Commands, exact evidence and hashes

Interpreter: `C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe -B`, with PYTHONDONTWRITEBYTECODE=1. UTF-8 is explicit on source/artifact text operations. Exact source copies are retained under current and Git a4c5b21 copies under baseline. Pure helper imports use synthetic package paths to avoid unrelated package convenience imports; reader_question is compiled from its exact AST function with only re in scope, avoiding model imports.

- `probes.py current`: exit1,3FAIL/8PASS, current.log/current-result.json.
- `boundary_controls.py current`: exit1,1FAIL/4PASS, current-boundary.log/current-boundary-result.json.
- Corresponding baseline commands also return1 because desired new-feature controls are not implemented there. All four regression assertions above pass on baseline; this is behavior characterization, not a model-quality comparison. Full outputs are retained separately.
- Read-only Git diff/source/test inspection and snapshot hash verification: exit0.

All five scoped files have identical source-before/source-after hashes during this review. Raw implementation SHA256: answer_reader `459b03ca3ffb323ed12f40d518b272daa9cc22cc9abb365a662d3942109392b9`; reader_questions `b9eecb5990b4567380853ca13a9acab68a9b7d9afc5fa6a252ad1e84dbee9bd8`; reader_support `41f062d9e602880a330247a64c1e18ae7d0c6b121fedacb64fd0c29b5edf2908`. Exact test hashes are in source-before.json/source-after.json.

The five review files had matching boundary hashes while parent reported an active exposed-development HTTP observation; the reviewer did not interact with that process or independently audit its source binding. Parent owns sealing that observation, recording narrow repair RED/control evidence, and requesting a focused recheck. Failed blind-v4 and later exposed status remain unchanged; no unseen or release claim is made.
