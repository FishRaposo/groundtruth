"""Pure helper/AST-normalizer probes, no model/API imports or calls."""
import ast
import json
from pathlib import Path
import re
import sys
import types
version = sys.argv[1]
O = Path(__file__).resolve().parent
root = O/version/'app/services'
for package, relative in [('app','app'),('app.services','app/services')]:
    module=types.ModuleType(package)
    module.__path__=[str(O/version/relative)]
    sys.modules[package]=module
from app.services.reader_questions import question_parts, mismatch_reason
from app.services.reader_support import procedure_features
tree=ast.parse((root/'answer_reader.py').read_text(encoding='utf-8'))
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='reader_question')
namespace={'re':re}
exec(compile(ast.Module(body=[node],type_ignores=[]),'exact_reader_question_ast','exec'),namespace)
reader_question=namespace['reader_question']
rows=[]
def check(name, passed, observed):
    rows.append({'name':name,'passed':bool(passed),'observed':observed})
def show(parts):
    return [{'question':p.question,'anchors':p.anchors} for p in parts]
for name,question in [('embedded_give_is_not_a_request_head','What is the time required to give the Willow talk?'),('embedded_identify_is_not_a_request_head','Who should identify the Willow panel owner?')]:
    p=question_parts(question)
    check(name,len(p)==1 and p[0].question==question,show(p))
p=question_parts('Give the review duration for the Willow frame sequence, then the reservation role and deadline.')
check('sequence_entity_nominal_compound_control',len(p)==3 and all(p.anchors==('willow',) for p in p),show(p))
source='The Willow frame sequence session starts at 14:10.'
start=source.index('14:10')
actual=mismatch_reason('When does the Willow frame sequence session start?',source,start,start+5)
check('entity_sequence_schedule_control',actual is None,actual)
actual=mismatch_reason('What is the time required to review Willow?',source,start,start+5)
check('time_required_cannot_be_start_clock_control',actual is not None,actual)
prepared=reader_question('I am preparing the Willow panel after shutdown. Copy the entire procedure in its stated order.')
check('procedural_qa_subject_qualifier_control',prepared=='What are the steps for the Willow panel after shutdown?',prepared)
p=question_parts('Which role is responsible for restoring the Willow panel after shutdown? Also give the scheduled day and time.')
check('responsible_role_continuation_preserves_qualifier',len(p)==3 and all('after shutdown' in x.question for x in p) and all('is responsible' not in x.question for x in p[1:]),show(p))
base='For the Willow exception, attach the marker to the inner edge. This exception is outside the standard review procedure. '
for label,continuation,question,expected in [
    ('own_excluded_anaphor_control','This instruction applies to the same current practice run.','What are the steps for the Willow standard review?',True),
    ('named_new_subject_control','This instruction for Borealis review takes 18 minutes.','How long is the Borealis review?',False),
    ('single_letter_named_subject_breaks_inheritance','This instruction for X review takes 18 minutes.','How long is the X review?',False),
    ('blank_paragraph_break_control','\n\nThis instruction takes 18 minutes.','How long is the standard review?',False),
]:
    source=base+continuation
    raw='same current practice run' if label=='own_excluded_anaphor_control' else '18 minutes'
    start=source.index(raw)
    reason=mismatch_reason(question,source,start,start+len(raw))
    check(label,(reason is not None)==expected,reason)
print(json.dumps(rows,indent=2))
(O/(version+'-result.json')).write_text(json.dumps(rows,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not r['passed'] for r in rows) else 0)
