import json
from pathlib import Path
import sys
import types
version=sys.argv[1]
O=Path(__file__).resolve().parent
for package, relative in [('app','app'),('app.services','app/services')]:
    module=types.ModuleType(package)
    module.__path__=[str(O/version/relative)]
    sys.modules[package]=module
from app.services.reader_questions import question_parts, scope_matches, mismatch_reason
from app.services.reader_support import procedure_features
rows=[]
def check(name,passed,observed):
    rows.append({'name':name,'passed':bool(passed),'observed':observed})
source='Willow handling: First, isolate. Next, inspect.'
actual=procedure_features('What sequence should I follow to handle the Willow panel?',source)['requested']
check('modal_follow_sequence_is_procedural',actual is True,actual)
actual=procedure_features('What is the sequence number for the Willow panel?',source)['requested']
check('sequence_number_is_attribute_control',actual is False,actual)
p=question_parts('For the Willow panel in the dry room, please give the owner and deadline.')
check('prefaced_directive_keeps_named_subject_and_qualifier',len(p)==2 and all(x.anchors==('willow',) and 'dry room' in x.question for x in p),[{'question':x.question,'anchors':x.anchors} for x in p])
p=question_parts('Who owns the Copy queue?')
check('mid_name_Copy_control',not scope_matches(p[0],'The Borealis queue owner is the steward.'),p[0].anchors)
source='For the Willow exception, attach the marker to the inner edge. This exception is outside the standard review procedure. This instruction applies to the same current practice run as instruction B.'
raw='same current practice run'
start=source.index(raw)
actual=mismatch_reason('What are the steps for the Willow standard review?',source,start,start+len(raw))
check('same_instruction_letter_reference_keeps_exclusion',actual is not None,actual)
print(json.dumps(rows,indent=2))
(O/(version+'-boundary-result.json')).write_text(json.dumps(rows,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not r['passed'] for r in rows) else 0)
