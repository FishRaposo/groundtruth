"""Production _parts + witness selection with deterministic accepted seam only."""
import hashlib
import json
import os
from pathlib import Path
import sys
import types
O=Path(__file__).resolve().parent
W=O.parents[3]/'delivery-worktree'
os.environ.update(DATABASE_URL='sqlite+aiosqlite:///:memory:',EMBEDDING_MODE='legacy',GENERATION_MODE='extractive',ANSWER_SELECTION_MODE='reader',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OPENAI_API_KEY='')
sys.path.insert(0,str(W/'apps/api'))
services=types.ModuleType('app.services')
services.__path__=[str(O/'current/app/services'),str(W/'apps/api/app/services')]
sys.modules['app.services']=services
from app.services.answer_reader import LocalReader, ReaderSelection, passage_span
from app.services.reader_questions import mismatch_reason
from app.services.reader_witnesses import select_witness_cover

contexts=[
    'The Willow inspection replaces the Borealis inspection. Complete procedure: 1. Isolate the console. 2. Inspect the seal.',
    'For the Willow inspection, isolate the console before inspecting the seal.',
]
question='What are the steps for Willow inspection?'
rows=[]
for margins,expected in [((-6.0,-4.0),(0,)),((-4.0,-6.0),(1,))]:
    local=LocalReader()
    def never_load(*args,**kwargs):
        raise AssertionError('Model load is prohibited in this probe')
    local._load=never_load
    def prediction(question,context,config):
        raw='Isolate the console' if 'Isolate the console' in context else 'isolate the console'
        start=context.index(raw)
        return ReaderSelection(passage_span(context,start,start+len(raw)),{'decision':'answer','null_margin':margins[contexts.index(context)],'raw_span':{'start':start,'end':start+len(raw)}})
    local._context=prediction
    selections=local._parts(question,contexts,object())
    assert all(s.span is not None for s in selections)
    assert all(s.span.text==contexts[i][s.span.start:s.span.end] for i,s in enumerate(selections))
    assert all(s.diagnostics['parts'][0]['procedure_evidence']['selected_sequence'] is False for s in selections)
    cover=select_witness_cover(selections)
    assert cover.indices==expected
    rows.append({'margins':margins,'accepted_spans':len(selections),'format_prior':[s.diagnostics['parts'][0]['procedure_evidence']['selected_sequence'] for s in selections],'selected_indices':cover.indices,'expected':expected,'passed':True})
source='The Willow policy uses the inner edge. This policy is outside the standard review procedure.'
raw='inner edge'
start=source.index(raw)
reason=mismatch_reason('Which policies apply to Willow?',source,start,start+len(raw))
assert reason is None
assert 'torch' not in sys.modules and 'transformers' not in sys.modules
result={'fallback_cases':rows,'policies_plural_eligible':True,'model_libraries_imported':False,'witness_source_sha256':hashlib.sha256((W/'apps/api/app/services/reader_witnesses.py').read_bytes()).hexdigest()}
(O/'fallback-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
