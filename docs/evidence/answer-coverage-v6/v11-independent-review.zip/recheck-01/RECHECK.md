# V11 focused finding accumulator — recheck01

2026-10-24. All three retained material defects are resolved in the copied quiet-source snapshot. No unresolved material finding remains within this focused recheck. The original review, red observations and raw/normalized paragraph witness remain unchanged. This does not establish real-model accuracy, entailment, release readiness or unseen acceptance.

| Finding | Final independent observation | Status |
| --- | --- | --- |
| Start-location question treated as a clock request | Exact09:20 selection now rejects as clock_does_not_establish_requested_attribute; nominal actual start and relative start stay eligible | Resolved |
| Own plural exceptions wrongly excluded | Original exceptions question and additional ordinary policies plural remain eligible; singular own query/default/nondefault controls retain behavior | Resolved |
| Borealis subject borrowing Willow object for generic heading | selected_sequence is now false when another capitalized named entity occurs, before accepting target-token presence | Resolved |

The heading rule deliberately also withholds its formatting prior for `The Willow inspection replaces the Borealis inspection.`. This conservative policy was discussed before repair and affects only the prior. It must not reject an already accepted span. The source explicitly documents the prior as formatting/name evidence, not coreference resolution, and states that only paragraph breaks present in canonical context can constrain it. Original layout can be collapsed by ingestion and cannot be recovered here.

## Exact retained observations

The unchanged original14-assertion probe returns exit1 with12 passing and2 retained nonpassing expectations. They are explicitly accounted for rather than relabeled as all14 passing:

- target_subject_with_other_named_object_control now observes false: intentional conservative removal of the formatting prior, not a factual rejection.
- original_paragraph_bound_is_not_preserved_by_canonical_whitespace still observes true: the documented normalization limitation, not an implemented original-layout boundary.

All three material regression assertions pass. Their original failure outputs remain in the parent review directory, and original-probes.log/current-result.json retain this recheck's exact outcomes. No original assertion or old result was edited.

## Accepted-span fallback

fallback_probe.py invokes the production LocalReader._parts and production select_witness_cover, replacing only _context with deterministic already-accepted seam predictions. Two actual source contexts remain accepted, both formatting-prior flags are false, and exact immutable span copies are checked. With margins(-6,-4), cover chooses context0; swapping to(-4,-6) chooses context1. Thus dropping the generic-heading prior does not discard accepted candidates or prevent normal raw-margin selection. This directly verifies the requested fallback boundary; it does not measure a QA model.

The same probe checks ordinary policy→policies own-scope eligibility. It sets only disposable in-memory configuration, never creates an API or DB session, blocks model loading and asserts torch/transformers were not imported. Production model classes/schemas are imported solely to use the real ReaderSelection/AnswerSpan types. No weights, models, APIs, services, corpus, private seed, database data or network are accessed. The unchanged witness helper SHA256 is278a6fac781d201a7cf0d6c6979047de5851306d3965768ab70b084e06311f51.

All16 retained v10 pure controls also pass unchanged on this source (11+5), including embedded directives, modal procedure intent, sequence-number attributes, role/qualifier inheritance, X subject, instruction-B reference and named Copy.

## Commands and source binding

Interpreter: C:/Projects/operation-fan-the-hammer/portfolio/groundtruth/.venv/Scripts/python.exe -B; PYTHONDONTWRITEBYTECODE=1; explicit UTF-8 source/artifact operations.

- Original v11 probes.py with snapshot argument recheck-01/current: exit1,12PASS/2 documented expectations above.
- recheck-01/fallback_probe.py: exit0, both margin fallback cases and policies plural pass; fallback.log/fallback-result.json.
- Original v10 probes.py and boundary_controls.py with this review's absolute prior-v10/current snapshot path: both exit0,16/16. Outputs remain under this recheck's prior-v10 directory.
- Hash/result verification: exit0. All four scoped source/test hashes before=after; retained implementation copies match their measured bytes. result-summary.json records exact values.

Reader support SHA256 d78b204fe4e49a0854ebfbdeeed040728129bfcc84d22db392403905a048b2f2; reader questions1fe1c26e49548e3ce6f104e6c4f7d8d42bc46d81a06423bb8f1051ed4e001b1c; answer reader95ffe055533050a7206370f78565914dcde58cdb7fda80a896a98031b3ce491c; new boundary testsbd6c7edc5fed50d69660d240fa91d044be8253cde305b0c1a681df4ff2bae078.

No repository application/test/corpus/evidence/staging change was made by this reviewer. The prior v11 actual observation belongs to its pre-repair source; these fixes have not been model-measured by this recheck. Parent owns any next source-bound exposed-development observation. No quality, completion or blind-gate pass is claimed.
