"""Pure evidence-boundary fixtures; no API, model, corpus or seed reads."""
import json
from pathlib import Path
import re
import sys
import types
version=sys.argv[1]
O=Path(__file__).resolve().parent
for package,relative in [('app','app'),('app.services','app/services')]:
    module=types.ModuleType(package)
    module.__path__=[str(O/version/relative)]
    sys.modules[package]=module
from app.services.reader_questions import mismatch_reason
from app.services.reader_support import procedure_features
rows=[]
def check(name,passed,observed):
    rows.append({'name':name,'passed':bool(passed),'observed':observed})
source='The Willow session starts at 09:20.'
start=source.index('09:20')
reason=mismatch_reason('What is the session start location for Willow?',source,start,start+5)
check('start_location_cannot_be_answered_by_clock',reason is not None,reason)
reason=mismatch_reason('What is the session start for Willow?',source,start,start+5)
check('actual_nominal_start_clock_control',reason is None,reason)
source='The Willow review takes 18 minutes.'
start=source.index('18 minutes')
reason=mismatch_reason('What is the session start for Willow?',source,start,start+10)
check('elapsed_is_not_start_control',reason is not None,reason)
source='The Willow session starts 18 minutes after the bell.'
raw='18 minutes after the bell'
start=source.index(raw)
reason=mismatch_reason('What is the session start for Willow?',source,start,start+len(raw))
check('relative_start_control',reason is None,reason)
source='The Willow exception uses the inner edge. This exception is outside the standard review procedure.'
raw='inner edge'
start=source.index(raw)
reason=mismatch_reason('Which exceptions apply to Willow?',source,start,start+len(raw))
check('own_plural_exceptions_question_keeps_evidence',reason is None,reason)
reason=mismatch_reason('Which exception applies to Willow?',source,start,start+len(raw))
check('own_singular_exception_control',reason is None,reason)
reason=mismatch_reason('Which edge applies to Willow?',source,start,start+len(raw))
check('unqualified_default_scope_exclusion_control',reason is not None,reason)
other=source.replace('standard review procedure','export procedure')
reason=mismatch_reason('Which edge applies to Willow?',other,start,start+len(raw))
check('nondefault_scope_control',reason is None,reason)
def heading(prefix):
    source=prefix+'Complete procedure: 1. Isolate the console. 2. Inspect the seal.'
    raw='Isolate the console'
    start=source.index(raw)
    return procedure_features('What are the steps for Willow inspection?',source,start=start,end=start+len(raw),anchors=('willow',))['selected_sequence']
actual=heading('The Willow inspection covers six seals. The Borealis inspection replaces the Willow inspection. ')
check('new_named_subject_cannot_borrow_target_object',actual is False,actual)
actual=heading('The Willow inspection replaces the Borealis inspection. ')
check('target_subject_with_other_named_object_control',actual is True,actual)
actual=heading('The Willow inspection covers six seals. Do not open the latch. ')
check('nearest_subject_generic_heading_control',actual is True,actual)
actual=heading('The Willow inspection covers six seals. The Borealis inspection covers two seals. ')
check('separate_new_topic_control',actual is False,actual)
actual=heading('The Willow inspection covers six seals.\n\n')
check('raw_paragraph_break_control',actual is False,actual)
canonical_prefix=re.sub(r'\s+',' ','The Willow inspection covers six seals.\n\n').strip()+' '
actual=heading(canonical_prefix)
check('original_paragraph_bound_is_not_preserved_by_canonical_whitespace',actual is False,actual)
print(json.dumps(rows,indent=2))
(O/(version+'-result.json')).write_text(json.dumps(rows,indent=2),encoding='utf-8')
raise SystemExit(1 if any(not row['passed'] for row in rows) else 0)
