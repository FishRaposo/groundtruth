"""V10 post-failure EXPOSED development only; no first reports or owner data modified."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, socket, sqlite3, subprocess, sys, time
import httpx

V = Path(__file__).resolve().parent
S = V.parent
W = S / 'delivery-worktree'
R = W.parents[2]
P = R / 'portfolio/groundtruth/.venv/Scripts/python.exe'
O = V / 'v10-observations'
assert not O.exists(), 'Never overwrite observations'
O.mkdir()
sys.path[:0] = [str(W/'apps/api'), str(W/'scripts')]
from app.portfolio import load_corpus
import evaluate_portfolio_retrieval as ev
from verify_answer_coverage_delivery import audit_report

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

paths = sorted(set(list((W/'apps/api/app').rglob('*.py')) +
    list((W/'apps/api/tests').glob('test_reader*.py')) +
    [W/'scripts/evaluate_portfolio_retrieval.py', W/'scripts/verify_answer_coverage_delivery.py']))
def hashes():
    return {p.relative_to(W).as_posix(): sha(p) for p in paths}
before = hashes()
(O/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
environment = os.environ.copy()
for key in list(environment):
    if key.startswith(('OPENAI_','ANTHROPIC_','AZURE_OPENAI_','GOOGLE_API','GEMINI_')):
        del environment[key]
environment.update(PYTHONPATH=str(W/'apps/api'), EMBEDDING_MODE='local',
    EMBEDDING_DIMENSIONS='384', LOCAL_MODEL_PATH=str(R/'.tmp/groundtruth-20261023/models/all-MiniLM-L6-v2--1110a243fdf4706b3f48f1d95db1a4f5529b4d41'),
    ANSWER_SELECTION_MODE='reader', READER_MODEL_PATH=str(S/'models/roberta-base-squad2--adc3b06f79f797d1c575d5479d6f5efe54a9e3b4'),
    READER_MODEL_REVISION='adc3b06f79f797d1c575d5479d6f5efe54a9e3b4', READER_NULL_THRESHOLD='4',
    GENERATION_MODE='extractive', INGESTION_MODE='inline', AUTH_ENABLED='true', RATE_LIMIT_ENABLED='false',
    APP_ENV='development', OPENAI_API_KEY='', CORS_ORIGINS='http://127.0.0.1:3506',
    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1',
    OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false')

for label, previous, corpus_name in [
    ('prior-development-80', V/'calibration', 'coverage-development-v3'),
    ('exposed-v4-200', S/'candidate-blind-v4', 'coverage-blind-v4'),
]:
    target = S/('v10-development-data-'+label)
    assert not target.exists()
    target.mkdir()
    original_hash = sha(previous/'groundtruth.sqlite')
    with sqlite3.connect('file:'+(previous/'groundtruth.sqlite').as_posix()+'?mode=ro',uri=True) as old:
        with sqlite3.connect(target/'groundtruth.sqlite') as new:
            old.backup(new)
    assert sha(previous/'groundtruth.sqlite') == original_hash
    seed = json.loads((previous/'seed-manifest.json').read_text(encoding='utf-8'))
    seed['api_url'] = 'http://127.0.0.1:8410'
    (target/'seed-manifest.json').write_text(json.dumps(seed,indent=2)+'\n',encoding='utf-8')
    corpus_path = W/'apps/api/app/portfolio/assets'/corpus_name
    corpus = load_corpus(corpus_path)
    assert seed['corpus_manifest_sha256'] == corpus['manifest']['manifest_sha256']
    run_env = dict(environment, DATABASE_URL='sqlite+aiosqlite:///'+(target/'groundtruth.sqlite').as_posix(), STORAGE_ROOT=str(target/'uploads'))
    command = [str(P),'-m','uvicorn','app.main:app','--host','127.0.0.1','--port','8410','--no-access-log']
    with socket.socket() as available:
        available.bind(('127.0.0.1',8410))
    with (O/(label+'-api.log')).open('wb') as log:
        process = subprocess.Popen(command,cwd=W,env=run_env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            for _ in range(200):
                if process.poll() is not None:
                    raise RuntimeError('Dedicated development API exited')
                try:
                    if httpx.get(seed['api_url']+'/api/health/live',timeout=1).status_code==200:
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(.25)
            else:
                raise RuntimeError('API startup timeout')
            response = httpx.get(seed['api_url']+'/api/health/ready',timeout=300)
            response.raise_for_status()
            health=response.json()
            assert health['status']=='ready'
            assert process.poll() is None, 'New API did not retain its port'
            (O/(label+'-readiness.json')).write_text(json.dumps(health,indent=2)+'\n',encoding='utf-8')
            docs=ev.map_documents(corpus,seed)
            settings=dict(corpus['profile'],reader_null_threshold=4,reader_model_revision=environment['READER_MODEL_REVISION'])
            methods=('reranked',)
            results={}
            for method in methods:
                rows=[]
                for case in corpus['cases']:
                    status,body,elapsed=ev.request_json(seed,case['principal'],'/api/queries',{'question':case['question'],'top_k':5,
                        'document_ids':[docs[d]['document_id'] for d in case['document_ids']] if case['document_ids'] is not None else None,'retrieval_method':method})
                    row=ev.build_case_row(case,body,status,docs,require_answer_spans=True)
                    ev.check_response_configuration(row,body,status,settings,'candidate')
                    row.update(http_elapsed_ms=elapsed,method=method,search_scope='explicit_document_filter' if case['document_ids'] is not None else 'all_authorized_documents')
                    rows.append(row)
                    if len(rows)%20==0:
                        print(label,method,len(rows),'of',len(corpus['cases']),flush=True)
                results[method]={'summary':ev.summarize(rows),'cases':rows}
            report={'schema_version':2,'created_at':datetime.now(timezone.utc).isoformat(),'corpus_revision':corpus['manifest']['revision'],
                'corpus_manifest_sha256':corpus['manifest']['manifest_sha256'],'split':corpus['cases'][0]['split'],
                'evaluation_visibility':'EXPOSED DEVELOPMENT ONLY - not unseen acceptance','selection_sha256':None,
                'measurement_scope':'Post-failure exposed regression; original authored split retained only for immutable case identity. No new blind validation.',
                'settings':settings,'profile':seed['profile'],'results':results,'indexed_claim':False,'score_contract':'coverage-v2',
                'span_integrity_required':True,'execution_arm':'candidate','source_document_ids':ev.public_source_document_ids(docs)}
            audit=audit_report(report,corpus)
            assert before==hashes(),'Source changed during observation'
            destination=O/(label+'-report.json')
            destination.write_bytes((json.dumps(report,indent=2)+'\n').encode())
            destination.with_suffix('.json.sha256').write_bytes((sha(destination)+'\n').encode())
            (O/(label+'-integrity.json')).write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
            print(json.dumps({'EXPOSED_DEVELOPMENT':label,'summary':{k:x['summary'] for k,x in results.items()},'portable_integrity':audit}),flush=True)
        finally:
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            process.wait(timeout=30)
    assert sha(previous/'groundtruth.sqlite')==original_hash
after=hashes()
(O/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
assert before==after
print('Exposed development observations complete; source and original databases unchanged.',flush=True)
