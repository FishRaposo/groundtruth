"""Preserve a failed exposed observation without substituting later source."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

V = Path(__file__).resolve().parent
S = V.parent
W = S / 'delivery-worktree'
O = V / 'v10-observations'
E = W / 'docs/evidence/answer-coverage-v6'

def sha(body):
    return hashlib.sha256(body).hexdigest()

before = json.loads((O/'source-before.json').read_text(encoding='utf-8'))
assert before == json.loads((O/'source-after.json').read_text(encoding='utf-8'))
restored = {}
for name, digest in before.items():
    path = W/name
    choices = [path.read_bytes()]
    review_copy = V/'code-review/v10-intent-review/current/app/services'/path.name
    if review_copy.is_file():
        choices.append(review_copy.read_bytes())
    if path.name == 'test_reader_request_intent.py':
        text = path.read_text(encoding='utf-8').split(
            '\n\n@pytest.mark.parametrize(\n    "question",', 1
        )[0].rstrip()+'\n'
        text = text.replace(
            'from app.services.reader_support import procedure_features, requests_procedure',
            'from app.services.reader_support import procedure_features'
        )
        choices.extend([text.encode('utf-8'),text.replace('\n','\r\n').encode('utf-8')])
    if path.name == 'test_reader_scope_exclusion.py':
        text = path.read_text(encoding='utf-8').split(
            '\n\ndef test_single_letter_new_subject_breaks_exclusion_inheritance', 1
        )[0].rstrip()+'\n'
        choices.extend([text.encode('utf-8'),text.replace('\n','\r\n').encode('utf-8')])
    matched = next((body for body in choices if sha(body)==digest), None)
    if matched is None:
        old = subprocess.check_output(['git','show','a4c5b21:'+name],cwd=W)
        canonical = old.decode('utf-8').replace('\r\n','\n')
        matched = next((body for body in [old,canonical.encode('utf-8'),canonical.replace('\n','\r\n').encode('utf-8')] if sha(body)==digest),None)
    assert matched is not None, 'Cannot reconstruct exact measured source: '+name
    restored['measured-source/'+name] = matched

keys=set()
for data in [S/'candidate-blind-v4',V/'calibration']:
    seed=json.loads((data/'seed-manifest.json').read_text(encoding='utf-8'))
    keys.update(x['api_key'].encode() for x in seed['principals'].values() if x.get('api_key'))

payloads={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
payloads.update(restored)
payloads['runner/check_v10_development.py']=(V/'check_v10_development.py').read_bytes()
payloads['controller.log']=(V/'v10-development-controller.log').read_bytes()
payloads['preservation/archive_v10_observation.py']=Path(__file__).read_bytes()
assert not any(key in body for key in keys for body in payloads.values())
assert not E.exists(), 'Never overwrite evidence'
E.mkdir()
destination=E/'v10-exposed-development-observation.zip'
hashes={name:sha(body) for name,body in payloads.items()}
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,body in sorted(payloads.items()):
        archive.writestr(name,body)
    archive.writestr('archive-file-hashes.json',json.dumps(hashes,indent=2)+'\n')
with zipfile.ZipFile(destination) as archive:
    assert all(sha(archive.read(name))==digest for name,digest in hashes.items())
destination.with_suffix('.zip.sha256').write_bytes((sha(destination.read_bytes())+'\n').encode())
summary={
    'status':'EXPOSED DEVELOPMENT ONLY - acceptance remains OPEN',
    'reader_contract':'reader-parts-v8',
    'reader_threshold':4,
    'source_parent_commit':'a4c5b21',
    'source_unchanged_during_measurement':True,
    'exact_source_reconstructed_against_recorded_raw_hashes':len(restored),
    'archive_sha256':sha(destination.read_bytes()),
    'archive_payloads':len(payloads),
    'results':{},
    'limitations':[
        'These cases were already exposed, not fresh blind acceptance.',
        'Independent code review found three defects in this measured version; later repairs are separate.',
        'Later working source is not the source measured in this report.',
        'Synthetic agent-authored labels, not human/general quality validation.'
    ]
}
for label in ['prior-development-80','exposed-v4-200']:
    report=json.loads((O/(label+'-report.json')).read_text(encoding='utf-8'))
    summary['results'][label]={method:value['summary'] for method,value in report['results'].items()}
body=(json.dumps(summary,indent=2)+'\n').encode()
(E/'v10-observation.json').write_bytes(body)
(E/'v10-observation.json.sha256').write_bytes((sha(body)+'\n').encode())
print(json.dumps(summary,indent=2))
